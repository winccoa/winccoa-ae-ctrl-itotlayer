"use strict";
(self["webpackChunkwidgets_label"] = self["webpackChunkwidgets_label"] || []).push([[103],{

/***/ 93745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  g: () => (/* binding */ delay)
});

// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/scheduler/async.js
var scheduler_async = __webpack_require__(88307);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/concat.js + 1 modules
var concat = __webpack_require__(11832);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/take.js
var take = __webpack_require__(40995);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/util/lift.js
var lift = __webpack_require__(5849);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/OperatorSubscriber.js
var OperatorSubscriber = __webpack_require__(76735);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/util/noop.js
var noop = __webpack_require__(40736);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/ignoreElements.js



function ignoreElements() {
  return (0,lift/* operate */.e)((source, subscriber) => {
    source.subscribe((0,OperatorSubscriber/* createOperatorSubscriber */.x)(subscriber, noop/* noop */.Z));
  });
}
//# sourceMappingURL=ignoreElements.js.map
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/mapTo.js
var mapTo = __webpack_require__(21531);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/mergeMap.js
var mergeMap = __webpack_require__(59641);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/innerFrom.js
var innerFrom = __webpack_require__(51599);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/delayWhen.js






function delayWhen(delayDurationSelector, subscriptionDelay) {
  if (subscriptionDelay) {
    return source => (0,concat/* concat */.z)(subscriptionDelay.pipe((0,take/* take */.q)(1), ignoreElements()), source.pipe(delayWhen(delayDurationSelector)));
  }
  return (0,mergeMap/* mergeMap */.z)((value, index) => (0,innerFrom/* innerFrom */.Xf)(delayDurationSelector(value, index)).pipe((0,take/* take */.q)(1), (0,mapTo/* mapTo */.h)(value)));
}
//# sourceMappingURL=delayWhen.js.map
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/timer.js
var timer = __webpack_require__(24231);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/delay.js



function delay(due, scheduler = scheduler_async/* asyncScheduler */.z) {
  const duration = (0,timer/* timer */.H)(due, scheduler);
  return delayWhen(() => duration);
}
//# sourceMappingURL=delay.js.map

/***/ }),

/***/ 21531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h: () => (/* binding */ mapTo)
/* harmony export */ });
/* harmony import */ var _map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(47946);

function mapTo(value) {
  return (0,_map__WEBPACK_IMPORTED_MODULE_0__/* .map */ .U)(() => value);
}
//# sourceMappingURL=mapTo.js.map

/***/ }),

/***/ 86870:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ SieBadgeModule)
/* harmony export */ });
/* unused harmony export BadgeComponent */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87161);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67700);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48573);








function BadgeComponent_sie_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelement(0, "sie-icon", 3);
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r0.icon)("flip", ctx_r0.iconFlip);
  }
}
function BadgeComponent_a_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 4);
    i0.ɵɵlistener("click", function BadgeComponent_a_4_Template_a_click_0_listener($event) {
      i0.ɵɵrestoreView(_r3);
      const ctx_r2 = i0.ɵɵnextContext();
      ctx_r2.onBadgeCloseClicked();
      return i0.ɵɵresetView($event.stopPropagation());
    });
    i0.ɵɵelementEnd();
  }
}
const _c0 = (/* unused pure expression or super */ null && (["*"]));
let BadgeComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class BadgeComponent {
    constructor() {
      this.type = 'dark';
      this.backgroundColor = null;
      this.color = null;
      this.large = false;
      this.interactive = false;
      this.disabled = false;
      this.noEllipsis = false;
      this.icon = null;
      this.iconFlip = null;
      this.closeBadge = new EventEmitter();
    }
    onBadgeCloseClicked() {
      this.closeBadge.emit();
    }
    static #_ = this.ɵfac = function BadgeComponent_Factory(t) {
      return new (t || BadgeComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: BadgeComponent,
      selectors: [["sie-badge"]],
      inputs: {
        type: "type",
        backgroundColor: "backgroundColor",
        color: "color",
        large: "large",
        interactive: "interactive",
        disabled: "disabled",
        noEllipsis: "noEllipsis",
        icon: "icon",
        iconFlip: "iconFlip"
      },
      outputs: {
        closeBadge: "closeBadge"
      },
      ngContentSelectors: _c0,
      decls: 5,
      vars: 11,
      consts: [["sieBackgroundColor", "", "sieColor", "", 1, "span", "badge", 3, "ngClass", "backgroundColor", "color"], ["type", "bold", 3, "icon", "flip", 4, "ngIf"], ["class", "a badge__close", 3, "click", 4, "ngIf"], ["type", "bold", 3, "icon", "flip"], [1, "a", "badge__close", 3, "click"]],
      template: function BadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "span", 0);
          i0.ɵɵtemplate(1, BadgeComponent_sie_icon_1_Template, 1, 2, "sie-icon", 1);
          i0.ɵɵelementStart(2, "span");
          i0.ɵɵprojection(3);
          i0.ɵɵelementEnd();
          i0.ɵɵtemplate(4, BadgeComponent_a_4_Template, 1, 0, "a", 2);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵclassProp("badge--large", ctx.large)("badge--noEllipsis", ctx.noEllipsis)("is-disabled", ctx.disabled);
          i0.ɵɵproperty("ngClass", "badge--" + ctx.type)("backgroundColor", ctx.backgroundColor)("color", ctx.color);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.icon);
          i0.ɵɵadvance(3);
          i0.ɵɵproperty("ngIf", ctx.interactive);
        }
      },
      dependencies: [i1.NgClass, i1.NgIf, i2.BackgroundColorDirective, i2.ColorDirective, i3.IconComponent],
      styles: ["sie-badge .badge>sie-icon:first-child{padding-right:2px;font-size:16px}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return BadgeComponent;
})()));
(function () {
  ( false) && 0;
})();
let SieBadgeModule = /*#__PURE__*/(() => {
  class SieBadgeModule {
    static #_ = this.ɵfac = function SieBadgeModule_Factory(t) {
      return new (t || SieBadgeModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieBadgeModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .SieColorModule */ .NQ, _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_3__/* .SieIconModule */ .A]
    });
  }
  return SieBadgeModule;
})();
(function () {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-badge.mjs.map

/***/ }),

/***/ 12099:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SE: () => (/* binding */ SieCardModule)
/* harmony export */ });
/* unused harmony exports CardComponent, CardContentComponent, CardFooterComponent, CardGridColumnComponent, CardGridComponent, CardGridRowComponent, CardMenuComponent, CardSublineComponent, CardTitleComponent */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87161);




const _c0 = (/* unused pure expression or super */ null && (["*"]));
function CardComponent_div_0_h3_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "h3", 6);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
  }
}
function CardComponent_div_0_p_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 7);
    i0.ɵɵprojection(1, 2);
    i0.ɵɵelementEnd();
  }
}
function CardComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 3);
    i0.ɵɵprojection(1);
    i0.ɵɵtemplate(2, CardComponent_div_0_h3_2_Template, 2, 0, "h3", 4);
    i0.ɵɵtemplate(3, CardComponent_div_0_p_3_Template, 2, 0, "p", 5);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.cardTitleComponent);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.cardSublineComponent);
  }
}
function CardComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵprojection(1, 3);
    i0.ɵɵelementEnd();
  }
}
function CardComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9);
    i0.ɵɵprojection(1, 4);
    i0.ɵɵelementEnd();
  }
}
const _c1 = (/* unused pure expression or super */ null && ([[["sie-card-menu"]], [["sie-card-title"]], [["sie-card-subline"]], [["sie-card-content"]], [["sie-card-footer"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-card-menu", "sie-card-title", "sie-card-subline", "sie-card-content", "sie-card-footer"]));
let CardContentComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardContentComponent {
    static #_ = this.ɵfac = function CardContentComponent_Factory(t) {
      return new (t || CardContentComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardContentComponent,
      selectors: [["sie-card-content"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardContentComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardContentComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardFooterComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardFooterComponent {
    static #_ = this.ɵfac = function CardFooterComponent_Factory(t) {
      return new (t || CardFooterComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardFooterComponent,
      selectors: [["sie-card-footer"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardFooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardFooterComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardSublineComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardSublineComponent {
    static #_ = this.ɵfac = function CardSublineComponent_Factory(t) {
      return new (t || CardSublineComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardSublineComponent,
      selectors: [["sie-card-subline"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardSublineComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardSublineComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardTitleComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardTitleComponent {
    static #_ = this.ɵfac = function CardTitleComponent_Factory(t) {
      return new (t || CardTitleComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardTitleComponent,
      selectors: [["sie-card-title"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardTitleComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardTitleComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardComponent {
    constructor() {
      this.centered = false;
      this.hostClasses = 'card';
    }
    static #_ = this.ɵfac = function CardComponent_Factory(t) {
      return new (t || CardComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardComponent,
      selectors: [["sie-card"]],
      contentQueries: function CardComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i0.ɵɵcontentQuery(dirIndex, CardTitleComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, CardSublineComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, CardContentComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, CardFooterComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardTitleComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardSublineComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardContentComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardFooterComponent = _t.first);
        }
      },
      hostVars: 4,
      hostBindings: function CardComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
          i0.ɵɵclassProp("card--centered", ctx.centered);
        }
      },
      inputs: {
        centered: "centered"
      },
      ngContentSelectors: _c2,
      decls: 3,
      vars: 3,
      consts: [["class", "card__header", 4, "ngIf"], ["class", "card__content", 4, "ngIf"], ["class", "card__footer", 4, "ngIf"], [1, "card__header"], ["class", "card__title", 4, "ngIf"], ["class", "card__subline", 4, "ngIf"], [1, "card__title"], [1, "card__subline"], [1, "card__content"], [1, "card__footer"]],
      template: function CardComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵtemplate(0, CardComponent_div_0_Template, 4, 2, "div", 0);
          i0.ɵɵtemplate(1, CardComponent_div_1_Template, 2, 0, "div", 1);
          i0.ɵɵtemplate(2, CardComponent_div_2_Template, 2, 0, "div", 2);
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.cardTitleComponent || ctx.cardSublineComponent);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.cardContentComponent);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.cardFooterComponent);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["sie-card sie-card-title a{position:static!important}sie-card sie-card-content p{padding:0 24px;font-size:14px}sie-card sie-card-content p:first-child{margin-top:0}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardMenuComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardMenuComponent {
    static #_ = this.ɵfac = function CardMenuComponent_Factory(t) {
      return new (t || CardMenuComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardMenuComponent,
      selectors: [["sie-card-menu"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardMenuComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardMenuComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardGridComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardGridComponent {
    static #_ = this.ɵfac = function CardGridComponent_Factory(t) {
      return new (t || CardGridComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardGridComponent,
      selectors: [["sie-card-grid"]],
      ngContentSelectors: _c0,
      decls: 2,
      vars: 0,
      consts: [[1, "cards", "cards--simpleGrid"]],
      template: function CardGridComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "div", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardGridComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardGridColumnComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardGridColumnComponent {
    constructor() {
      this.hostClasses = 'cards__col';
    }
    static #_ = this.ɵfac = function CardGridColumnComponent_Factory(t) {
      return new (t || CardGridColumnComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardGridColumnComponent,
      selectors: [["sie-card-grid-column"]],
      hostVars: 2,
      hostBindings: function CardGridColumnComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardGridColumnComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardGridColumnComponent;
})()));
(function () {
  ( false) && 0;
})();
let CardGridRowComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardGridRowComponent {
    constructor() {
      this.hostClasses = 'cards__row';
    }
    static #_ = this.ɵfac = function CardGridRowComponent_Factory(t) {
      return new (t || CardGridRowComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardGridRowComponent,
      selectors: [["sie-card-grid-row"]],
      hostVars: 2,
      hostBindings: function CardGridRowComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardGridRowComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardGridRowComponent;
})()));
(function () {
  ( false) && 0;
})();
let SieCardModule = /*#__PURE__*/(() => {
  class SieCardModule {
    static #_ = this.ɵfac = function SieCardModule_Factory(t) {
      return new (t || SieCardModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieCardModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule]
    });
  }
  return SieCardModule;
})();
(function () {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-card.mjs.map

/***/ }),

/***/ 60491:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o4: () => (/* binding */ SieContainerModule)
/* harmony export */ });
/* unused harmony exports ContainerComponent, ContainerContentComponent, ContainerContentDividerComponent, ContainerGroupComponent, ContainerTitleActionsComponent, ContainerTitleComponent, ContainerTitleMetaComponent */
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87161);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(75826);




const _c0 = (/* unused pure expression or super */ null && (["*"]));
function ContainerComponent_div_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainer(0);
  }
}
function ContainerComponent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9);
    i0.ɵɵprojection(1);
    i0.ɵɵelementEnd();
  }
}
function ContainerComponent_div_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 10);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
  }
}
function ContainerComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtemplate(1, ContainerComponent_div_0_ng_container_1_Template, 1, 0, "ng-container", 6);
    i0.ɵɵtemplate(2, ContainerComponent_div_0_div_2_Template, 2, 0, "div", 7);
    i0.ɵɵtemplate(3, ContainerComponent_div_0_div_3_Template, 2, 0, "div", 8);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    const _r4 = i0.ɵɵreference(5);
    const _r2 = i0.ɵɵreference(3);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r0.type === "collapsable" ? _r4 : _r2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.containerTitleMetaComponent);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.containerTitleActionsComponent);
  }
}
function ContainerComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵprojection(1, 2);
    i0.ɵɵelementEnd();
  }
}
function ContainerComponent_ng_template_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainer(0);
  }
}
function ContainerComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 12);
    i0.ɵɵtemplate(1, ContainerComponent_ng_template_2_ng_container_1_Template, 1, 0, "ng-container", 6);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    i0.ɵɵnextContext();
    const _r6 = i0.ɵɵreference(7);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngTemplateOutlet", _r6);
  }
}
function ContainerComponent_ng_template_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainer(0);
  }
}
function ContainerComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 13);
    i0.ɵɵlistener("click", function ContainerComponent_ng_template_4_Template_a_click_0_listener() {
      i0.ɵɵrestoreView(_r14);
      const ctx_r13 = i0.ɵɵnextContext();
      return i0.ɵɵresetView(ctx_r13.toggleCollapsedState());
    });
    i0.ɵɵtemplate(1, ContainerComponent_ng_template_4_ng_container_1_Template, 1, 0, "ng-container", 6);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    i0.ɵɵnextContext();
    const _r6 = i0.ɵɵreference(7);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngTemplateOutlet", _r6);
  }
}
function ContainerComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵprojection(0, 3);
  }
}
const _c1 = (/* unused pure expression or super */ null && ([[["sie-container-title-meta"]], [["sie-container-title-actions"]], [["sie-container-content"]], [["sie-container-title"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-container-title-meta", "sie-container-title-actions", "sie-container-content", "sie-container-title"]));
const _c3 = (/* unused pure expression or super */ null && ([[["sie-container"]]]));
const _c4 = (/* unused pure expression or super */ null && (["sie-container"]));
let ContainerContentComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerContentComponent {
    static #_ = this.ɵfac = function ContainerContentComponent_Factory(t) {
      return new (t || ContainerContentComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerContentComponent,
      selectors: [["sie-container-content"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerContentComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerContentComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContainerTitleComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerTitleComponent {
    static #_ = this.ɵfac = function ContainerTitleComponent_Factory(t) {
      return new (t || ContainerTitleComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerTitleComponent,
      selectors: [["sie-container-title"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerTitleComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerTitleComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContainerTitleActionsComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerTitleActionsComponent {
    static #_ = this.ɵfac = function ContainerTitleActionsComponent_Factory(t) {
      return new (t || ContainerTitleActionsComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerTitleActionsComponent,
      selectors: [["sie-container-title-actions"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerTitleActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerTitleActionsComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContainerTitleMetaComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerTitleMetaComponent {
    static #_ = this.ɵfac = function ContainerTitleMetaComponent_Factory(t) {
      return new (t || ContainerTitleMetaComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerTitleMetaComponent,
      selectors: [["sie-container-title-meta"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerTitleMetaComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerTitleMetaComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContainerComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerComponent {
    constructor() {
      this.type = null;
      this.collapsed = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    toggleCollapsedState() {
      this.collapsed = !this.collapsed;
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['container'];
      if (this.type) {
        hostClassesArray.push(`container--${this.type}`);
      }
      if (this.type === 'collapsable' && this.collapsed) {
        hostClassesArray.push('is-collapsed');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function ContainerComponent_Factory(t) {
      return new (t || ContainerComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerComponent,
      selectors: [["sie-container"]],
      contentQueries: function ContainerComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i0.ɵɵcontentQuery(dirIndex, ContainerTitleComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContainerTitleMetaComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContainerTitleActionsComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContainerContentComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerTitleComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerTitleMetaComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerTitleActionsComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerContentComponent = _t.first);
        }
      },
      hostVars: 2,
      hostBindings: function ContainerComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        type: "type",
        collapsed: "collapsed"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c2,
      decls: 8,
      vars: 2,
      consts: [["class", "container__title", 4, "ngIf"], ["class", "container__content", 4, "ngIf"], ["defaultContainerTitle", ""], ["collapsableContainerTitle", ""], ["containerTitleContent", ""], [1, "container__title"], [4, "ngTemplateOutlet"], ["class", "title__meta", 4, "ngIf"], ["class", "title__actions", 4, "ngIf"], [1, "title__meta"], [1, "title__actions"], [1, "container__content"], [1, "title__content"], [1, "a", "title__content", 3, "click"]],
      template: function ContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵtemplate(0, ContainerComponent_div_0_Template, 4, 3, "div", 0);
          i0.ɵɵtemplate(1, ContainerComponent_div_1_Template, 2, 0, "div", 1);
          i0.ɵɵtemplate(2, ContainerComponent_ng_template_2_Template, 2, 1, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
          i0.ɵɵtemplate(4, ContainerComponent_ng_template_4_Template, 2, 1, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
          i0.ɵɵtemplate(6, ContainerComponent_ng_template_6_Template, 1, 0, "ng-template", null, 4, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.containerTitleComponent);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.containerContentComponent);
        }
      },
      dependencies: [i1.NgIf, i1.NgTemplateOutlet],
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return ContainerComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContainerContentDividerComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerContentDividerComponent {
    constructor() {
      this.section = false;
    }
    static #_ = this.ɵfac = function ContainerContentDividerComponent_Factory(t) {
      return new (t || ContainerContentDividerComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerContentDividerComponent,
      selectors: [["sie-container-content-divider"]],
      inputs: {
        section: "section"
      },
      decls: 1,
      vars: 2,
      consts: [[1, "hr", "content__divider"]],
      template: function ContainerContentDividerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵelement(0, "hr", 0);
        }
        if (rf & 2) {
          i0.ɵɵclassProp("content__divider--section", ctx.section);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerContentDividerComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContainerGroupComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerGroupComponent {
    constructor() {
      this.hostClasses = 'containergroup';
    }
    static #_ = this.ɵfac = function ContainerGroupComponent_Factory(t) {
      return new (t || ContainerGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerGroupComponent,
      selectors: [["sie-container-group"]],
      hostVars: 2,
      hostBindings: function ContainerGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c4,
      decls: 1,
      vars: 0,
      template: function ContainerGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c3);
          i0.ɵɵprojection(0);
        }
      },
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return ContainerGroupComponent;
})()));
(function () {
  ( false) && 0;
})();
let SieContainerModule = /*#__PURE__*/(() => {
  class SieContainerModule {
    static #_ = this.ɵfac = function SieContainerModule_Factory(t) {
      return new (t || SieContainerModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieContainerModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]
    });
  }
  return SieContainerModule;
})();
(function () {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-container.mjs.map

/***/ })

}]);