"use strict";
(self["webpackChunkwidgets_label"] = self["webpackChunkwidgets_label"] || []).push([[414],{

/***/ 92613:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EJ: () => (/* binding */ SieButtonModule),
/* harmony export */   Qp: () => (/* binding */ ButtonComponent),
/* harmony export */   Z7: () => (/* binding */ ButtonGroupComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(53081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10463);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99710);






const _c0 = ["*"];
function ButtonComponent_sie_icon_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "sie-icon", 2);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("icon", ctx_r0.icon)("type", ctx_r0.iconType)("flip", ctx_r0.iconFlip);
  }
}
function ButtonComponent_sie_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "sie-icon", 2);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("icon", ctx_r0.icon)("type", ctx_r0.iconType)("flip", ctx_r0.iconFlip);
  }
}
function ButtonComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ButtonComponent_div_3_Template_div_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"]($event.stopPropagation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
}
const _c1 = (/* runtime-dependent pure expression or super */ /^(437|792)$/.test(__webpack_require__.j) ? ([[["sie-button"]]]) : null);
const _c2 = (/* runtime-dependent pure expression or super */ /^(437|792)$/.test(__webpack_require__.j) ? (["sie-button"]) : null);
let ButtonComponent = /*#__PURE__*/(() => {
  class ButtonComponent {
    onKeyupEnter() {
      if (!this.disabled && this.elementRef.nativeElement) {
        this.elementRef.nativeElement.click();
      }
    }
    constructor(elementRef) {
      this.elementRef = elementRef;
      this.type = 'primary';
      this.icon = null;
      this.iconType = null;
      this.iconFlip = null;
      this.iconOnly = false;
      this.iconPosition = 'left';
      this.disabled = false;
      this.activated = false;
      this.danger = false;
      this.additionalCssClasses = null;
      this.tabIndex = 0;
      this.role = 'button';
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['button'];
      hostClassesArray.push(`button--${this.type}`);
      if (this.additionalCssClasses) {
        hostClassesArray.push(this.additionalCssClasses);
      }
      if (this.iconOnly) {
        hostClassesArray.push('has-icon-only');
      }
      if (this.disabled) {
        hostClassesArray.push('is-disabled');
      }
      if (this.activated) {
        hostClassesArray.push('is-activated');
      }
      if (this.danger) {
        hostClassesArray.push('is-dangerButton');
      }
      if (this.iconPosition === 'right') {
        hostClassesArray.push('has-icon-right');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function ButtonComponent_Factory(t) {
      return new (t || ButtonComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: ButtonComponent,
      selectors: [["sie-button"]],
      hostVars: 4,
      hostBindings: function ButtonComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup.enter", function ButtonComponent_keyup_enter_HostBindingHandler() {
            return ctx.onKeyupEnter();
          });
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵhostProperty"]("tabindex", ctx.tabIndex);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("role", ctx.role);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      inputs: {
        type: "type",
        icon: "icon",
        iconType: "iconType",
        iconFlip: "iconFlip",
        iconOnly: "iconOnly",
        iconPosition: "iconPosition",
        disabled: "disabled",
        activated: "activated",
        danger: "danger",
        additionalCssClasses: "additionalCssClasses",
        tabIndex: "tabIndex"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]],
      ngContentSelectors: _c0,
      decls: 4,
      vars: 3,
      consts: [[3, "icon", "type", "flip", 4, "ngIf"], ["class", "button__disabledOverlay", 3, "click", 4, "ngIf"], [3, "icon", "type", "flip"], [1, "button__disabledOverlay", 3, "click"]],
      template: function ButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, ButtonComponent_sie_icon_0_Template, 1, 3, "sie-icon", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojection"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, ButtonComponent_sie_icon_2_Template, 1, 3, "sie-icon", 0)(3, ButtonComponent_div_3_Template, 1, 0, "div", 1);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.icon && ctx.iconPosition === "left");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.icon && ctx.iconPosition === "right");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.disabled);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.NgIf, _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_2__/* .IconComponent */ .R],
      styles: ["sie-button{position:relative;-webkit-user-select:none;user-select:none}sie-button .button__disabledOverlay{position:absolute;cursor:not-allowed;inset:-1px}sie-button:focus:not(:focus-visible){outline:0!important}.uxt.uxt-defaults sie-button.button--ghost,.uxt.uxt-defaults sie-button.button--primaryContentAction,.uxt.uxt-defaults sie-button.button--secondaryContentAction{transition:background-color .2s ease-in-out,color .2s ease-in-out!important}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ButtonComponent;
})();
(() => {
  ( false) && 0;
})();
let ButtonGroupComponent = /*#__PURE__*/(/* runtime-dependent pure expression or super */ /^(437|792)$/.test(__webpack_require__.j) ? ((() => {
  class ButtonGroupComponent {
    constructor() {
      this.hostClasses = 'buttonGroup';
    }
    static #_ = this.ɵfac = function ButtonGroupComponent_Factory(t) {
      return new (t || ButtonGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: ButtonGroupComponent,
      selectors: [["sie-button-group"]],
      hostVars: 2,
      hostBindings: function ButtonGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      ngContentSelectors: _c2,
      decls: 1,
      vars: 0,
      template: function ButtonGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojectionDef"](_c1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojection"](0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ButtonGroupComponent;
})()) : null);
(() => {
  ( false) && 0;
})();
let SieButtonModule = /*#__PURE__*/(() => {
  class SieButtonModule {
    static #_ = this.ɵfac = function SieButtonModule_Factory(t) {
      return new (t || SieButtonModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieButtonModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_2__/* .SieIconModule */ .j]
    });
  }
  return SieButtonModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-button.mjs.map

/***/ }),

/***/ 35782:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $e: () => (/* binding */ SieColorModule),
/* harmony export */   D$: () => (/* binding */ BackgroundColorDirective),
/* harmony export */   Fy: () => (/* binding */ ColorDirective)
/* harmony export */ });
/* unused harmony exports BorderColorDirective, ToColorHexPipe, toColorHex */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(53081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10463);



const COLOR_CLASS_MAP = new Map([
// Base colors
['base000', 'base000'], ['base200', 'base200'], ['base450', 'base450'], ['base600', 'base600'], ['base750', 'base750'], ['base800', 'base800'], ['base900', 'base900'], ['base950', 'base950'], ['base1000', 'base1000'],
// Primary colors
['primaryDarker', 'primary-darker'], ['primaryDark', 'primary-dark'], ['primary', 'primary'], ['primaryLight', 'primary-light'], ['primaryLighter', 'primary-lighter'], ['primaryLightest', 'primary-lightest'],
// Functional colors
['infoDark', 'info-dark'], ['info', 'info'], ['infoLight', 'info-light'], ['infoLighter', 'info-lighter'], ['warningDark', 'warning-dark'], ['warning', 'warning'], ['warningLight', 'warning-light'], ['warningLighter', 'warning-lighter'], ['errorDark', 'error-dark'], ['error', 'error'], ['errorLight', 'error-light'], ['errorLighter', 'error-lighter'], ['successDark', 'success-dark'], ['success', 'success'], ['successLight', 'success-light'], ['successLighter', 'success-lighter'],
// OS Bar / Launchpad colors
['firefly', 'firefly'], ['aquaHaze', 'aquaHaze'],
// Charting colors
['charting01', 'charting01'], ['charting02', 'charting02'], ['charting03', 'charting03'], ['charting04', 'charting04'], ['charting05', 'charting05'], ['charting06', 'charting06'], ['charting07', 'charting07'], ['charting08', 'charting08'], ['charting09', 'charting09'], ['charting10', 'charting10'], ['charting11', 'charting11'], ['charting12', 'charting12'], ['charting13', 'charting13'], ['charting14', 'charting14'], ['charting15', 'charting15'], ['charting16', 'charting16'], ['charting17', 'charting17'], ['charting18', 'charting18'], ['charting19', 'charting19'], ['charting20', 'charting20'], ['charting21', 'charting21']]);
const COLOR_HEX_MAP = new Map([
// Base colors
['base000', '#000000'], ['base200', '#323232'], ['base450', '#595959'], ['base600', '#969696'], ['base750', '#BEBEBE'], ['base800', '#D2D2D2'], ['base900', '#F0F0F0'], ['base950', '#F6F6F6'], ['base1000', '#FFFFFF'],
// Primary colors
['primaryDarker', '#354C80'], ['primaryDark', '#005CBF'], ['primary', '#006FE6'], ['primaryLight', '#009EFF'], ['primaryLighter', '#7FB7F2'], ['primaryLightest', '#CCE2FA'],
// Functional colors
['infoDark', '#235461'], ['info', '#006FE6'], ['infoLight', '#BBD0D7'], ['infoLighter', '#D1E8F0'], ['warningDark', '#665E48'], ['warning', '#FFC800'], ['warningLight', '#E6DBB7'], ['warningLighter', '#FFEDB5'], ['errorDark', '#811211'], ['error', '#F62447'], ['errorLight', '#D6B4B4'], ['errorLighter', '#FCD3D2'], ['successDark', '#5E6919'], ['success', '#65C728'], ['successLight', '#C8D1BA'], ['successLighter', '#E6EED1'],
// OS Bar / Launchpad colors
['firefly', '#1E2832'], ['aquaHaze', '#DCE1E6'],
// Charting colors
['charting01', '#08889E'], ['charting02', '#FFB900'], ['charting03', '#AAB414'], ['charting04', '#8068E7'], ['charting05', '#AF235F'], ['charting06', '#794934'], ['charting07', '#006FE6'], ['charting08', '#879BAA'], ['charting09', '#EB780A'], ['charting10', '#554A50'], ['charting11', '#647D2D'], ['charting12', '#50BED7'], ['charting13', '#B98F72'], ['charting14', '#C8C8B7'], ['charting15', '#A985A8'], ['charting16', '#FF9EBC'], ['charting17', '#530E00'], ['charting18', '#789CFF'], ['charting19', '#F62447'], ['charting20', '#FFC800'], ['charting21', '#65C728']]);
let BackgroundColorDirective = /*#__PURE__*/(() => {
  class BackgroundColorDirective {
    constructor(renderer, elementRef) {
      this.renderer = renderer;
      this.elementRef = elementRef;
      this.backgroundColor = null;
      this.backgroundColorForced = false;
    }
    ngOnChanges() {
      if (this.addedClassName) {
        this.renderer.removeClass(this.elementRef.nativeElement, this.addedClassName);
      }
      if (this.backgroundColor) {
        const className = this.getClassName(this.backgroundColor, this.backgroundColorForced);
        this.renderer.addClass(this.elementRef.nativeElement, className);
        this.addedClassName = className;
      }
    }
    getClassName(backgroundColor, backgroundColorForced) {
      return `has-bgColor-${backgroundColorForced ? 'forced-' : ''}${COLOR_CLASS_MAP.get(backgroundColor)}`;
    }
    static #_ = this.ɵfac = function BackgroundColorDirective_Factory(t) {
      return new (t || BackgroundColorDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
      type: BackgroundColorDirective,
      selectors: [["", "sieBackgroundColor", ""]],
      inputs: {
        backgroundColor: "backgroundColor",
        backgroundColorForced: "backgroundColorForced"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]]
    });
  }
  return BackgroundColorDirective;
})();
(() => {
  ( false) && 0;
})();
let BorderColorDirective = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class BorderColorDirective {
    constructor(renderer, elementRef) {
      this.renderer = renderer;
      this.elementRef = elementRef;
      this.borderColor = null;
      this.borderColorForced = false;
    }
    ngOnChanges() {
      if (this.addedClassName) {
        this.renderer.removeClass(this.elementRef.nativeElement, this.addedClassName);
      }
      if (this.borderColor) {
        const className = this.getClassName(this.borderColor, this.borderColorForced);
        this.renderer.addClass(this.elementRef.nativeElement, className);
        this.addedClassName = className;
      }
    }
    getClassName(borderColor, borderColorForced) {
      return `has-borderColor-${borderColorForced ? 'forced-' : ''}${COLOR_CLASS_MAP.get(borderColor)}`;
    }
    static #_ = this.ɵfac = function BorderColorDirective_Factory(t) {
      return new (t || BorderColorDirective)(i0.ɵɵdirectiveInject(i0.Renderer2), i0.ɵɵdirectiveInject(i0.ElementRef));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */i0.ɵɵdefineDirective({
      type: BorderColorDirective,
      selectors: [["", "sieBorderColor", ""]],
      inputs: {
        borderColor: "borderColor",
        borderColorForced: "borderColorForced"
      },
      features: [i0.ɵɵNgOnChangesFeature]
    });
  }
  return BorderColorDirective;
})()));
(() => {
  ( false) && 0;
})();
let ColorDirective = /*#__PURE__*/(() => {
  class ColorDirective {
    constructor(renderer, elementRef) {
      this.renderer = renderer;
      this.elementRef = elementRef;
      this.color = null;
      this.colorForced = false;
    }
    ngOnChanges() {
      if (this.addedClassName) {
        this.renderer.removeClass(this.elementRef.nativeElement, this.addedClassName);
      }
      if (this.color) {
        const className = this.getClassName(this.color, this.colorForced);
        this.renderer.addClass(this.elementRef.nativeElement, className);
        this.addedClassName = className;
      }
    }
    getClassName(color, colorForced) {
      return `has-color-${colorForced ? 'forced-' : ''}${COLOR_CLASS_MAP.get(color)}`;
    }
    static #_ = this.ɵfac = function ColorDirective_Factory(t) {
      return new (t || ColorDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
      type: ColorDirective,
      selectors: [["", "sieColor", ""]],
      inputs: {
        color: "color",
        colorForced: "colorForced"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]]
    });
  }
  return ColorDirective;
})();
(() => {
  ( false) && 0;
})();
let ToColorHexPipe = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ToColorHexPipe {
    transform(color) {
      return toColorHex(color);
    }
    static #_ = this.ɵfac = function ToColorHexPipe_Factory(t) {
      return new (t || ToColorHexPipe)();
    };
    static #_2 = this.ɵpipe = /* @__PURE__ */i0.ɵɵdefinePipe({
      name: "sieToColorHex",
      type: ToColorHexPipe,
      pure: true
    });
  }
  return ToColorHexPipe;
})()));
(() => {
  ( false) && 0;
})();
function toColorHex(color) {
  return COLOR_HEX_MAP.get(color) ?? null;
}
let SieColorModule = /*#__PURE__*/(() => {
  class SieColorModule {
    static #_ = this.ɵfac = function SieColorModule_Factory(t) {
      return new (t || SieColorModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieColorModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule]
    });
  }
  return SieColorModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-color.mjs.map

/***/ }),

/***/ 76963:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C$: () => (/* binding */ SelectDirective),
/* harmony export */   _1: () => (/* binding */ SieFormModule),
/* harmony export */   fv: () => (/* binding */ InputGroupComponent),
/* harmony export */   h4: () => (/* binding */ FormGroupComponent),
/* harmony export */   hM: () => (/* binding */ InputTextDirective),
/* harmony export */   i4: () => (/* binding */ TextareaDirective),
/* harmony export */   jj: () => (/* binding */ CheckboxDirective),
/* harmony export */   pd: () => (/* binding */ SelectWrapperComponent),
/* harmony export */   wU: () => (/* binding */ FormGroupLineBreakComponent)
/* harmony export */ });
/* unused harmony exports CheckboxWrapperComponent, FieldsetComponent, FormButtonsComponent, FormComponent, FormRequiredMessageComponent, InputGroupErrorComponent, RadioButtonDirective, RadioButtonWrapperComponent, SwitchComponent */
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10463);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53081);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(78075);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(35782);







const _c0 = ["*"];
function CheckboxWrapperComponent_ng_container_1_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function CheckboxWrapperComponent_ng_container_1_label_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function CheckboxWrapperComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, CheckboxWrapperComponent_ng_container_1_label_1_Template, 2, 2, "label", 0)(2, CheckboxWrapperComponent_ng_container_1_label_2_Template, 2, 2, "label", 1);
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
function CheckboxWrapperComponent_ng_container_2_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelement(0, "label");
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
  }
}
function CheckboxWrapperComponent_ng_container_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function CheckboxWrapperComponent_ng_container_2_p_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function CheckboxWrapperComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, CheckboxWrapperComponent_ng_container_2_label_1_Template, 1, 1, "label", 0);
    i0.ɵɵelementStart(2, "div", 3);
    i0.ɵɵtemplate(3, CheckboxWrapperComponent_ng_container_2_div_3_Template, 2, 1, "div", 4)(4, CheckboxWrapperComponent_ng_container_2_p_4_Template, 2, 1, "p", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
function FieldsetComponent_legend_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.subtitle);
  }
}
function FieldsetComponent_legend_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "legend", 1)(1, "div", 2);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, FieldsetComponent_legend_0_div_3_Template, 2, 1, "div", 3);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.title);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.subtitle);
  }
}
const _c1 = (/* unused pure expression or super */ null && ([[["sie-button"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-button"]));
function InputGroupComponent_label_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("is-required", ctx_r0.required);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("for", ctx_r0.for);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.label, "\n");
  }
}
function InputGroupComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.description, "\n");
  }
}
function RadioButtonWrapperComponent_ng_container_1_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function RadioButtonWrapperComponent_ng_container_1_label_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function RadioButtonWrapperComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, RadioButtonWrapperComponent_ng_container_1_label_1_Template, 2, 2, "label", 0)(2, RadioButtonWrapperComponent_ng_container_1_label_2_Template, 2, 2, "label", 1);
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
function RadioButtonWrapperComponent_ng_container_2_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelement(0, "label");
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
  }
}
function RadioButtonWrapperComponent_ng_container_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function RadioButtonWrapperComponent_ng_container_2_p_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function RadioButtonWrapperComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, RadioButtonWrapperComponent_ng_container_2_label_1_Template, 1, 1, "label", 0);
    i0.ɵɵelementStart(2, "div", 3);
    i0.ɵɵtemplate(3, RadioButtonWrapperComponent_ng_container_2_div_3_Template, 2, 1, "div", 4)(4, RadioButtonWrapperComponent_ng_container_2_p_4_Template, 2, 1, "p", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
const _c3 = "[_nghost-%COMP%]{display:block;font-size:initial;line-height:initial}";
function SwitchComponent_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 5);
  }
}
function SwitchComponent_label_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("for", ctx_r0.switchId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.label, " ");
  }
}
let CheckboxWrapperComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CheckboxWrapperComponent {
    constructor() {
      this.description = null;
      this.alternative = false;
      this.shadow = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['checkboxWrapper'];
      if (this.alternative) {
        hostClassesArray.push('checkboxWrapper--alternative');
        if (this.shadow) {
          hostClassesArray.push('has-shadow');
        }
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function CheckboxWrapperComponent_Factory(t) {
      return new (t || CheckboxWrapperComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CheckboxWrapperComponent,
      selectors: [["sie-checkbox-wrapper"]],
      hostVars: 2,
      hostBindings: function CheckboxWrapperComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        label: "label",
        description: "description",
        for: "for",
        alternative: "alternative",
        shadow: "shadow"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 2,
      consts: [[4, "ngIf"], ["class", "checkbox__description", 4, "ngIf"], [1, "checkbox__description"], [1, "checkboxWrapper--alternative__content"], ["class", "checkboxWrapper--alternative__header", 4, "ngIf"], [1, "checkboxWrapper--alternative__header"]],
      template: function CheckboxWrapperComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
          i0.ɵɵtemplate(1, CheckboxWrapperComponent_ng_container_1_Template, 3, 2, "ng-container", 0)(2, CheckboxWrapperComponent_ng_container_2_Template, 5, 3, "ng-container", 0);
        }
        if (rf & 2) {
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", !ctx.alternative);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.alternative);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["[_nghost-%COMP%]{display:block;font-size:initial;line-height:initial}"],
      changeDetection: 0
    });
  }
  return CheckboxWrapperComponent;
})()));
(() => {
  ( false) && 0;
})();
let FieldsetComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FieldsetComponent {
    constructor() {
      this.title = null;
      this.subtitle = null;
      this.alternative = false;
      this.compact = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['fieldset'];
      if (this.alternative) {
        hostClassesArray.push('fieldset--alternative');
      }
      if (this.compact) {
        hostClassesArray.push('fieldset--compact');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function FieldsetComponent_Factory(t) {
      return new (t || FieldsetComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FieldsetComponent,
      selectors: [["sie-fieldset"]],
      hostVars: 2,
      hostBindings: function FieldsetComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        title: "title",
        subtitle: "subtitle",
        alternative: "alternative",
        compact: "compact"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 1,
      consts: [["class", "legend", 4, "ngIf"], [1, "legend"], [1, "legend__title"], ["class", "legend__subtitle", 4, "ngIf"], [1, "legend__subtitle"]],
      template: function FieldsetComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵtemplate(0, FieldsetComponent_legend_0_Template, 4, 2, "legend", 0);
          i0.ɵɵelementStart(1, "div");
          i0.ɵɵprojection(2);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.title);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return FieldsetComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormComponent {
    static #_ = this.ɵfac = function FormComponent_Factory(t) {
      return new (t || FormComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormComponent,
      selectors: [["sie-form"]],
      ngContentSelectors: _c0,
      decls: 2,
      vars: 0,
      consts: [["novalidate", "", "autocomplete", "off", 1, "form"]],
      template: function FormComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "form", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormButtonsComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormButtonsComponent {
    static #_ = this.ɵfac = function FormButtonsComponent_Factory(t) {
      return new (t || FormButtonsComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormButtonsComponent,
      selectors: [["sie-form-buttons"]],
      ngContentSelectors: _c2,
      decls: 2,
      vars: 0,
      consts: [[1, "form__buttons"]],
      template: function FormButtonsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵelementStart(0, "div", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormButtonsComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormGroupComponent = /*#__PURE__*/(() => {
  class FormGroupComponent {
    constructor() {
      this.error = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['form__formGroup'];
      if (this.error) {
        hostClassesArray.push('has-error');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function FormGroupComponent_Factory(t) {
      return new (t || FormGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: FormGroupComponent,
      selectors: [["sie-form-group"]],
      hostVars: 2,
      hostBindings: function FormGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      inputs: {
        error: "error"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function FormGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return FormGroupComponent;
})();
(() => {
  ( false) && 0;
})();
let FormGroupLineBreakComponent = /*#__PURE__*/(/* runtime-dependent pure expression or super */ /^(437|792)$/.test(__webpack_require__.j) ? ((() => {
  class FormGroupLineBreakComponent {
    constructor() {
      this.hostClasses = 'form__lineBreak';
    }
    static #_ = this.ɵfac = function FormGroupLineBreakComponent_Factory(t) {
      return new (t || FormGroupLineBreakComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: FormGroupLineBreakComponent,
      selectors: [["sie-form-group-line-break"]],
      hostVars: 2,
      hostBindings: function FormGroupLineBreakComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function FormGroupLineBreakComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormGroupLineBreakComponent;
})()) : null);
(() => {
  ( false) && 0;
})();
let FormRequiredMessageComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormRequiredMessageComponent {
    static #_ = this.ɵfac = function FormRequiredMessageComponent_Factory(t) {
      return new (t || FormRequiredMessageComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormRequiredMessageComponent,
      selectors: [["sie-form-required-message"]],
      ngContentSelectors: _c0,
      decls: 2,
      vars: 0,
      consts: [[1, "form__requiredMsg"]],
      template: function FormRequiredMessageComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "div", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormRequiredMessageComponent;
})()));
(() => {
  ( false) && 0;
})();
let InputGroupComponent = /*#__PURE__*/(() => {
  class InputGroupComponent {
    constructor() {
      this.label = null;
      this.description = null;
      this.required = false;
      this.size = null;
      this.invalid = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['inputGroup'];
      if (this.invalid) {
        hostClassesArray.push('is-invalid');
      }
      if (this.size) {
        hostClassesArray.push(`inputGroup--${this.size.toLowerCase()}`);
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function InputGroupComponent_Factory(t) {
      return new (t || InputGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: InputGroupComponent,
      selectors: [["sie-input-group"]],
      hostVars: 2,
      hostBindings: function InputGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      inputs: {
        label: "label",
        description: "description",
        required: "required",
        size: "size",
        invalid: "invalid",
        for: "for"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 2,
      consts: [["class", "inputGroup__label", 3, "is-required", 4, "ngIf"], ["class", "inputGroup__description", 4, "ngIf"], [1, "inputGroup__label"], [1, "inputGroup__description"]],
      template: function InputGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, InputGroupComponent_label_0_Template, 2, 4, "label", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, InputGroupComponent_div_2_Template, 2, 1, "div", 1);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.label);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.description);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf],
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return InputGroupComponent;
})();
(() => {
  ( false) && 0;
})();
let InputGroupErrorComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class InputGroupErrorComponent {
    static #_ = this.ɵfac = function InputGroupErrorComponent_Factory(t) {
      return new (t || InputGroupErrorComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: InputGroupErrorComponent,
      selectors: [["sie-input-group-error"]],
      inputs: {
        for: "for"
      },
      ngContentSelectors: _c0,
      decls: 2,
      vars: 1,
      consts: [[1, "inputGroup--error"]],
      template: function InputGroupErrorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "label", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵattribute("for", ctx.for);
        }
      },
      styles: ["sie-input-group-error{display:block}sie-input-group-error .inputGroup--error{margin-bottom:0!important}sie-form-group-line-break sie-input-group-error:last-child .inputGroup--error{margin-bottom:16px!important;margin-bottom:1rem!important}sie-form-group.has-error:last-child>sie-form-group-line-break:last-child sie-input-group-error:last-child .inputGroup--error{margin-bottom:0!important}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return InputGroupErrorComponent;
})()));
(() => {
  ( false) && 0;
})();
let RadioButtonWrapperComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class RadioButtonWrapperComponent {
    constructor() {
      this.description = null;
      this.alternative = false;
      this.shadow = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['radioButtonWrapper'];
      if (this.alternative) {
        hostClassesArray.push('radioButtonWrapper--alternative');
        if (this.shadow) {
          hostClassesArray.push('has-shadow');
        }
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function RadioButtonWrapperComponent_Factory(t) {
      return new (t || RadioButtonWrapperComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: RadioButtonWrapperComponent,
      selectors: [["sie-radio-button-wrapper"]],
      hostVars: 2,
      hostBindings: function RadioButtonWrapperComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        label: "label",
        description: "description",
        for: "for",
        alternative: "alternative",
        shadow: "shadow"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 2,
      consts: [[4, "ngIf"], ["class", "radioButton__description", 4, "ngIf"], [1, "radioButton__description"], [1, "radioButtonWrapper--alternative__content"], ["class", "radioButtonWrapper--alternative__header", 4, "ngIf"], [1, "radioButtonWrapper--alternative__header"]],
      template: function RadioButtonWrapperComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
          i0.ɵɵtemplate(1, RadioButtonWrapperComponent_ng_container_1_Template, 3, 2, "ng-container", 0)(2, RadioButtonWrapperComponent_ng_container_2_Template, 5, 3, "ng-container", 0);
        }
        if (rf & 2) {
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", !ctx.alternative);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.alternative);
        }
      },
      dependencies: [i1.NgIf],
      styles: [_c3],
      changeDetection: 0
    });
  }
  return RadioButtonWrapperComponent;
})()));
(() => {
  ( false) && 0;
})();
let SelectWrapperComponent = /*#__PURE__*/(() => {
  class SelectWrapperComponent {
    constructor() {
      this.multiple = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['selectWrapper'];
      if (this.multiple) {
        hostClassesArray.push('selectWrapper--multiple');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function SelectWrapperComponent_Factory(t) {
      return new (t || SelectWrapperComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: SelectWrapperComponent,
      selectors: [["sie-select-wrapper"]],
      hostVars: 2,
      hostBindings: function SelectWrapperComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      inputs: {
        multiple: "multiple"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function SelectWrapperComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      styles: ["[_nghost-%COMP%]:before{top:calc(50% - 7px)!important;font-size:initial;line-height:initial}"],
      changeDetection: 0
    });
  }
  return SelectWrapperComponent;
})();
(() => {
  ( false) && 0;
})();

/* eslint-disable @typescript-eslint/ban-types */
const SWITCH_VALUE_ACCESSOR = {
  provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NG_VALUE_ACCESSOR,
  useExisting: (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => SwitchComponent),
  multi: true
};
let SwitchComponent = /*#__PURE__*/(() => {
  class SwitchComponent {
    constructor() {
      this.label = null;
      this.showIcon = false;
      this.size = 'medium';
      this.color = null;
    }
    registerOnChange(fn) {
      this.onChange = fn;
    }
    registerOnTouched(fn) {
      this.onTouched = fn;
    }
    setDisabledState(disabled) {
      this.disabled = disabled;
    }
    writeValue(checked) {
      this.checked = checked;
    }
    /* ControlValueAccessor - END */
    onKeyupEnter() {
      if (!this.disabled) {
        this.checked = !this.checked;
        this.onChange(this.checked);
        this.onTouched();
      }
    }
    change(event) {
      const checked = event.target.checked;
      this.checked = checked;
      this.onChange(this.checked);
      this.onTouched();
    }
    static #_ = this.ɵfac = function SwitchComponent_Factory(t) {
      return new (t || SwitchComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: SwitchComponent,
      selectors: [["sie-switch"]],
      hostBindings: function SwitchComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function SwitchComponent_keyup_enter_HostBindingHandler() {
            return ctx.onKeyupEnter();
          });
        }
      },
      inputs: {
        switchId: "switchId",
        label: "label",
        showIcon: "showIcon",
        size: "size",
        color: "color"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([SWITCH_VALUE_ACCESSOR])],
      decls: 5,
      vars: 8,
      consts: [[1, "switch", 3, "ngClass"], ["type", "checkbox", 1, "switch__checkbox", 3, "change", "id", "checked", "disabled"], ["sieBackgroundColor", "", 1, "switch__handle", 3, "backgroundColor", "for"], ["class", "switch__icon", 4, "ngIf"], ["class", "switch__label", 3, "for", 4, "ngIf"], [1, "switch__icon"], [1, "switch__label", 3, "for"]],
      template: function SwitchComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "input", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function SwitchComponent_Template_input_change_1_listener($event) {
            return ctx.change($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "label", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, SwitchComponent_span_3_Template, 1, 0, "span", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, SwitchComponent_label_4_Template, 2, 2, "label", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "switch--" + ctx.size);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx.switchId)("checked", ctx.checked)("disabled", ctx.disabled);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("backgroundColor", ctx.color)("for", ctx.switchId);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showIcon);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.label);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_3__/* .BackgroundColorDirective */ .D$],
      styles: [".switch__checkbox[_ngcontent-%COMP%]:focus:not(:focus-visible){outline:0!important}"]
    });
  }
  return SwitchComponent;
})();
(() => {
  ( false) && 0;
})();
let CheckboxDirective = /*#__PURE__*/(() => {
  class CheckboxDirective {
    constructor() {
      this.hostClasses = 'inputGroup__checkbox';
    }
    static #_ = this.ɵfac = function CheckboxDirective_Factory(t) {
      return new (t || CheckboxDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: CheckboxDirective,
      selectors: [["", "sieCheckbox", ""]],
      hostVars: 2,
      hostBindings: function CheckboxDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return CheckboxDirective;
})();
(() => {
  ( false) && 0;
})();
let InputTextDirective = /*#__PURE__*/(() => {
  class InputTextDirective {
    constructor() {
      this.hostClasses = 'inputGroup__textInput';
    }
    static #_ = this.ɵfac = function InputTextDirective_Factory(t) {
      return new (t || InputTextDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: InputTextDirective,
      selectors: [["", "sieInputText", ""]],
      hostVars: 2,
      hostBindings: function InputTextDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return InputTextDirective;
})();
(() => {
  ( false) && 0;
})();
let RadioButtonDirective = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class RadioButtonDirective {
    constructor() {
      this.hostClasses = 'inputGroup__radioButton';
    }
    static #_ = this.ɵfac = function RadioButtonDirective_Factory(t) {
      return new (t || RadioButtonDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */i0.ɵɵdefineDirective({
      type: RadioButtonDirective,
      selectors: [["", "sieRadioButton", ""]],
      hostVars: 2,
      hostBindings: function RadioButtonDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      }
    });
  }
  return RadioButtonDirective;
})()));
(() => {
  ( false) && 0;
})();
let SelectDirective = /*#__PURE__*/(() => {
  class SelectDirective {
    constructor() {
      this.hostClasses = 'inputGroup__select';
    }
    static #_ = this.ɵfac = function SelectDirective_Factory(t) {
      return new (t || SelectDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: SelectDirective,
      selectors: [["", "sieSelect", ""]],
      hostVars: 2,
      hostBindings: function SelectDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return SelectDirective;
})();
(() => {
  ( false) && 0;
})();
let TextareaDirective = /*#__PURE__*/(() => {
  class TextareaDirective {
    constructor() {
      this.hostClasses = 'inputGroup__textarea';
    }
    static #_ = this.ɵfac = function TextareaDirective_Factory(t) {
      return new (t || TextareaDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: TextareaDirective,
      selectors: [["", "sieTextarea", ""]],
      hostVars: 2,
      hostBindings: function TextareaDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return TextareaDirective;
})();
(() => {
  ( false) && 0;
})();
let SieFormModule = /*#__PURE__*/(() => {
  class SieFormModule {
    static #_ = this.ɵfac = function SieFormModule_Factory(t) {
      return new (t || SieFormModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieFormModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_3__/* .SieColorModule */ .$e]
    });
  }
  return SieFormModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-form.mjs.map

/***/ }),

/***/ 99710:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ IconComponent),
/* harmony export */   j: () => (/* binding */ SieIconModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10463);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53081);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35782);






const _c0 = (a0, a1, a2, a3) => [a0, a1, a2, a3];
function IconComponent_span_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 1);
  }
  if (rf & 2) {
    let tmp_1_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction4"](3, _c0, ctx_r0.icon, (tmp_1_0 = ctx_r0.type) !== null && tmp_1_0 !== undefined ? tmp_1_0 : "", ctx_r0.rotate ? "is-rotated-" + ctx_r0.rotate : "", ctx_r0.flip ? "is-flipped-" + ctx_r0.flip : ""))("backgroundColor", ctx_r0.backgroundColor)("color", ctx_r0.color);
  }
}
let IconComponent = /*#__PURE__*/(() => {
  class IconComponent {
    constructor() {
      this.type = null;
      this.rotate = null;
      this.flip = null;
      this.backgroundColor = null;
      this.color = null;
    }
    static #_ = this.ɵfac = function IconComponent_Factory(t) {
      return new (t || IconComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: IconComponent,
      selectors: [["sie-icon"]],
      inputs: {
        icon: "icon",
        type: "type",
        rotate: "rotate",
        flip: "flip",
        backgroundColor: "backgroundColor",
        color: "color"
      },
      decls: 1,
      vars: 1,
      consts: [["class", "span iconUxt", "aria-hidden", "true", "sieBackgroundColor", "", "sieColor", "", 3, "ngClass", "backgroundColor", "color", 4, "ngIf"], ["aria-hidden", "true", "sieBackgroundColor", "", "sieColor", "", 1, "span", "iconUxt", 3, "ngClass", "backgroundColor", "color"]],
      template: function IconComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, IconComponent_span_0_Template, 1, 8, "span", 0);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.icon);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .BackgroundColorDirective */ .D$, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .ColorDirective */ .Fy],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return IconComponent;
})();
(() => {
  ( false) && 0;
})();
let SieIconModule = /*#__PURE__*/(() => {
  class SieIconModule {
    static #_ = this.ɵfac = function SieIconModule_Factory(t) {
      return new (t || SieIconModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieIconModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .SieColorModule */ .$e]
    });
  }
  return SieIconModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-icon.mjs.map

/***/ })

}]);