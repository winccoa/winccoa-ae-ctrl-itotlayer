"use strict";
(self["webpackChunkwidgets_label"] = self["webpackChunkwidgets_label"] || []).push([[253,869],{

/***/ 91253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  S2: () => (/* reexport */ DashboardWidgetsLabelModule)
});

// UNUSED EXPORTS: LabelContainerComponent, LabelSettingsComponent

// EXTERNAL MODULE: consume shared module (default) @angular/common@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/common/fesm2022/common.mjs)
var common_mjs_ = __webpack_require__(75826);
// EXTERNAL MODULE: consume shared module (default) @angular/core@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/core/fesm2022/core.mjs)
var core_mjs_ = __webpack_require__(87161);
// EXTERNAL MODULE: consume shared module (default) @angular/forms@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/forms/fesm2022/forms.mjs)
var forms_mjs_ = __webpack_require__(24269);
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/dashboard-widgets-base@* (strict) (fallback: ./libs/dashboard/widgets/base/src/index.ts)
var index_ts_ = __webpack_require__(77721);
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/settings-form-elements@* (strict) (fallback: ./libs/settings-form-elements/src/index.ts)
var src_index_ts_ = __webpack_require__(14854);
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/shared@* (strict) (fallback: ./libs/shared/src/index.ts)
var shared_src_index_ts_ = __webpack_require__(94020);
// EXTERNAL MODULE: consume shared module (default) @ngx-translate/core@^15.0.0 (singleton) (fallback: ../../node_modules/@ngx-translate/core/dist/fesm2022/ngx-translate-core.mjs)
var ngx_translate_core_mjs_ = __webpack_require__(38229);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-badge.mjs
var siemens_di_pa_sw_reusable_components_uxt_badge = __webpack_require__(86870);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-button.mjs
var siemens_di_pa_sw_reusable_components_uxt_button = __webpack_require__(15695);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-card.mjs
var siemens_di_pa_sw_reusable_components_uxt_card = __webpack_require__(12099);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-container.mjs
var siemens_di_pa_sw_reusable_components_uxt_container = __webpack_require__(60491);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-content-header.mjs
var siemens_di_pa_sw_reusable_components_uxt_content_header = __webpack_require__(47869);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-form.mjs
var siemens_di_pa_sw_reusable_components_uxt_form = __webpack_require__(36655);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-icon.mjs
var siemens_di_pa_sw_reusable_components_uxt_icon = __webpack_require__(48573);
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/models@* (strict) (fallback: ./libs/models/src/index.ts)
var models_src_index_ts_ = __webpack_require__(66013);
;// CONCATENATED MODULE: ./libs/dashboard/widgets/label/src/lib/createWidgetSettings.ts

const createWidgetSettings = function (data, widgetInformation) {
  return {
    type: models_src_index_ts_.DashboardWidgetType.Label,
    ...widgetInformation.defaultSettings,
    data
  };
};
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/abstract-services@* (strict) (fallback: ./libs/abstract-services/src/index.ts)
var abstract_services_src_index_ts_ = __webpack_require__(35277);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/combineLatest.js
var combineLatest = __webpack_require__(23016);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/map.js
var map = __webpack_require__(47946);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/switchMap.js
var switchMap = __webpack_require__(25700);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/of.js
var of = __webpack_require__(8480);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/take.js
var take = __webpack_require__(40995);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/delay.js + 2 modules
var delay = __webpack_require__(93745);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/filter.js
var filter = __webpack_require__(19249);
;// CONCATENATED MODULE: ./libs/dashboard/widgets/label/src/lib/label-ui/label-ui.component.ts






function LabelUiComponent_sie_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "sie-icon", 4);
  }
  if (rf & 2) {
    const ctx_r0 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("icon", ctx_r0.settings.icon);
  }
}
const _c0 = function (a0, a1) {
  return {
    color: a0,
    "flex-direction": a1
  };
};
const _c1 = function (a0) {
  return {
    order: a0
  };
};
let LabelUiComponent = /*#__PURE__*/(() => {
  class LabelUiComponent {
    // eslint-disable-next-line @angular-eslint/no-input-rename
    set _alertFontColor(color) {
      this.alertFontColor = color;
      this.setFontColor();
    }
    // eslint-disable-next-line @angular-eslint/no-input-rename
    set _settings(settings) {
      this.settings = settings;
      this.setFontColor();
      if (this.directiveList != undefined) {
        this.onWindowResize();
      }
    }
    set resize(value) {
      if (this.directiveList != undefined) {
        this.onWindowResize();
      }
    }
    set value(value) {
      this._value = value;
      if (this.directiveList != undefined) {
        this.onWindowResize();
      }
    }
    set color(color) {
      this._color = color;
      this.setFontColor();
    }
    onWindowResize() {
      this.directiveList.forEach(directive => directive.onWindowResize());
    }
    setFontColor() {
      this.fontColor = this.alertFontColor ? this.alertFontColor : this._color;
    }
    static #_ = this.ɵfac = function LabelUiComponent_Factory(t) {
      return new (t || LabelUiComponent)();
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core_mjs_["ɵɵdefineComponent"]({
      type: LabelUiComponent,
      selectors: [["wui-label"]],
      viewQuery: function LabelUiComponent_Query(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵviewQuery"](shared_src_index_ts_.FittextDirective, 5);
        }
        if (rf & 2) {
          let _t;
          core_mjs_["ɵɵqueryRefresh"](_t = core_mjs_["ɵɵloadQuery"]()) && (ctx.directiveList = _t);
        }
      },
      inputs: {
        postfix: "postfix",
        prefix: "prefix",
        _alertFontColor: ["alertFontColor", "_alertFontColor"],
        _settings: ["settings", "_settings"],
        resize: "resize",
        value: "value",
        color: "color"
      },
      decls: 5,
      vars: 15,
      consts: [[1, "content", 3, "ngStyle"], ["data-cy", "label_icon_container", "wuiFittext", "", 1, "content__fittext", 3, "minFontSize", "compression", "ngStyle"], [3, "icon", 4, "ngIf"], ["wuiFittext", "", 1, "content__fittext", 3, "minFontSize", "compression"], [3, "icon"]],
      template: function LabelUiComponent_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          core_mjs_["ɵɵtemplate"](2, LabelUiComponent_sie_icon_2_Template, 1, 1, "sie-icon", 2);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](3, "div", 3);
          core_mjs_["ɵɵtext"](4);
          core_mjs_["ɵɵelementEnd"]()();
        }
        if (rf & 2) {
          core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction2"](10, _c0, ctx.fontColor ? ctx.fontColor : "rgb(var(--color-base000))", (ctx.settings == null ? null : ctx.settings.iconAlign) ? "row" : "column"));
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("minFontSize", 1)("compression", (ctx.settings == null ? null : ctx.settings.iconSizeFactor) ? ctx.settings.iconSizeFactor : 1)("ngStyle", core_mjs_["ɵɵpureFunction1"](13, _c1, (ctx.settings == null ? null : ctx.settings.iconPosition) ? ctx.settings.iconPosition : 0));
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.settings == null ? null : ctx.settings.icon);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("minFontSize", 1)("compression", (ctx.settings == null ? null : ctx.settings.fontSizeFactor) ? (ctx.settings == null ? null : ctx.settings.icon) ? (1 - ctx.settings.iconSizeFactor) * ctx.settings.fontSizeFactor : ctx.settings.fontSizeFactor : 1);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵtextInterpolate3"](" ", ctx.prefix, "", ctx._value, "", ctx.postfix, " ");
        }
      },
      dependencies: [common_mjs_.NgIf, common_mjs_.NgStyle, siemens_di_pa_sw_reusable_components_uxt_icon/* IconComponent */.o, shared_src_index_ts_.FittextDirective],
      styles: [".content[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 100%;\n  width: 100%;\n}\n.content__fittext[_ngcontent-%COMP%] {\n  display: flex;\n  white-space: nowrap;\n}"],
      changeDetection: 0
    });
  }
  return LabelUiComponent;
})();
;// CONCATENATED MODULE: ./libs/dashboard/widgets/label/src/lib/label-container/label-container.component.ts










function LabelContainerComponent_wui_label_0_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "wui-label", 2);
    core_mjs_["ɵɵpipe"](1, "stringFormat");
    core_mjs_["ɵɵpipe"](2, "async");
    core_mjs_["ɵɵpipe"](3, "async");
    core_mjs_["ɵɵpipe"](4, "async");
    core_mjs_["ɵɵpipe"](5, "async");
  }
  if (rf & 2) {
    const ctx_r0 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("value", core_mjs_["ɵɵpipeBind2"](1, 7, core_mjs_["ɵɵpipeBind1"](2, 10, ctx_r0.value$), ctx_r0.settings.formatSettings == null ? null : ctx_r0.settings.formatSettings.value))("alertFontColor", core_mjs_["ɵɵpipeBind1"](3, 12, ctx_r0.alertFontColor$))("settings", ctx_r0.settings)("resize", ctx_r0.resize)("prefix", ctx_r0.prefix)("postfix", core_mjs_["ɵɵpipeBind1"](4, 14, ctx_r0.postfix$))("color", core_mjs_["ɵɵpipeBind1"](5, 16, ctx_r0.color$));
  }
}
function LabelContainerComponent_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "wui-label", 2);
    core_mjs_["ɵɵpipe"](1, "async");
    core_mjs_["ɵɵpipe"](2, "async");
    core_mjs_["ɵɵpipe"](3, "async");
  }
  if (rf & 2) {
    const ctx_r2 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("value", "")("alertFontColor", core_mjs_["ɵɵpipeBind1"](1, 7, ctx_r2.alertFontColor$))("settings", ctx_r2.settings)("resize", ctx_r2.resize)("prefix", ctx_r2.prefix)("postfix", core_mjs_["ɵɵpipeBind1"](2, 9, ctx_r2.postfix$))("color", core_mjs_["ɵɵpipeBind1"](3, 11, ctx_r2.color$));
  }
}
let LabelContainerComponent = /*#__PURE__*/(() => {
  class LabelContainerComponent extends index_ts_.DashboardWidgetComponent {
    constructor(oaRxJsFacade, oaRxJsService, multiLangTextService, themeService) {
      super();
      this.oaRxJsFacade = oaRxJsFacade;
      this.oaRxJsService = oaRxJsService;
      this.multiLangTextService = multiLangTextService;
      this.themeService = themeService;
      this.subscriptions = [];
    }
    ngOnDestroy() {
      this.subscriptions.forEach(sub => sub.unsubscribe());
    }
    ngOnInit() {
      this.setupSettingsSubscription();
      this.color$ = (0,combineLatest/* combineLatest */.a)([this.themeService.currentTheme$, this.settings$]).pipe((0,map/* map */.U)(() => this.themeService.determineColor(this.settings?.fontColor)));
    }
    connectToAlertColor() {
      if (this.settings !== undefined && this.isData(this.settings.data)) {
        this.frontColorPath = this.settings.data.dataPath + models_src_index_ts_.ALERT_PATH_COLOR;
        this.alertFontColor$ = null;
        this.alertFontColor$ = this.oaRxJsFacade.dpConnect(this.frontColorPath).pipe((0,switchMap/* switchMap */.w)(value => {
          if (!value) {
            return (0,of.of)(null);
          }
          return this.oaRxJsService.colorToHtml(value);
        }));
      }
    }
    connectToData() {
      if (this.settings !== undefined && this.isData(this.settings.data) && this.settings.data.dataPath) {
        this.value$ = null;
        this.value$ = this.oaRxJsFacade.dpConnect(this.settings.data.dataPath);
        // Do not use the same subscription with take(1) for finishloading
        // otherwise we may unsubscribe before the value arrives
        this.oaRxJsFacade.getDatabyDataPath(this.settings.data.dataPath).pipe((0,take/* take */.q)(1), (0,delay/* delay */.g)(150)).subscribe(() => this.finishLoading());
      } else {
        this.value$ = null;
      }
    }
    disconnectFromExistingsDp() {
      this.value$ = null;
      this.alertFontColor$ = null;
    }
    getPostfix() {
      if (this.settings?.queryPostfix && this.isData(this.settings.data) && this.settings.data.dataPath) {
        return this.oaRxJsService.dpGetUnit(this.settings.data.dataPath);
      } else {
        const postfix = this.settings?.valuePostfix;
        return (0,of.of)(this.multiLangTextService.getText(postfix));
      }
    }
    getPrefix() {
      return this.multiLangTextService.getText(this.settings?.valuePrefix);
    }
    isData(data) {
      return data && data.dataPath !== undefined;
    }
    setupSettingsSubscription() {
      const sub = this.settings$.subscribe(settings => {
        if (settings) {
          this.startLoading();
          this.prefix = this.getPrefix();
          this.postfix$ = this.getPostfix();
          this.updateWidget();
        }
      });
      this.subscriptions.push(sub);
    }
    updateWidget() {
      if (this.settings !== undefined && this.isData(this.settings.data) && this.settings.data.dataPath) {
        this.connectToData();
        if (this.settings?.generalDataSettings?.alert?.queryConfig && (!this.alertFontColor$ || this.frontColorPath !== this.settings.data.dataPath + models_src_index_ts_.ALERT_PATH_COLOR)) {
          this.connectToAlertColor();
        } else if (!this.settings?.generalDataSettings?.alert?.queryConfig && this.alertFontColor$) {
          this.alertFontColor$ = null;
        }
        if (this.settings.queryPostfix || this.settings.formatSettings?.type == models_src_index_ts_.FormatSettingsType.Oa) {
          this.oaRxJsFacade.getConfigs(this.settings.data.dataPath).pipe((0,filter/* filter */.h)(value => value !== undefined), (0,take/* take */.q)(1)).subscribe(value => {
            if (value) {
              if (this.settings?.queryPostfix) {
                this.settings.valuePostfix = value.unit;
              }
              if (this.settings?.formatSettings?.type == models_src_index_ts_.FormatSettingsType.Oa) {
                this.settings.formatSettings.value = value.format;
              }
            }
          });
        }
      } else {
        this.disconnectFromExistingsDp();
        this.finishLoading();
      }
    }
    static #_ = this.ɵfac = function LabelContainerComponent_Factory(t) {
      return new (t || LabelContainerComponent)(core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.OaRxJsFacade), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.OaRxJsService), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.MultiLangTextService), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.ThemeSwitcherService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core_mjs_["ɵɵdefineComponent"]({
      type: LabelContainerComponent,
      selectors: [["wui-label-container"]],
      features: [core_mjs_["ɵɵProvidersFeature"]([LabelUiComponent]), core_mjs_["ɵɵInheritDefinitionFeature"]],
      decls: 3,
      vars: 2,
      consts: [[3, "value", "alertFontColor", "settings", "resize", "prefix", "postfix", "color", 4, "ngIf", "ngIfElse"], ["withoutDatapath", ""], [3, "value", "alertFontColor", "settings", "resize", "prefix", "postfix", "color"]],
      template: function LabelContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵtemplate"](0, LabelContainerComponent_wui_label_0_Template, 6, 18, "wui-label", 0);
          core_mjs_["ɵɵtemplate"](1, LabelContainerComponent_ng_template_1_Template, 4, 13, "ng-template", null, 1, core_mjs_["ɵɵtemplateRefExtractor"]);
        }
        if (rf & 2) {
          const _r1 = core_mjs_["ɵɵreference"](2);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.value$ !== null)("ngIfElse", _r1);
        }
      },
      dependencies: [common_mjs_.NgIf, LabelUiComponent, common_mjs_.AsyncPipe, src_index_ts_.StringFormatPipe],
      styles: ["[_nghost-%COMP%] {\n  width: 100%;\n  height: 100%;\n}"]
    });
  }
  return LabelContainerComponent;
})();
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/debounceTime.js
var debounceTime = __webpack_require__(59221);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/startWith.js
var startWith = __webpack_require__(56371);
;// CONCATENATED MODULE: ./libs/dashboard/widgets/label/src/lib/label-settings/label-settings.component.ts






























function LabelSettingsComponent_input_35_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "input", 46);
  }
  if (rf & 2) {
    const ctx_r0 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("value", ctx_r0.queriedPostfix);
  }
}
function LabelSettingsComponent_ng_template_36_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "wui-multi-lang-text", 47);
  }
}
function LabelSettingsComponent_wui_checkbox_40_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "wui-checkbox", 48);
  }
  if (rf & 2) {
    const ctx_r3 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r3.InputGroupSize.Medium);
  }
}
function LabelSettingsComponent_span_58_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "span", 49);
  }
  if (rf & 2) {
    const ctx_r4 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵclassMapInterpolate1"]("iconUxt ", ctx_r4.icon, "");
  }
}
function LabelSettingsComponent_div_59_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "div", 50);
  }
}
const label_settings_component_c0 = function (a0) {
  return [a0];
};
let LabelSettingsComponent = /*#__PURE__*/(() => {
  class LabelSettingsComponent extends index_ts_.DashboardWidgetSettingsComponent {
    constructor(formBuilder, oaRxJsFacade, dashboardFacade, contextRegionFacade) {
      super(dashboardFacade, contextRegionFacade);
      this.formBuilder = formBuilder;
      this.oaRxJsFacade = oaRxJsFacade;
      this.ButtonType = models_src_index_ts_.ButtonType;
      this.Color = models_src_index_ts_.Color;
      this.ContainerType = models_src_index_ts_.ContainerType;
      this.Icon = models_src_index_ts_.Icon;
      this.InputGroupSize = models_src_index_ts_.InputGroupSize;
      this.queriedPostfix = '';
      this.queryAlertColor = models_src_index_ts_.Color.Error;
      this.queryAlertIcon = models_src_index_ts_.Icon.CancelCircle;
      this.queryPostfixDisabled = false;
    }
    get dataPath() {
      return this.settingsForm.get('data')?.value['dataPath'];
    }
    get dataType() {
      return this.settingsForm.get('data')?.value['dataType'];
    }
    get fontSizeFactor() {
      return this.settingsForm.get('fontSizeFactor')?.value;
    }
    get icon() {
      return this.settingsForm.get('icon')?.value;
    }
    get iconAlign() {
      return this.settingsForm.get('iconAlign')?.value;
    }
    get iconPosition() {
      return this.settingsForm.get('iconPosition')?.value;
    }
    get iconSizeFactor() {
      return this.settingsForm.get('iconSizeFactor')?.value;
    }
    get queryPostfix() {
      return this.settingsForm.get('queryPostfix')?.value;
    }
    get valuePostfix() {
      return this.settingsForm.get('valuePostfix')?.value;
    }
    set dataPath(path) {
      this.settingsForm.get('data')?.patchValue({
        dataPath: path
      });
    }
    set fontSizeFactor(factor) {
      const fontSizeFactor = this.settingsForm.get('fontSizeFactor');
      if (fontSizeFactor !== null) {
        if (fontSizeFactor.value !== factor) {
          fontSizeFactor.markAsDirty();
        }
        fontSizeFactor.patchValue(factor);
      }
    }
    set icon(icon) {
      this.settingsForm.get('icon')?.patchValue(icon);
    }
    set iconAlign(factor) {
      const iconAlign = this.settingsForm.get('iconAlign');
      if (iconAlign !== null) {
        if (iconAlign.value !== factor) {
          iconAlign.markAsDirty();
        }
        iconAlign.patchValue(factor);
      }
    }
    set iconPosition(factor) {
      const iconPosition = this.settingsForm.get('iconPosition');
      if (iconPosition !== null) {
        if (iconPosition.value !== factor) {
          iconPosition.markAsDirty();
        }
        iconPosition.patchValue(factor);
      }
    }
    set iconSizeFactor(factor) {
      const iconSizeFactor = this.settingsForm.get('iconSizeFactor');
      if (iconSizeFactor !== null) {
        if (iconSizeFactor.value !== factor) {
          iconSizeFactor.markAsDirty();
        }
        iconSizeFactor.patchValue(factor);
      }
    }
    set queryPostfix(value) {
      this.settingsForm.get('queryPostfix')?.patchValue(value);
    }
    clearIcon() {
      this.settingsForm.get('icon')?.markAsDirty();
      this.icon = '';
    }
    formInit() {
      const baseColor = 'rgb(var(--color-base000))';
      const fontColorControl = {
        color: this.settings?.fontColor?.color ?? this.settings?.fontColor ?? baseColor,
        useDifferentColors: this.settings?.fontColor?.useDifferentColors ?? false,
        darkModeColor: this.settings?.fontColor?.darkModeColor ?? baseColor
      };
      this.settingsForm = this.formBuilder.nonNullable.group({
        data: [this.settings?.data ?? {
          dataPath: null,
          dataType: null
        }],
        generalSettings: [this.settings?.generalSettings ?? this.getGeneralSetting()],
        generalDataSettings: [this.settings?.generalDataSettings ?? null],
        valuePrefix: [this.settings?.valuePrefix ?? null],
        valuePostfix: [this.settings?.valuePostfix ?? null],
        queryPostfix: [this.settings?.queryPostfix ?? true],
        formatSettings: this.setFormatSettingsFormGroup(this.settings?.formatSettings),
        fontColor: fontColorControl,
        fontSizeFactor: [this.settings?.fontSizeFactor ?? 0.75],
        iconSizeFactor: [this.settings?.iconSizeFactor ?? 0.5],
        icon: [this.settings?.icon ?? ''],
        iconAlign: [this.settings?.iconAlign ?? 0],
        iconPosition: [this.settings?.iconPosition ?? 0]
      });
    }
    ngOnInit() {
      this.formInit();
      this.groupControls();
      if (this.settings) {
        this.onQueryPostfixChanges();
        this.onDataPathCanges();
      }
      this.initialFormValue = this.settingsForm.value;
      this.data$ = this.getDataObservable(this.settingsForm);
      // create icon array for Icon selector
      this.iconArray = Object.keys(this.Icon).map(o => {
        return {
          key: o,
          value: this.Icon[o]
        };
      });
      this.subscriptions.push(this.settingsForm.valueChanges.pipe((0,debounceTime/* debounceTime */.b)(500)).subscribe(settings => {
        if (!this.unsavedChanges(settings, this.initialFormValue)) this.settingsForm.markAsPristine();
        this.emitSettings(settings);
        this.updateFormState(this.settingsForm);
      }));
      this.resetFromState(this.settingsForm);
      this.updateFormState(this.settingsForm);
      this.emitSettings(this.settingsForm.value);
      super.ngOnInit();
    }
    onDataPathCanges() {
      const dataControl = this.settingsForm.get('data');
      if (dataControl !== null) {
        const subscription = dataControl.valueChanges.pipe((0,startWith/* startWith */.O)(dataControl.value)).subscribe(({
          dataPath
        }) => {
          this.queryPostfixDisabled = !dataPath;
          if (this.queryPostfixDisabled) {
            this.queryPostfix = false;
          } else {
            if (this.queryPostfix) {
              this.queryPostfix = false;
              this.queryPostfix = true;
            }
          }
          if (dataPath && dataPath != null) {
            this.oaRxJsFacade.fetchConfig(dataPath);
          }
        });
        this.subscriptions.push(subscription);
      }
    }
    onIconPickerDefaultSelect(icon) {
      this.settingsForm.get('icon')?.markAsDirty();
      this.icon = icon;
    }
    onQueryPostfixChanges() {
      const queryPostfixControl = this.settingsForm.get('queryPostfix');
      if (queryPostfixControl !== null) {
        const subscription = queryPostfixControl.valueChanges.pipe((0,startWith/* startWith */.O)(this.queryPostfix)).subscribe(() => {
          this.oaRxJsFacade.getConfigs(this.dataPath).pipe((0,filter/* filter */.h)(value => value !== undefined), (0,take/* take */.q)(1)).subscribe(value => {
            if (value) {
              this.queriedPostfix = value.unit;
            }
          });
        });
        this.subscriptions.push(subscription);
      }
    }
    groupControls() {
      this.fontColorControl = this.settingsForm.get('fontColor');
      this.fontSizeFactorControl = this.settingsForm.get('fontSizeFactor');
      this.iconControl = this.settingsForm.get('icon');
      this.iconPositionControl = this.settingsForm.get('iconPosition');
      this.iconSizeFactorControl = this.settingsForm.get('iconSizeFactor');
      this.valuePostfixControl = this.settingsForm.get('valuePostfix');
      this.widgetDataGroup = [this.settingsForm.get('data'), this.settingsForm.get('generalDataSettings')];
      this.widgetOptionsGroup = [this.settingsForm.get('valuePrefix'), this.valuePostfixControl, this.settingsForm.get('queryPostfix'), this.fontColorControl, this.fontSizeFactorControl, this.iconControl, this.iconSizeFactorControl, this.iconPositionControl, this.settingsForm.get('iconAlign')];
    }
    static #_ = this.ɵfac = function LabelSettingsComponent_Factory(t) {
      return new (t || LabelSettingsComponent)(core_mjs_["ɵɵdirectiveInject"](forms_mjs_.UntypedFormBuilder), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.OaRxJsFacade), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.DashboardFacade), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.ContextRegionFacade));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core_mjs_["ɵɵdefineComponent"]({
      type: LabelSettingsComponent,
      selectors: [["wui-label-settings"]],
      features: [core_mjs_["ɵɵInheritDefinitionFeature"]],
      decls: 82,
      vars: 128,
      consts: [[3, "formGroup"], [3, "type", "isInvalid", "isDirty"], ["formControlName", "generalSettings", 3, "data"], [3, "type", "collapsed", "isDirty"], ["for", "data", 3, "size", "isDirty", "isInvalid", "isTouched"], ["data-cy", "input_label_settings_datasource", "formControlName", "data", "id", "data", 3, "dataTypes"], ["for", "generalDataSettings", 3, "size"], ["formControlName", "generalDataSettings", "id", "generalDataSettings", 3, "dataPath"], ["data-cy", "input_label_settings_prefix", "label", "WUI_Dashboard.Widget.Prefix", "description", "WUI_Dashboard.Widget.PrefixDescription", "for", "valuePrefix", 3, "size", "isDirty", "isInvalid", "isTouched"], ["formControlName", "valuePrefix", "id", "valuePrefix"], ["data-cy", "input_label_settings_postfix", "omitInputGroup", "true", "for", "valuePostfix", 3, "size"], ["label", "WUI_Dashboard.Widget.Postfix", "description", "WUI_Dashboard.Widget.PostfixDescription", "for", "valuePostfix", 3, "size", "isDirty", "isRequired"], ["sieInputText", "", "type", "text", "id", "valuePostfix", "readOnly", "true", 3, "value", 4, "ngIf", "ngIfElse"], ["multiLang", ""], ["for", "queryPostfix", 3, "size"], ["label", "WUI_Dashboard.Widget.Detect.PostfixDescription", "data-cy", "checkbox_label_settings_postFix", "formControlName", "queryPostfix", "for", "queryPostfix", 3, "size", 4, "ngIf"], ["formControlName", "formatSettings", "id", "formatSettings", 3, "dataPath", "dataType", "validatorErrors"], ["omitInputGroup", "true"], ["formControlName", "fontColor", 3, "serieIndex"], ["label", "WUI_Dashboard.Widget.FontSize", "for", "fontSizeFactor", 3, "size", "isDirty"], ["data-cy", "button_label_settings_font_size05", "id", "small_font", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "visibilityShown", "btn_icon_small"], ["data-cy", "button_label_settings_font_size075", "id", "medium_font", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "visibilityShown", "btn_icon_medium"], ["data-cy", "button_label_settings_font_size1", "id", "large_font", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "visibilityShown", "btn_icon_large"], ["label", "WUI_Dashboard.Widget.Icon", "for", "icon", 3, "size", "isDirty"], [2, "display", "flex", "flex-direction", "row"], ["data-cy", "button_label_settings_icon", "wuiIconSelector", "", "isPosition", "top", "id", "icon", "type", "button", 1, "button", "button--secondary", "has-icon-only", "button--nomargin", "button--icon-selector", 3, "isIcon", "iconSelect"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], ["style", "height: 14px; width: 24px", "aria-hidden", "true", 4, "ngIf"], ["data-cy", "button_label_settings_icon_clear", "type", "button", 1, "button", "button--ghost", "has-icon-only", "button--nomargin", 3, "click"], ["aria-hidden", "true", 1, "iconUxt", "cancelCircle"], ["label", "WUI_Dashboard.Widget.IconPosition", "for", "iconPosition", 3, "size", "isDirty"], ["data-cy", "button_label_settings_icon_position0", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "import", "is-rotated-270"], ["data-cy", "button_label_settings_icon_position1", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "import", "is-rotated-90"], ["data-cy", "button_label_settings_icon_position2", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "import", "is-rotated-0"], ["data-cy", "button_label_settings_icon_position3", 3, "type", "iconOnly", "activated", "click"], ["aria-hidden", "true", 1, "iconUxt", "import", "is-rotated-180"], ["label", "WUI_Dashboard.Widget.IconSize", "for", "iconSizeFactor", 3, "size", "isDirty"], ["data-cy", "button_label_settings_icon_size05", "id", "small_icon", 3, "type", "iconOnly", "activated", "click"], ["data-cy", "button_label_settings_icon_size075", "id", "medium_icon", 3, "type", "iconOnly", "activated", "click"], ["data-cy", "button_label_settings_icon_size1", "id", "large_icon", 3, "type", "iconOnly", "activated", "click"], ["sieInputText", "", "type", "text", "id", "valuePostfix", "readOnly", "true", 3, "value"], ["formControlName", "valuePostfix"], ["label", "WUI_Dashboard.Widget.Detect.PostfixDescription", "data-cy", "checkbox_label_settings_postFix", "formControlName", "queryPostfix", "for", "queryPostfix", 3, "size"], ["aria-hidden", "true"], ["aria-hidden", "true", 2, "height", "14px", "width", "24px"]],
      template: function LabelSettingsComponent_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵelementStart"](0, "wui-form", 0)(1, "wui-container-group")(2, "wui-container", 1);
          core_mjs_["ɵɵpipe"](3, "isInvalid");
          core_mjs_["ɵɵpipe"](4, "isDirty");
          core_mjs_["ɵɵelementStart"](5, "wui-container-title");
          core_mjs_["ɵɵtext"](6);
          core_mjs_["ɵɵpipe"](7, "translate");
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](8, "wui-container-content");
          core_mjs_["ɵɵelement"](9, "wui-general-settings", 2);
          core_mjs_["ɵɵpipe"](10, "async");
          core_mjs_["ɵɵelementEnd"]()();
          core_mjs_["ɵɵelementStart"](11, "wui-container", 3);
          core_mjs_["ɵɵpipe"](12, "isDirty");
          core_mjs_["ɵɵelementStart"](13, "wui-container-title");
          core_mjs_["ɵɵtext"](14);
          core_mjs_["ɵɵpipe"](15, "translate");
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](16, "wui-container-content")(17, "wui-form-group", 4);
          core_mjs_["ɵɵpipe"](18, "isDirty");
          core_mjs_["ɵɵelement"](19, "wui-data-selector-input", 5);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](20, "wui-form-group", 6);
          core_mjs_["ɵɵelement"](21, "wui-general-data-settings", 7);
          core_mjs_["ɵɵelementEnd"]()()();
          core_mjs_["ɵɵelementStart"](22, "wui-container", 3);
          core_mjs_["ɵɵpipe"](23, "isDirty");
          core_mjs_["ɵɵelementStart"](24, "wui-container-title");
          core_mjs_["ɵɵtext"](25);
          core_mjs_["ɵɵpipe"](26, "translate");
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](27, "wui-container-content")(28, "wui-form-group", 8);
          core_mjs_["ɵɵpipe"](29, "isDirty");
          core_mjs_["ɵɵelement"](30, "wui-multi-lang-text", 9);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](31, "wui-form-group", 10)(32, "wui-input-group", 11);
          core_mjs_["ɵɵpipe"](33, "isDirty");
          core_mjs_["ɵɵpipe"](34, "hasRequiredField");
          core_mjs_["ɵɵtemplate"](35, LabelSettingsComponent_input_35_Template, 1, 1, "input", 12);
          core_mjs_["ɵɵtemplate"](36, LabelSettingsComponent_ng_template_36_Template, 1, 0, "ng-template", null, 13, core_mjs_["ɵɵtemplateRefExtractor"]);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelement"](38, "sie-form-group-line-break");
          core_mjs_["ɵɵelementStart"](39, "wui-input-group", 14);
          core_mjs_["ɵɵtemplate"](40, LabelSettingsComponent_wui_checkbox_40_Template, 1, 1, "wui-checkbox", 15);
          core_mjs_["ɵɵelementEnd"]()();
          core_mjs_["ɵɵelement"](41, "wui-format-settings", 16);
          core_mjs_["ɵɵelementStart"](42, "wui-form-group", 17);
          core_mjs_["ɵɵelement"](43, "wui-color-settings", 18);
          core_mjs_["ɵɵelementStart"](44, "wui-input-group", 19);
          core_mjs_["ɵɵpipe"](45, "isDirty");
          core_mjs_["ɵɵelementStart"](46, "sie-button-group")(47, "sie-button", 20);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_47_listener() {
            return ctx.fontSizeFactor = 0.5;
          });
          core_mjs_["ɵɵelement"](48, "span", 21);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](49, "sie-button", 22);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_49_listener() {
            return ctx.fontSizeFactor = 0.75;
          });
          core_mjs_["ɵɵelement"](50, "span", 23);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](51, "sie-button", 24);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_51_listener() {
            return ctx.fontSizeFactor = 1;
          });
          core_mjs_["ɵɵelement"](52, "span", 25);
          core_mjs_["ɵɵelementEnd"]()()()();
          core_mjs_["ɵɵelementStart"](53, "wui-form-group", 17)(54, "wui-input-group", 26);
          core_mjs_["ɵɵpipe"](55, "isDirty");
          core_mjs_["ɵɵelementStart"](56, "div", 27)(57, "button", 28);
          core_mjs_["ɵɵlistener"]("iconSelect", function LabelSettingsComponent_Template_button_iconSelect_57_listener($event) {
            return ctx.onIconPickerDefaultSelect($event);
          });
          core_mjs_["ɵɵtemplate"](58, LabelSettingsComponent_span_58_Template, 1, 3, "span", 29);
          core_mjs_["ɵɵtemplate"](59, LabelSettingsComponent_div_59_Template, 1, 0, "div", 30);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](60, "button", 31);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_button_click_60_listener() {
            return ctx.clearIcon();
          });
          core_mjs_["ɵɵelement"](61, "span", 32);
          core_mjs_["ɵɵelementEnd"]()()();
          core_mjs_["ɵɵelementStart"](62, "wui-input-group", 33);
          core_mjs_["ɵɵpipe"](63, "isDirty");
          core_mjs_["ɵɵelementStart"](64, "sie-button-group")(65, "sie-button", 34);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_65_listener() {
            ctx.iconPosition = 0;
            return ctx.iconAlign = 1;
          });
          core_mjs_["ɵɵelement"](66, "span", 35);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](67, "sie-button", 36);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_67_listener() {
            ctx.iconPosition = 1;
            return ctx.iconAlign = 1;
          });
          core_mjs_["ɵɵelement"](68, "span", 37);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](69, "sie-button", 38);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_69_listener() {
            ctx.iconPosition = 0;
            return ctx.iconAlign = 0;
          });
          core_mjs_["ɵɵelement"](70, "span", 39);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](71, "sie-button", 40);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_71_listener() {
            ctx.iconPosition = 1;
            return ctx.iconAlign = 0;
          });
          core_mjs_["ɵɵelement"](72, "span", 41);
          core_mjs_["ɵɵelementEnd"]()()();
          core_mjs_["ɵɵelementStart"](73, "wui-input-group", 42);
          core_mjs_["ɵɵpipe"](74, "isDirty");
          core_mjs_["ɵɵelementStart"](75, "sie-button-group")(76, "sie-button", 43);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_76_listener() {
            return ctx.iconSizeFactor = 0.125;
          });
          core_mjs_["ɵɵelement"](77, "span", 21);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](78, "sie-button", 44);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_78_listener() {
            return ctx.iconSizeFactor = 0.25;
          });
          core_mjs_["ɵɵelement"](79, "span", 23);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](80, "sie-button", 45);
          core_mjs_["ɵɵlistener"]("click", function LabelSettingsComponent_Template_sie_button_click_80_listener() {
            return ctx.iconSizeFactor = 0.5;
          });
          core_mjs_["ɵɵelement"](81, "span", 25);
          core_mjs_["ɵɵelementEnd"]()()()()()()()();
        }
        if (rf & 2) {
          const _r1 = core_mjs_["ɵɵreference"](37);
          core_mjs_["ɵɵproperty"]("formGroup", ctx.settingsForm);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ContainerType.Default)("isInvalid", core_mjs_["ɵɵpipeBind1"](3, 78, ctx.settingsForm.get("generalSettings")))("isDirty", core_mjs_["ɵɵpipeBind1"](4, 80, core_mjs_["ɵɵpureFunction1"](110, label_settings_component_c0, ctx.settingsForm.get("generalSettings"))));
          core_mjs_["ɵɵadvance"](4);
          core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](7, 82, "WUI_Dashboard.Widget.General"), " ");
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("data", core_mjs_["ɵɵpipeBind1"](10, 84, ctx.data$));
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ContainerType.Collapsable)("collapsed", ctx.collapsed)("isDirty", core_mjs_["ɵɵpipeBind1"](12, 86, ctx.widgetDataGroup));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](15, 88, "WUI_Dashboard.Widget.Data"), " ");
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Large)("isDirty", core_mjs_["ɵɵpipeBind1"](18, 90, core_mjs_["ɵɵpureFunction1"](112, label_settings_component_c0, ctx.settingsForm.get("data"))))("isInvalid", ctx.settingsForm.get("data").invalid)("isTouched", ctx.settingsForm.get("data").touched);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("dataTypes", ctx.dataTypes);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Large);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("dataPath", ctx.dataPath);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("type", ctx.ContainerType.Collapsable)("collapsed", ctx.collapsed)("isDirty", core_mjs_["ɵɵpipeBind1"](23, 92, ctx.widgetOptionsGroup));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](26, 94, "WUI_Dashboard.Widget.Options"), " ");
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Medium)("isDirty", core_mjs_["ɵɵpipeBind1"](29, 96, core_mjs_["ɵɵpureFunction1"](114, label_settings_component_c0, ctx.settingsForm.get("valuePrefix"))))("isInvalid", ctx.settingsForm.get("valuePrefix").invalid)("isTouched", ctx.settingsForm.get("valuePrefix").touched);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Medium);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Medium)("isDirty", core_mjs_["ɵɵpipeBind1"](33, 98, core_mjs_["ɵɵpureFunction1"](116, label_settings_component_c0, ctx.valuePostfixControl)))("isRequired", core_mjs_["ɵɵpipeBind1"](34, 100, ctx.valuePostfixControl));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.queryPostfix)("ngIfElse", _r1);
          core_mjs_["ɵɵadvance"](4);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Medium);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", !ctx.queryPostfixDisabled);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("dataPath", ctx.dataPath)("dataType", ctx.dataType)("validatorErrors", core_mjs_["ɵɵpureFunction1"](118, label_settings_component_c0, ctx.settingsForm.get("formatSettings").getError("maxValue")));
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("serieIndex", "font_color");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Small)("isDirty", core_mjs_["ɵɵpipeBind1"](45, 102, core_mjs_["ɵɵpureFunction1"](120, label_settings_component_c0, ctx.fontSizeFactorControl)));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.fontSizeFactor === 0.5);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.fontSizeFactor === 0.75);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.fontSizeFactor === 1);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.XSmall)("isDirty", core_mjs_["ɵɵpipeBind1"](55, 104, core_mjs_["ɵɵpureFunction1"](122, label_settings_component_c0, ctx.iconControl)));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("isIcon", ctx.icon);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.icon);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", !ctx.icon);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.XSmall)("isDirty", core_mjs_["ɵɵpipeBind1"](63, 106, core_mjs_["ɵɵpureFunction1"](124, label_settings_component_c0, ctx.iconPositionControl)));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconPosition === 0 && ctx.iconAlign === 1);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconPosition === 1 && ctx.iconAlign === 1);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconPosition === 0 && ctx.iconAlign === 0);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconPosition === 1 && ctx.iconAlign === 0);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Small)("isDirty", core_mjs_["ɵɵpipeBind1"](74, 108, core_mjs_["ɵɵpureFunction1"](126, label_settings_component_c0, ctx.iconSizeFactorControl)));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconSizeFactor === 0.125);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconSizeFactor === 0.25);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ButtonType.Secondary)("iconOnly", true)("activated", ctx.iconSizeFactor === 0.5);
        }
      },
      dependencies: [common_mjs_.NgIf, siemens_di_pa_sw_reusable_components_uxt_form/* FormGroupLineBreakComponent */.Ri, siemens_di_pa_sw_reusable_components_uxt_form/* InputTextDirective */.LR, siemens_di_pa_sw_reusable_components_uxt_button/* ButtonComponent */.r0, siemens_di_pa_sw_reusable_components_uxt_button/* ButtonGroupComponent */.Kb, forms_mjs_.NgControlStatus, forms_mjs_.NgControlStatusGroup, forms_mjs_.FormGroupDirective, forms_mjs_.FormControlName, src_index_ts_.GeneralSettingsComponent, src_index_ts_.ColorSettingsComponent, src_index_ts_.MultiLangTextComponent, src_index_ts_.FormGroupComponent, src_index_ts_.InputGroupComponent, src_index_ts_.FormComponent, src_index_ts_.IconSelectorDirective, src_index_ts_.CheckboxComponent, src_index_ts_.ContainerComponent, src_index_ts_.ContainerTitleComponent, src_index_ts_.ContainerContentComponent, src_index_ts_.ContainerGroupComponent, src_index_ts_.GeneralDataSettingsComponent, src_index_ts_.DataSelectorInputComponent, src_index_ts_.FormatSettingsComponent, common_mjs_.AsyncPipe, ngx_translate_core_mjs_.TranslatePipe, src_index_ts_.HasRequiredFieldPipe, src_index_ts_.IsDirtyPipe, src_index_ts_.IsInvalidPipe],
      styles: [".btn_icon_small[_ngcontent-%COMP%] {\n  font-size: 1.25rem !important;\n}\n\n.btn_icon_medium[_ngcontent-%COMP%] {\n  font-size: 1.5rem !important;\n}\n\n.btn_icon_large[_ngcontent-%COMP%] {\n  font-size: 2rem !important;\n}\n\n.button--nomargin[_ngcontent-%COMP%] {\n  margin: unset !important;\n}\n\n.button--icon-selector[_ngcontent-%COMP%] {\n  color: rgba(var(--color-base450), 1) !important;\n  border-color: rgba(var(--color-base450), 1) !important;\n}\n\n.fontColor[_ngcontent-%COMP%] {\n  margin-right: 1rem !important;\n}"]
    });
  }
  return LabelSettingsComponent;
})();
;// CONCATENATED MODULE: ./libs/dashboard/widgets/label/src/lib/dashboard-widgets-label.module.ts




















let DashboardWidgetsLabelModule = /*#__PURE__*/(() => {
  class DashboardWidgetsLabelModule extends index_ts_.DashboardWidgetModule {
    constructor() {
      super();
      this.createWidgetSettings = createWidgetSettings;
    }
    resolveWidget(viewContainerRef, moduleRef) {
      return viewContainerRef.createComponent(LabelContainerComponent, {
        ngModuleRef: moduleRef
      }).instance;
    }
    resolveWidgetSettings(viewContainerRef, moduleRef) {
      return viewContainerRef.createComponent(LabelSettingsComponent, {
        ngModuleRef: moduleRef
      }).instance;
    }
    static #_ = this.ɵfac = function DashboardWidgetsLabelModule_Factory(t) {
      return new (t || DashboardWidgetsLabelModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/core_mjs_["ɵɵdefineNgModule"]({
      type: DashboardWidgetsLabelModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/core_mjs_["ɵɵdefineInjector"]({
      imports: [common_mjs_.CommonModule, siemens_di_pa_sw_reusable_components_uxt_card/* SieCardModule */.SE, siemens_di_pa_sw_reusable_components_uxt_form/* SieFormModule */.H$, siemens_di_pa_sw_reusable_components_uxt_icon/* SieIconModule */.A, siemens_di_pa_sw_reusable_components_uxt_button/* SieButtonModule */.cH, siemens_di_pa_sw_reusable_components_uxt_content_header/* SieContentHeaderModule */.GY, siemens_di_pa_sw_reusable_components_uxt_container/* SieContainerModule */.o4, siemens_di_pa_sw_reusable_components_uxt_badge/* SieBadgeModule */.T, forms_mjs_.ReactiveFormsModule.withConfig({
        callSetDisabledState: 'whenDisabledForLegacyCode'
      }), ngx_translate_core_mjs_.TranslateModule, src_index_ts_.SettingsFormElementsModule, shared_src_index_ts_.SharedLibModule, src_index_ts_.FormatSettingsComponent]
    });
  }
  return DashboardWidgetsLabelModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && core_mjs_["ɵɵsetNgModuleScope"](DashboardWidgetsLabelModule, {
    declarations: [LabelSettingsComponent, LabelContainerComponent, LabelUiComponent],
    imports: [common_mjs_.CommonModule, siemens_di_pa_sw_reusable_components_uxt_card/* SieCardModule */.SE, siemens_di_pa_sw_reusable_components_uxt_form/* SieFormModule */.H$, siemens_di_pa_sw_reusable_components_uxt_icon/* SieIconModule */.A, siemens_di_pa_sw_reusable_components_uxt_button/* SieButtonModule */.cH, siemens_di_pa_sw_reusable_components_uxt_content_header/* SieContentHeaderModule */.GY, siemens_di_pa_sw_reusable_components_uxt_container/* SieContainerModule */.o4, siemens_di_pa_sw_reusable_components_uxt_badge/* SieBadgeModule */.T, forms_mjs_.ReactiveFormsModule, ngx_translate_core_mjs_.TranslateModule, src_index_ts_.SettingsFormElementsModule, shared_src_index_ts_.SharedLibModule, src_index_ts_.FormatSettingsComponent]
  });
})();
;// CONCATENATED MODULE: ./libs/dashboard/widgets/label/src/index.ts




/***/ }),

/***/ 47869:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GY: () => (/* binding */ SieContentHeaderModule),
/* harmony export */   LG: () => (/* binding */ ContentHeaderSublineComponent),
/* harmony export */   eL: () => (/* binding */ ContentHeaderComponent),
/* harmony export */   iv: () => (/* binding */ ContentHeaderHeadlineComponent)
/* harmony export */ });
/* unused harmony exports ContentHeaderActionsComponent, ContentHeaderContextComponent */
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87161);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(75826);




const _c0 = ["*"];
function ContentHeaderComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ContentHeaderComponent_h1_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ContentHeaderComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1, 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ContentHeaderComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
const _c1 = [[["sie-content-header-context"]], [["sie-content-header-headline"]], [["sie-content-header-subline"]], [["sie-content-header-actions"]]];
const _c2 = ["sie-content-header-context", "sie-content-header-headline", "sie-content-header-subline", "sie-content-header-actions"];
let ContentHeaderActionsComponent = /*#__PURE__*/(() => {
  class ContentHeaderActionsComponent {
    static #_ = this.ɵfac = function ContentHeaderActionsComponent_Factory(t) {
      return new (t || ContentHeaderActionsComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ContentHeaderActionsComponent,
      selectors: [["sie-content-header-actions"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderActionsComponent;
})();
(function () {
  ( false) && 0;
})();
let ContentHeaderContextComponent = /*#__PURE__*/(() => {
  class ContentHeaderContextComponent {
    static #_ = this.ɵfac = function ContentHeaderContextComponent_Factory(t) {
      return new (t || ContentHeaderContextComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ContentHeaderContextComponent,
      selectors: [["sie-content-header-context"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderContextComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderContextComponent;
})();
(function () {
  ( false) && 0;
})();
let ContentHeaderHeadlineComponent = /*#__PURE__*/(() => {
  class ContentHeaderHeadlineComponent {
    static #_ = this.ɵfac = function ContentHeaderHeadlineComponent_Factory(t) {
      return new (t || ContentHeaderHeadlineComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ContentHeaderHeadlineComponent,
      selectors: [["sie-content-header-headline"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderHeadlineComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderHeadlineComponent;
})();
(function () {
  ( false) && 0;
})();
let ContentHeaderSublineComponent = /*#__PURE__*/(() => {
  class ContentHeaderSublineComponent {
    static #_ = this.ɵfac = function ContentHeaderSublineComponent_Factory(t) {
      return new (t || ContentHeaderSublineComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ContentHeaderSublineComponent,
      selectors: [["sie-content-header-subline"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderSublineComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderSublineComponent;
})();
(function () {
  ( false) && 0;
})();
let ContentHeaderComponent = /*#__PURE__*/(() => {
  class ContentHeaderComponent {
    static #_ = this.ɵfac = function ContentHeaderComponent_Factory(t) {
      return new (t || ContentHeaderComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ContentHeaderComponent,
      selectors: [["sie-content-header"]],
      contentQueries: function ContentHeaderComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, ContentHeaderContextComponent, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, ContentHeaderHeadlineComponent, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, ContentHeaderSublineComponent, 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, ContentHeaderActionsComponent, 5);
        }
        if (rf & 2) {
          let _t;
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.contentHeaderContextComponent = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.contentHeaderHeadlineComponent = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.contentHeaderSublineComponent = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.contentHeaderActionsComponent = _t.first);
        }
      },
      ngContentSelectors: _c2,
      decls: 6,
      vars: 4,
      consts: [[1, "contentHeader"], [1, "contentHeader__header"], ["class", "header__context", 4, "ngIf"], ["class", "h1 header__headline", 4, "ngIf"], ["class", "header__subline", 4, "ngIf"], ["class", "contentHeader__actions", 4, "ngIf"], [1, "header__context"], [1, "h1", "header__headline"], [1, "header__subline"], [1, "contentHeader__actions"]],
      template: function ContentHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"](_c1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ContentHeaderComponent_div_2_Template, 2, 0, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ContentHeaderComponent_h1_3_Template, 2, 0, "h1", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ContentHeaderComponent_div_4_Template, 2, 0, "div", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, ContentHeaderComponent_div_5_Template, 2, 0, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.contentHeaderContextComponent);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.contentHeaderHeadlineComponent);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.contentHeaderSublineComponent);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.contentHeaderActionsComponent);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderComponent;
})();
(function () {
  ( false) && 0;
})();
let SieContentHeaderModule = /*#__PURE__*/(() => {
  class SieContentHeaderModule {
    static #_ = this.ɵfac = function SieContentHeaderModule_Factory(t) {
      return new (t || SieContentHeaderModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieContentHeaderModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]
    });
  }
  return SieContentHeaderModule;
})();
(function () {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-content-header.mjs.map

/***/ })

}]);