"use strict";
(self["webpackChunkpie"] = self["webpackChunkpie"] || []).push([[27,413],{

/***/ 27:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Op: () => (/* reexport */ PieLibModule)
});

// UNUSED EXPORTS: PieContainerComponent, PieSettingsComponent

// EXTERNAL MODULE: consume shared module (default) @angular/common@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/common/fesm2022/common.mjs)
var common_mjs_ = __webpack_require__(5826);
// EXTERNAL MODULE: consume shared module (default) @angular/core@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/core/fesm2022/core.mjs)
var core_mjs_ = __webpack_require__(7161);
// EXTERNAL MODULE: consume shared module (default) @angular/forms@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/forms/fesm2022/forms.mjs)
var forms_mjs_ = __webpack_require__(4269);
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/dashboard-widgets-base@* (strict) (fallback: ./libs/dashboard/widgets/base/src/index.ts)
var index_ts_ = __webpack_require__(7721);
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/settings-form-elements@* (strict) (fallback: ./libs/settings-form-elements/src/index.ts)
var src_index_ts_ = __webpack_require__(4854);
// EXTERNAL MODULE: consume shared module (default) @ngx-translate/core@^15.0.0 (singleton) (fallback: ../../node_modules/@ngx-translate/core/dist/fesm2022/ngx-translate-core.mjs)
var ngx_translate_core_mjs_ = __webpack_require__(8229);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-badge.mjs
var siemens_di_pa_sw_reusable_components_uxt_badge = __webpack_require__(6870);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-button.mjs
var siemens_di_pa_sw_reusable_components_uxt_button = __webpack_require__(5695);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-card.mjs
var siemens_di_pa_sw_reusable_components_uxt_card = __webpack_require__(2099);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-container.mjs
var siemens_di_pa_sw_reusable_components_uxt_container = __webpack_require__(491);
;// CONCATENATED MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-content-header.mjs




const _c0 = (/* unused pure expression or super */ null && (["*"]));
function ContentHeaderComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵprojection(1);
    i0.ɵɵelementEnd();
  }
}
function ContentHeaderComponent_h1_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "h1", 7);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
  }
}
function ContentHeaderComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵprojection(1, 2);
    i0.ɵɵelementEnd();
  }
}
function ContentHeaderComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9);
    i0.ɵɵprojection(1, 3);
    i0.ɵɵelementEnd();
  }
}
const _c1 = (/* unused pure expression or super */ null && ([[["sie-content-header-context"]], [["sie-content-header-headline"]], [["sie-content-header-subline"]], [["sie-content-header-actions"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-content-header-context", "sie-content-header-headline", "sie-content-header-subline", "sie-content-header-actions"]));
let ContentHeaderActionsComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContentHeaderActionsComponent {
    static #_ = this.ɵfac = function ContentHeaderActionsComponent_Factory(t) {
      return new (t || ContentHeaderActionsComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContentHeaderActionsComponent,
      selectors: [["sie-content-header-actions"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderActionsComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContentHeaderContextComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContentHeaderContextComponent {
    static #_ = this.ɵfac = function ContentHeaderContextComponent_Factory(t) {
      return new (t || ContentHeaderContextComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContentHeaderContextComponent,
      selectors: [["sie-content-header-context"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderContextComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderContextComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContentHeaderHeadlineComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContentHeaderHeadlineComponent {
    static #_ = this.ɵfac = function ContentHeaderHeadlineComponent_Factory(t) {
      return new (t || ContentHeaderHeadlineComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContentHeaderHeadlineComponent,
      selectors: [["sie-content-header-headline"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderHeadlineComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderHeadlineComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContentHeaderSublineComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContentHeaderSublineComponent {
    static #_ = this.ɵfac = function ContentHeaderSublineComponent_Factory(t) {
      return new (t || ContentHeaderSublineComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContentHeaderSublineComponent,
      selectors: [["sie-content-header-subline"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContentHeaderSublineComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderSublineComponent;
})()));
(function () {
  ( false) && 0;
})();
let ContentHeaderComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContentHeaderComponent {
    static #_ = this.ɵfac = function ContentHeaderComponent_Factory(t) {
      return new (t || ContentHeaderComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContentHeaderComponent,
      selectors: [["sie-content-header"]],
      contentQueries: function ContentHeaderComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i0.ɵɵcontentQuery(dirIndex, ContentHeaderContextComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContentHeaderHeadlineComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContentHeaderSublineComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContentHeaderActionsComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.contentHeaderContextComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.contentHeaderHeadlineComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.contentHeaderSublineComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.contentHeaderActionsComponent = _t.first);
        }
      },
      ngContentSelectors: _c2,
      decls: 6,
      vars: 4,
      consts: [[1, "contentHeader"], [1, "contentHeader__header"], ["class", "header__context", 4, "ngIf"], ["class", "h1 header__headline", 4, "ngIf"], ["class", "header__subline", 4, "ngIf"], ["class", "contentHeader__actions", 4, "ngIf"], [1, "header__context"], [1, "h1", "header__headline"], [1, "header__subline"], [1, "contentHeader__actions"]],
      template: function ContentHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵelementStart(0, "div", 0)(1, "div", 1);
          i0.ɵɵtemplate(2, ContentHeaderComponent_div_2_Template, 2, 0, "div", 2);
          i0.ɵɵtemplate(3, ContentHeaderComponent_h1_3_Template, 2, 0, "h1", 3);
          i0.ɵɵtemplate(4, ContentHeaderComponent_div_4_Template, 2, 0, "div", 4);
          i0.ɵɵelementEnd();
          i0.ɵɵtemplate(5, ContentHeaderComponent_div_5_Template, 2, 0, "div", 5);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵadvance(2);
          i0.ɵɵproperty("ngIf", ctx.contentHeaderContextComponent);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.contentHeaderHeadlineComponent);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.contentHeaderSublineComponent);
          i0.ɵɵadvance(1);
          i0.ɵɵproperty("ngIf", ctx.contentHeaderActionsComponent);
        }
      },
      dependencies: [i1.NgIf],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContentHeaderComponent;
})()));
(function () {
  ( false) && 0;
})();
let SieContentHeaderModule = /*#__PURE__*/(() => {
  class SieContentHeaderModule {
    static #_ = this.ɵfac = function SieContentHeaderModule_Factory(t) {
      return new (t || SieContentHeaderModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */core_mjs_["ɵɵdefineNgModule"]({
      type: SieContentHeaderModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */core_mjs_["ɵɵdefineInjector"]({
      imports: [common_mjs_.CommonModule]
    });
  }
  return SieContentHeaderModule;
})();
(function () {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-content-header.mjs.map
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-form.mjs
var siemens_di_pa_sw_reusable_components_uxt_form = __webpack_require__(6655);
// EXTERNAL MODULE: ../../node_modules/@siemens-di-pa-sw/reusable-components-uxt/fesm2022/siemens-di-pa-sw-reusable-components-uxt-icon.mjs
var siemens_di_pa_sw_reusable_components_uxt_icon = __webpack_require__(8573);
// EXTERNAL MODULE: ../../node_modules/echarts/index.js + 549 modules
var echarts = __webpack_require__(4942);
// EXTERNAL MODULE: ../../node_modules/ngx-color-picker/fesm2020/ngx-color-picker.mjs
var ngx_color_picker = __webpack_require__(335);
// EXTERNAL MODULE: ../../node_modules/ngx-echarts/fesm2022/ngx-echarts.mjs + 2 modules
var ngx_echarts = __webpack_require__(3810);
// EXTERNAL MODULE: ../../node_modules/primeng/fesm2022/primeng-dom.mjs
var primeng_dom = __webpack_require__(668);
;// CONCATENATED MODULE: ../../node_modules/primeng/fesm2022/primeng-slider.mjs






const primeng_slider_c0 = ["sliderHandle"];
const primeng_slider_c1 = ["sliderHandleStart"];
const primeng_slider_c2 = ["sliderHandleEnd"];
const _c3 = function (a0, a1) {
  return {
    left: a0,
    width: a1
  };
};
function Slider_span_1_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "span", 5);
  }
  if (rf & 2) {
    const ctx_r0 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction2"](2, _c3, ctx_r0.offset !== null && ctx_r0.offset !== undefined ? ctx_r0.offset + "%" : ctx_r0.handleValues[0] + "%", ctx_r0.diff ? ctx_r0.diff + "%" : ctx_r0.handleValues[1] - ctx_r0.handleValues[0] + "%"));
    core_mjs_["ɵɵattribute"]("data-pc-section", "range");
  }
}
const _c4 = function (a0, a1) {
  return {
    bottom: a0,
    height: a1
  };
};
function Slider_span_2_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "span", 5);
  }
  if (rf & 2) {
    const ctx_r1 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction2"](2, _c4, ctx_r1.offset !== null && ctx_r1.offset !== undefined ? ctx_r1.offset + "%" : ctx_r1.handleValues[0] + "%", ctx_r1.diff ? ctx_r1.diff + "%" : ctx_r1.handleValues[1] - ctx_r1.handleValues[0] + "%"));
    core_mjs_["ɵɵattribute"]("data-pc-section", "range");
  }
}
const _c5 = function (a0) {
  return {
    height: a0
  };
};
function Slider_span_3_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "span", 5);
  }
  if (rf & 2) {
    const ctx_r2 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction1"](2, _c5, ctx_r2.handleValue + "%"));
    core_mjs_["ɵɵattribute"]("data-pc-section", "range");
  }
}
const _c6 = function (a0) {
  return {
    width: a0
  };
};
function Slider_span_4_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "span", 5);
  }
  if (rf & 2) {
    const ctx_r3 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction1"](2, _c6, ctx_r3.handleValue + "%"));
    core_mjs_["ɵɵattribute"]("data-pc-section", "range");
  }
}
const _c7 = function (a0, a1) {
  return {
    left: a0,
    bottom: a1
  };
};
function Slider_span_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = core_mjs_["ɵɵgetCurrentView"]();
    core_mjs_["ɵɵelementStart"](0, "span", 6, 7);
    core_mjs_["ɵɵlistener"]("touchstart", function Slider_span_5_Template_span_touchstart_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r9);
      const ctx_r8 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r8.onDragStart($event));
    })("touchmove", function Slider_span_5_Template_span_touchmove_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r9);
      const ctx_r10 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r10.onDrag($event));
    })("touchend", function Slider_span_5_Template_span_touchend_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r9);
      const ctx_r11 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r11.onDragEnd($event));
    })("mousedown", function Slider_span_5_Template_span_mousedown_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r9);
      const ctx_r12 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r12.onMouseDown($event));
    })("keydown", function Slider_span_5_Template_span_keydown_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r9);
      const ctx_r13 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r13.onKeyDown($event));
    });
    core_mjs_["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵstyleProp"]("transition", ctx_r4.dragging ? "none" : null);
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction2"](11, _c7, ctx_r4.orientation == "horizontal" ? ctx_r4.handleValue + "%" : null, ctx_r4.orientation == "vertical" ? ctx_r4.handleValue + "%" : null));
    core_mjs_["ɵɵattribute"]("tabindex", ctx_r4.disabled ? null : ctx_r4.tabindex)("aria-valuemin", ctx_r4.min)("aria-valuenow", ctx_r4.value)("aria-valuemax", ctx_r4.max)("aria-labelledby", ctx_r4.ariaLabelledBy)("aria-label", ctx_r4.ariaLabel)("aria-orientation", ctx_r4.orientation)("data-pc-section", "handle");
  }
}
const _c8 = function (a0) {
  return {
    "p-slider-handle-active": a0
  };
};
function Slider_span_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = core_mjs_["ɵɵgetCurrentView"]();
    core_mjs_["ɵɵelementStart"](0, "span", 8, 9);
    core_mjs_["ɵɵlistener"]("keydown", function Slider_span_6_Template_span_keydown_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r16);
      const ctx_r15 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r15.onKeyDown($event, 0));
    })("mousedown", function Slider_span_6_Template_span_mousedown_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r16);
      const ctx_r17 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r17.onMouseDown($event, 0));
    })("touchstart", function Slider_span_6_Template_span_touchstart_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r16);
      const ctx_r18 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r18.onDragStart($event, 0));
    })("touchmove", function Slider_span_6_Template_span_touchmove_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r16);
      const ctx_r19 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r19.onDrag($event, 0));
    })("touchend", function Slider_span_6_Template_span_touchend_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r16);
      const ctx_r20 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r20.onDragEnd($event));
    });
    core_mjs_["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵstyleProp"]("transition", ctx_r5.dragging ? "none" : null);
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction2"](12, _c7, ctx_r5.rangeStartLeft, ctx_r5.rangeStartBottom))("ngClass", core_mjs_["ɵɵpureFunction1"](15, _c8, ctx_r5.handleIndex == 0));
    core_mjs_["ɵɵattribute"]("tabindex", ctx_r5.disabled ? null : ctx_r5.tabindex)("aria-valuemin", ctx_r5.min)("aria-valuenow", ctx_r5.value ? ctx_r5.value[0] : null)("aria-valuemax", ctx_r5.max)("aria-labelledby", ctx_r5.ariaLabelledBy)("aria-label", ctx_r5.ariaLabel)("aria-orientation", ctx_r5.orientation)("data-pc-section", "startHandler");
  }
}
function Slider_span_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = core_mjs_["ɵɵgetCurrentView"]();
    core_mjs_["ɵɵelementStart"](0, "span", 10, 11);
    core_mjs_["ɵɵlistener"]("keydown", function Slider_span_7_Template_span_keydown_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r23);
      const ctx_r22 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r22.onKeyDown($event, 1));
    })("mousedown", function Slider_span_7_Template_span_mousedown_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r23);
      const ctx_r24 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r24.onMouseDown($event, 1));
    })("touchstart", function Slider_span_7_Template_span_touchstart_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r23);
      const ctx_r25 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r25.onDragStart($event, 1));
    })("touchmove", function Slider_span_7_Template_span_touchmove_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r23);
      const ctx_r26 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r26.onDrag($event, 1));
    })("touchend", function Slider_span_7_Template_span_touchend_0_listener($event) {
      core_mjs_["ɵɵrestoreView"](_r23);
      const ctx_r27 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r27.onDragEnd($event));
    });
    core_mjs_["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵstyleProp"]("transition", ctx_r6.dragging ? "none" : null);
    core_mjs_["ɵɵproperty"]("ngStyle", core_mjs_["ɵɵpureFunction2"](12, _c7, ctx_r6.rangeEndLeft, ctx_r6.rangeEndBottom))("ngClass", core_mjs_["ɵɵpureFunction1"](15, _c8, ctx_r6.handleIndex == 1));
    core_mjs_["ɵɵattribute"]("tabindex", ctx_r6.disabled ? null : ctx_r6.tabindex)("aria-valuemin", ctx_r6.min)("aria-valuenow", ctx_r6.value ? ctx_r6.value[1] : null)("aria-valuemax", ctx_r6.max)("aria-labelledby", ctx_r6.ariaLabelledBy)("aria-label", ctx_r6.ariaLabel)("aria-orientation", ctx_r6.orientation)("data-pc-section", "endHandler");
  }
}
const _c9 = function (a1, a2, a3, a4) {
  return {
    "p-slider p-component": true,
    "p-disabled": a1,
    "p-slider-horizontal": a2,
    "p-slider-vertical": a3,
    "p-slider-animate": a4
  };
};
const SLIDER_VALUE_ACCESSOR = {
  provide: forms_mjs_.NG_VALUE_ACCESSOR,
  useExisting: (0,core_mjs_.forwardRef)(() => Slider),
  multi: true
};
/**
 * Slider is a component to provide input with a drag handle.
 * @group Components
 */
let Slider = /*#__PURE__*/(() => {
  class Slider {
    document;
    platformId;
    el;
    renderer;
    ngZone;
    cd;
    /**
     * When enabled, displays an animation on click of the slider bar.
     * @group Props
     */
    animate;
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    disabled;
    /**
     * Mininum boundary value.
     * @group Props
     */
    min = 0;
    /**
     * Maximum boundary value.
     * @group Props
     */
    max = 100;
    /**
     * Orientation of the slider.
     * @group Props
     */
    orientation = 'horizontal';
    /**
     * Step factor to increment/decrement the value.
     * @group Props
     */
    step;
    /**
     * When specified, allows two boundary values to be picked.
     * @group Props
     */
    range;
    /**
     * Inline style of the component.
     * @group Props
     */
    style;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = 0;
    /**
     * Callback to invoke on value change.
     * @param {SliderChangeEvent} event - Custom value change event.
     * @group Emits
     */
    onChange = new core_mjs_.EventEmitter();
    /**
     * Callback to invoke when slide ended.
     * @param {SliderSlideEndEvent} event - Custom slide end event.
     * @group Emits
     */
    onSlideEnd = new core_mjs_.EventEmitter();
    sliderHandle;
    sliderHandleStart;
    sliderHandleEnd;
    value;
    values;
    handleValue;
    handleValues = [];
    diff;
    offset;
    bottom;
    onModelChange = () => {};
    onModelTouched = () => {};
    dragging;
    dragListener;
    mouseupListener;
    initX;
    initY;
    barWidth;
    barHeight;
    sliderHandleClick;
    handleIndex = 0;
    startHandleValue;
    startx;
    starty;
    constructor(document, platformId, el, renderer, ngZone, cd) {
      this.document = document;
      this.platformId = platformId;
      this.el = el;
      this.renderer = renderer;
      this.ngZone = ngZone;
      this.cd = cd;
    }
    onMouseDown(event, index) {
      if (this.disabled) {
        return;
      }
      this.dragging = true;
      this.updateDomData();
      this.sliderHandleClick = true;
      if (this.range && this.handleValues && this.handleValues[0] === this.max) {
        this.handleIndex = 0;
      } else {
        this.handleIndex = index;
      }
      this.bindDragListeners();
      event.target.focus();
      event.preventDefault();
      if (this.animate) {
        primeng_dom/* DomHandler */.p.removeClass(this.el.nativeElement.children[0], 'p-slider-animate');
      }
    }
    onDragStart(event, index) {
      if (this.disabled) {
        return;
      }
      var touchobj = event.changedTouches[0];
      this.startHandleValue = this.range ? this.handleValues[index] : this.handleValue;
      this.dragging = true;
      if (this.range && this.handleValues && this.handleValues[0] === this.max) {
        this.handleIndex = 0;
      } else {
        this.handleIndex = index;
      }
      if (this.orientation === 'horizontal') {
        this.startx = parseInt(touchobj.clientX, 10);
        this.barWidth = this.el.nativeElement.children[0].offsetWidth;
      } else {
        this.starty = parseInt(touchobj.clientY, 10);
        this.barHeight = this.el.nativeElement.children[0].offsetHeight;
      }
      if (this.animate) {
        primeng_dom/* DomHandler */.p.removeClass(this.el.nativeElement.children[0], 'p-slider-animate');
      }
      event.preventDefault();
    }
    onDrag(event) {
      if (this.disabled) {
        return;
      }
      var touchobj = event.changedTouches[0],
        handleValue = 0;
      if (this.orientation === 'horizontal') {
        handleValue = Math.floor((parseInt(touchobj.clientX, 10) - this.startx) * 100 / this.barWidth) + this.startHandleValue;
      } else {
        handleValue = Math.floor((this.starty - parseInt(touchobj.clientY, 10)) * 100 / this.barHeight) + this.startHandleValue;
      }
      this.setValueFromHandle(event, handleValue);
      event.preventDefault();
    }
    onDragEnd(event) {
      if (this.disabled) {
        return;
      }
      this.dragging = false;
      if (this.range) this.onSlideEnd.emit({
        originalEvent: event,
        values: this.values
      });else this.onSlideEnd.emit({
        originalEvent: event,
        value: this.value
      });
      if (this.animate) {
        primeng_dom/* DomHandler */.p.addClass(this.el.nativeElement.children[0], 'p-slider-animate');
      }
      event.preventDefault();
    }
    onBarClick(event) {
      if (this.disabled) {
        return;
      }
      if (!this.sliderHandleClick) {
        this.updateDomData();
        this.handleChange(event);
        if (this.range) this.onSlideEnd.emit({
          originalEvent: event,
          values: this.values
        });else this.onSlideEnd.emit({
          originalEvent: event,
          value: this.value
        });
      }
      this.sliderHandleClick = false;
    }
    onKeyDown(event, index) {
      this.handleIndex = index;
      switch (event.code) {
        case 'ArrowDown':
        case 'ArrowLeft':
          this.decrementValue(event, index);
          event.preventDefault();
          break;
        case 'ArrowUp':
        case 'ArrowRight':
          this.incrementValue(event, index);
          event.preventDefault();
          break;
        case 'PageDown':
          this.decrementValue(event, index, true);
          event.preventDefault();
          break;
        case 'PageUp':
          this.incrementValue(event, index, true);
          event.preventDefault();
          break;
        case 'Home':
          this.updateValue(this.min, event);
          event.preventDefault();
          break;
        case 'End':
          this.updateValue(this.max, event);
          event.preventDefault();
          break;
        default:
          break;
      }
    }
    decrementValue(event, index, pageKey = false) {
      let newValue;
      if (this.range) {
        if (this.step) newValue = this.values[index] - this.step;else newValue = this.values[index] - 1;
      } else {
        if (this.step) newValue = this.value - this.step;else if (!this.step && pageKey) newValue = this.value - 10;else newValue = this.value - 1;
      }
      this.updateValue(newValue, event);
      event.preventDefault();
    }
    incrementValue(event, index, pageKey = false) {
      let newValue;
      if (this.range) {
        if (this.step) newValue = this.values[index] + this.step;else newValue = this.values[index] + 1;
      } else {
        if (this.step) newValue = this.value + this.step;else if (!this.step && pageKey) newValue = this.value + 10;else newValue = this.value + 1;
      }
      this.updateValue(newValue, event);
      event.preventDefault();
    }
    handleChange(event) {
      let handleValue = this.calculateHandleValue(event);
      this.setValueFromHandle(event, handleValue);
    }
    bindDragListeners() {
      if ((0,common_mjs_.isPlatformBrowser)(this.platformId)) {
        this.ngZone.runOutsideAngular(() => {
          const documentTarget = this.el ? this.el.nativeElement.ownerDocument : this.document;
          if (!this.dragListener) {
            this.dragListener = this.renderer.listen(documentTarget, 'mousemove', event => {
              if (this.dragging) {
                this.ngZone.run(() => {
                  this.handleChange(event);
                });
              }
            });
          }
          if (!this.mouseupListener) {
            this.mouseupListener = this.renderer.listen(documentTarget, 'mouseup', event => {
              if (this.dragging) {
                this.dragging = false;
                this.ngZone.run(() => {
                  if (this.range) this.onSlideEnd.emit({
                    originalEvent: event,
                    values: this.values
                  });else this.onSlideEnd.emit({
                    originalEvent: event,
                    value: this.value
                  });
                  if (this.animate) {
                    primeng_dom/* DomHandler */.p.addClass(this.el.nativeElement.children[0], 'p-slider-animate');
                  }
                });
              }
            });
          }
        });
      }
    }
    unbindDragListeners() {
      if (this.dragListener) {
        this.dragListener();
        this.dragListener = null;
      }
      if (this.mouseupListener) {
        this.mouseupListener();
        this.mouseupListener = null;
      }
    }
    setValueFromHandle(event, handleValue) {
      let newValue = this.getValueFromHandle(handleValue);
      if (this.range) {
        if (this.step) {
          this.handleStepChange(newValue, this.values[this.handleIndex]);
        } else {
          this.handleValues[this.handleIndex] = handleValue;
          this.updateValue(newValue, event);
        }
      } else {
        if (this.step) {
          this.handleStepChange(newValue, this.value);
        } else {
          this.handleValue = handleValue;
          this.updateValue(newValue, event);
        }
      }
      this.cd.markForCheck();
    }
    handleStepChange(newValue, oldValue) {
      let diff = newValue - oldValue;
      let val = oldValue;
      let _step = this.step;
      if (diff < 0) {
        val = oldValue + Math.ceil(newValue / _step - oldValue / _step) * _step;
      } else if (diff > 0) {
        val = oldValue + Math.floor(newValue / _step - oldValue / _step) * _step;
      }
      this.updateValue(val);
      this.updateHandleValue();
    }
    writeValue(value) {
      if (this.range) this.values = value || [0, 0];else this.value = value || 0;
      this.updateHandleValue();
      this.updateDiffAndOffset();
      this.cd.markForCheck();
    }
    registerOnChange(fn) {
      this.onModelChange = fn;
    }
    registerOnTouched(fn) {
      this.onModelTouched = fn;
    }
    setDisabledState(val) {
      this.disabled = val;
      this.cd.markForCheck();
    }
    get rangeStartLeft() {
      if (!this.isVertical()) return this.handleValues[0] > 100 ? 100 + '%' : this.handleValues[0] + '%';
      return null;
    }
    get rangeStartBottom() {
      return this.isVertical() ? this.handleValues[0] + '%' : 'auto';
    }
    get rangeEndLeft() {
      return this.isVertical() ? null : this.handleValues[1] + '%';
    }
    get rangeEndBottom() {
      return this.isVertical() ? this.handleValues[1] + '%' : 'auto';
    }
    isVertical() {
      return this.orientation === 'vertical';
    }
    updateDomData() {
      let rect = this.el.nativeElement.children[0].getBoundingClientRect();
      this.initX = rect.left + primeng_dom/* DomHandler */.p.getWindowScrollLeft();
      this.initY = rect.top + primeng_dom/* DomHandler */.p.getWindowScrollTop();
      this.barWidth = this.el.nativeElement.children[0].offsetWidth;
      this.barHeight = this.el.nativeElement.children[0].offsetHeight;
    }
    calculateHandleValue(event) {
      if (this.orientation === 'horizontal') return (event.pageX - this.initX) * 100 / this.barWidth;else return (this.initY + this.barHeight - event.pageY) * 100 / this.barHeight;
    }
    updateHandleValue() {
      if (this.range) {
        this.handleValues[0] = (this.values[0] < this.min ? 0 : this.values[0] - this.min) * 100 / (this.max - this.min);
        this.handleValues[1] = (this.values[1] > this.max ? 100 : this.values[1] - this.min) * 100 / (this.max - this.min);
      } else {
        if (this.value < this.min) this.handleValue = 0;else if (this.value > this.max) this.handleValue = 100;else this.handleValue = (this.value - this.min) * 100 / (this.max - this.min);
      }
      if (this.step) {
        this.updateDiffAndOffset();
      }
    }
    updateDiffAndOffset() {
      this.diff = this.getDiff();
      this.offset = this.getOffset();
    }
    getDiff() {
      return Math.abs(this.handleValues[0] - this.handleValues[1]);
    }
    getOffset() {
      return Math.min(this.handleValues[0], this.handleValues[1]);
    }
    updateValue(val, event) {
      if (this.range) {
        let value = val;
        if (this.handleIndex == 0) {
          if (value < this.min) {
            value = this.min;
            this.handleValues[0] = 0;
          } else if (value > this.values[1]) {
            if (value > this.max) {
              value = this.max;
              this.handleValues[0] = 100;
            }
          }
          this.sliderHandleStart?.nativeElement.focus();
        } else {
          if (value > this.max) {
            value = this.max;
            this.handleValues[1] = 100;
            this.offset = this.handleValues[1];
          } else if (value < this.min) {
            value = this.min;
            this.handleValues[1] = 0;
          } else if (value < this.values[0]) {
            this.offset = this.handleValues[1];
          }
          this.sliderHandleEnd?.nativeElement.focus();
        }
        if (this.step) {
          this.updateHandleValue();
        } else {
          this.updateDiffAndOffset();
        }
        this.values[this.handleIndex] = this.getNormalizedValue(value);
        let newValues = [this.minVal, this.maxVal];
        this.onModelChange(newValues);
        this.onChange.emit({
          event: event,
          values: this.values
        });
      } else {
        if (val < this.min) {
          val = this.min;
          this.handleValue = 0;
        } else if (val > this.max) {
          val = this.max;
          this.handleValue = 100;
        }
        this.value = this.getNormalizedValue(val);
        this.onModelChange(this.value);
        this.onChange.emit({
          event: event,
          value: this.value
        });
        this.sliderHandle?.nativeElement.focus();
      }
      this.updateHandleValue();
    }
    getValueFromHandle(handleValue) {
      return (this.max - this.min) * (handleValue / 100) + this.min;
    }
    getDecimalsCount(value) {
      if (value && Math.floor(value) !== value) return value.toString().split('.')[1].length || 0;
      return 0;
    }
    getNormalizedValue(val) {
      let decimalsCount = this.getDecimalsCount(this.step);
      if (decimalsCount > 0) {
        return +parseFloat(val.toString()).toFixed(decimalsCount);
      } else {
        return Math.floor(val);
      }
    }
    ngOnDestroy() {
      this.unbindDragListeners();
    }
    get minVal() {
      return Math.min(this.values[1], this.values[0]);
    }
    get maxVal() {
      return Math.max(this.values[1], this.values[0]);
    }
    static ɵfac = function Slider_Factory(t) {
      return new (t || Slider)(core_mjs_["ɵɵdirectiveInject"](common_mjs_.DOCUMENT), core_mjs_["ɵɵdirectiveInject"](core_mjs_.PLATFORM_ID), core_mjs_["ɵɵdirectiveInject"](core_mjs_.ElementRef), core_mjs_["ɵɵdirectiveInject"](core_mjs_.Renderer2), core_mjs_["ɵɵdirectiveInject"](core_mjs_.NgZone), core_mjs_["ɵɵdirectiveInject"](core_mjs_.ChangeDetectorRef));
    };
    static ɵcmp = /* @__PURE__ */core_mjs_["ɵɵdefineComponent"]({
      type: Slider,
      selectors: [["p-slider"]],
      viewQuery: function Slider_Query(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵviewQuery"](primeng_slider_c0, 5);
          core_mjs_["ɵɵviewQuery"](primeng_slider_c1, 5);
          core_mjs_["ɵɵviewQuery"](primeng_slider_c2, 5);
        }
        if (rf & 2) {
          let _t;
          core_mjs_["ɵɵqueryRefresh"](_t = core_mjs_["ɵɵloadQuery"]()) && (ctx.sliderHandle = _t.first);
          core_mjs_["ɵɵqueryRefresh"](_t = core_mjs_["ɵɵloadQuery"]()) && (ctx.sliderHandleStart = _t.first);
          core_mjs_["ɵɵqueryRefresh"](_t = core_mjs_["ɵɵloadQuery"]()) && (ctx.sliderHandleEnd = _t.first);
        }
      },
      hostAttrs: [1, "p-element"],
      inputs: {
        animate: "animate",
        disabled: "disabled",
        min: "min",
        max: "max",
        orientation: "orientation",
        step: "step",
        range: "range",
        style: "style",
        styleClass: "styleClass",
        ariaLabel: "ariaLabel",
        ariaLabelledBy: "ariaLabelledBy",
        tabindex: "tabindex"
      },
      outputs: {
        onChange: "onChange",
        onSlideEnd: "onSlideEnd"
      },
      features: [core_mjs_["ɵɵProvidersFeature"]([SLIDER_VALUE_ACCESSOR])],
      decls: 8,
      vars: 18,
      consts: [[3, "ngStyle", "ngClass", "click"], ["class", "p-slider-range", 3, "ngStyle", 4, "ngIf"], ["class", "p-slider-handle", "role", "slider", 3, "transition", "ngStyle", "touchstart", "touchmove", "touchend", "mousedown", "keydown", 4, "ngIf"], ["class", "p-slider-handle", "role", "slider", 3, "transition", "ngStyle", "ngClass", "keydown", "mousedown", "touchstart", "touchmove", "touchend", 4, "ngIf"], ["class", "p-slider-handle", 3, "transition", "ngStyle", "ngClass", "keydown", "mousedown", "touchstart", "touchmove", "touchend", 4, "ngIf"], [1, "p-slider-range", 3, "ngStyle"], ["role", "slider", 1, "p-slider-handle", 3, "ngStyle", "touchstart", "touchmove", "touchend", "mousedown", "keydown"], ["sliderHandle", ""], ["role", "slider", 1, "p-slider-handle", 3, "ngStyle", "ngClass", "keydown", "mousedown", "touchstart", "touchmove", "touchend"], ["sliderHandleStart", ""], [1, "p-slider-handle", 3, "ngStyle", "ngClass", "keydown", "mousedown", "touchstart", "touchmove", "touchend"], ["sliderHandleEnd", ""]],
      template: function Slider_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵelementStart"](0, "div", 0);
          core_mjs_["ɵɵlistener"]("click", function Slider_Template_div_click_0_listener($event) {
            return ctx.onBarClick($event);
          });
          core_mjs_["ɵɵtemplate"](1, Slider_span_1_Template, 1, 5, "span", 1);
          core_mjs_["ɵɵtemplate"](2, Slider_span_2_Template, 1, 5, "span", 1);
          core_mjs_["ɵɵtemplate"](3, Slider_span_3_Template, 1, 4, "span", 1);
          core_mjs_["ɵɵtemplate"](4, Slider_span_4_Template, 1, 4, "span", 1);
          core_mjs_["ɵɵtemplate"](5, Slider_span_5_Template, 2, 14, "span", 2);
          core_mjs_["ɵɵtemplate"](6, Slider_span_6_Template, 2, 17, "span", 3);
          core_mjs_["ɵɵtemplate"](7, Slider_span_7_Template, 2, 17, "span", 4);
          core_mjs_["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          core_mjs_["ɵɵclassMap"](ctx.styleClass);
          core_mjs_["ɵɵproperty"]("ngStyle", ctx.style)("ngClass", core_mjs_["ɵɵpureFunction4"](13, _c9, ctx.disabled, ctx.orientation == "horizontal", ctx.orientation == "vertical", ctx.animate));
          core_mjs_["ɵɵattribute"]("data-pc-name", "slider")("data-pc-section", "root");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.range && ctx.orientation == "horizontal");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.range && ctx.orientation == "vertical");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", !ctx.range && ctx.orientation == "vertical");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", !ctx.range && ctx.orientation == "horizontal");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", !ctx.range);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.range);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.range);
        }
      },
      dependencies: [common_mjs_.NgClass, common_mjs_.NgIf, common_mjs_.NgStyle],
      styles: ["@layer primeng{.p-slider{position:relative}.p-slider .p-slider-handle{position:absolute;cursor:grab;touch-action:none;display:block}.p-slider-range{position:absolute;display:block}.p-slider-horizontal .p-slider-range{top:0;left:0;height:100%}.p-slider-horizontal .p-slider-handle{top:50%}.p-slider-vertical{height:100px}.p-slider-vertical .p-slider-handle{left:50%}.p-slider-vertical .p-slider-range{bottom:0;left:0;width:100%}}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return Slider;
})();
(function () {
  ( false) && 0;
})();
let SliderModule = /*#__PURE__*/(() => {
  class SliderModule {
    static ɵfac = function SliderModule_Factory(t) {
      return new (t || SliderModule)();
    };
    static ɵmod = /* @__PURE__ */core_mjs_["ɵɵdefineNgModule"]({
      type: SliderModule
    });
    static ɵinj = /* @__PURE__ */core_mjs_["ɵɵdefineInjector"]({
      imports: [common_mjs_.CommonModule]
    });
  }
  return SliderModule;
})();
(function () {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-slider.mjs.map
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/models@* (strict) (fallback: ./libs/models/src/index.ts)
var models_src_index_ts_ = __webpack_require__(6013);
;// CONCATENATED MODULE: ./libs/dashboard/widgets/pie/src/lib/createWidgetSettings.ts

const createWidgetSettings = function (data, widgetInformation, jsonFileName, multiLangTextService) {
  // will be called the first time a new widget is added to the dashboard to initially set config
  const returnObj = {
    type: widgetInformation.widgetType,
    ...widgetInformation.defaultSettings,
    data: [data]
  };
  const series = [];
  if (data.dataPath && data.dataType) {
    let i = 0;
    switch (typeof data.dataType) {
      case 'object':
        // seems to be a structure
        if (!data.dataPath.endsWith('.')) {
          data.dataPath += '.';
        }
        for (const [entry] of Object.entries(data.dataType)) {
          series.push({
            dpe: {
              dataPath: data.dataPath + entry,
              dataType: data.dataType
            },
            name: {
              name: multiLangTextService.createMultiLangString(entry),
              queryName: true,
              nameSource: models_src_index_ts_.TitleSource.Description,
              nameDataPath: data.dataPath
            },
            color: models_src_index_ts_.MDSP_COLORS[i],
            formatSettings: {
              type: models_src_index_ts_.FormatSettingsType.Oa,
              value: '%0.2f'
            },
            unitSettings: {
              type: models_src_index_ts_.UnitSettingsType.Oa,
              value: multiLangTextService.createMultiLangString('')
            }
          });
          i = i + 1;
        }
        break;
      case 'string':
        // seems to be a dpe
        series.push({
          dpe: data,
          name: {
            name: multiLangTextService.createMultiLangString(data.dataPath.substr(0, data.dataPath.lastIndexOf('.'))),
            queryName: true,
            nameSource: models_src_index_ts_.TitleSource.Description,
            nameDataPath: data.dataPath
          },
          color: models_src_index_ts_.MDSP_COLORS[i],
          formatSettings: {
            type: models_src_index_ts_.FormatSettingsType.Oa,
            value: '%0.2f'
          },
          unitSettings: {
            type: models_src_index_ts_.UnitSettingsType.Oa,
            value: multiLangTextService.createMultiLangString('')
          }
        });
    }
  } else {
    series.push({
      dpe: {
        dataPath: null,
        dataType: null
      },
      name: {
        queryName: true,
        nameSource: models_src_index_ts_.TitleSource.Description,
        nameDataPath: null
      },
      color: models_src_index_ts_.MDSP_COLORS[0],
      formatSettings: {
        type: models_src_index_ts_.FormatSettingsType.Oa,
        value: '%0.2f'
      },
      unitSettings: {
        type: models_src_index_ts_.UnitSettingsType.Oa,
        value: multiLangTextService.createMultiLangString('')
      }
    });
  }
  returnObj.chartOptions = {
    ...returnObj.chartOptions,
    ...{
      series: series
    }
  };
  return returnObj;
};
// EXTERNAL MODULE: consume shared module (default) @etm-professional-control/abstract-services@* (strict) (fallback: ./libs/abstract-services/src/index.ts)
var abstract_services_src_index_ts_ = __webpack_require__(5277);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/Subject.js + 1 modules
var Subject = __webpack_require__(8611);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/Subscription.js + 1 modules
var Subscription = __webpack_require__(8870);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/map.js
var map = __webpack_require__(7946);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/takeUntil.js
var takeUntil = __webpack_require__(4146);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/tap.js
var tap = __webpack_require__(8790);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/take.js
var take = __webpack_require__(995);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/delay.js + 2 modules
var delay = __webpack_require__(3745);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/shareReplay.js
var shareReplay = __webpack_require__(1837);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/filter.js
var filter = __webpack_require__(9249);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/forkJoin.js
var forkJoin = __webpack_require__(9121);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/of.js
var of = __webpack_require__(8480);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/timeout.js
var timeout = __webpack_require__(5291);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/switchMap.js
var switchMap = __webpack_require__(5700);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/auditTime.js + 1 modules
var auditTime = __webpack_require__(2897);
;// CONCATENATED MODULE: ./libs/dashboard/widgets/pie/src/lib/pie-ui/pie-ui.component.ts






const pie_ui_component_c0 = ["pie"];
let PieUiComponent = /*#__PURE__*/(() => {
  class PieUiComponent extends index_ts_.EchartsUiComponent {
    constructor() {
      super(...arguments);
      this.resized = new core_mjs_.EventEmitter();
      this.resizeCallsSubject = new Subject/* Subject */.x();
      this.onWindowResize = () => {
        this.resizeCallsSubject.next();
      };
    }
    set chartOptions(_chartOptions) {
      super.chartOptions = _chartOptions;
      this.resizeCallsSubject.next();
    }
    set resize(value) {
      this.resizeCallsSubject.next();
    }
    ngOnInit() {
      this.subscribeToResize();
    }
    onResize() {
      super.resize = 1;
      if (this.eChartsWrapper?.nativeElement) {
        const width = this.eChartsWrapper.nativeElement.clientWidth;
        const height = this.eChartsWrapper.nativeElement.clientHeight;
        if (width > 0 && height > 0) {
          this.resized.emit([width, height]);
        }
      }
    }
    subscribeToResize() {
      this.subs.push(this.resizeCallsSubject.pipe((0,auditTime/* auditTime */.e)(250)).subscribe(() => {
        this.onResize();
      }));
      this.resizeCallsSubject.next();
    }
    static #_ = this.ɵfac = /*@__PURE__*/function () {
      let ɵPieUiComponent_BaseFactory;
      return function PieUiComponent_Factory(t) {
        return (ɵPieUiComponent_BaseFactory || (ɵPieUiComponent_BaseFactory = core_mjs_["ɵɵgetInheritedFactory"](PieUiComponent)))(t || PieUiComponent);
      };
    }();
    static #_2 = this.ɵcmp = /*@__PURE__*/core_mjs_["ɵɵdefineComponent"]({
      type: PieUiComponent,
      selectors: [["wui-pie-ui"]],
      viewQuery: function PieUiComponent_Query(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵviewQuery"](pie_ui_component_c0, 5);
        }
        if (rf & 2) {
          let _t;
          core_mjs_["ɵɵqueryRefresh"](_t = core_mjs_["ɵɵloadQuery"]()) && (ctx.eChartsWrapper = _t.first);
        }
      },
      hostBindings: function PieUiComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵlistener"]("resize", function PieUiComponent_resize_HostBindingHandler() {
            return ctx.onWindowResize();
          }, false, core_mjs_["ɵɵresolveWindow"]);
        }
      },
      inputs: {
        chartOptions: "chartOptions",
        resize: "resize"
      },
      outputs: {
        resized: "resized"
      },
      features: [core_mjs_["ɵɵInheritDefinitionFeature"]],
      decls: 4,
      vars: 5,
      consts: [[1, "wrapper"], ["pie", ""], ["echarts", "", 1, "chart", 3, "options", "merge", "loading"]],
      template: function PieUiComponent_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵelementStart"](0, "div", 0, 1);
          core_mjs_["ɵɵelement"](2, "div", 2);
          core_mjs_["ɵɵpipe"](3, "async");
          core_mjs_["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("options", ctx._chartOptions)("merge", core_mjs_["ɵɵpipeBind1"](3, 3, ctx._chartOptions$))("loading", ctx.loading);
        }
      },
      dependencies: [ngx_echarts/* NgxEchartsDirective */._w, common_mjs_.AsyncPipe],
      styles: [".chart[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n}\n\n.wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}"]
    });
  }
  return PieUiComponent;
})();
;// CONCATENATED MODULE: ./libs/dashboard/widgets/pie/src/lib/pie-container/pie-container.component.ts











let PieContainerComponent = /*#__PURE__*/(() => {
  class PieContainerComponent extends index_ts_.DashboardWidgetComponent {
    constructor(oaRxJsFacade, advancedNameService, formatter, echartsColorTheme) {
      super();
      this.oaRxJsFacade = oaRxJsFacade;
      this.advancedNameService = advancedNameService;
      this.formatter = formatter;
      this.echartsColorTheme = echartsColorTheme;
      this.MAX_NAME_LENGTH = 30;
      this.WAITING_TIME_OBSERVABLE = 3000;
      this.dpConnect$ = null;
      this.eChartConfig = {};
      this.eChartConfigMerge$ = new Subject/* Subject */.x();
      this.dataSubscriptions = new Subscription/* Subscription */.w0();
      this.subscriptions = new Subscription/* Subscription */.w0();
    }
    ngOnDestroy() {
      super.ngOnDestroy();
      this.subscriptions.unsubscribe();
      this.dataSubscriptions.unsubscribe();
      this.disconnectFromExistingsDp();
    }
    ngOnInit() {
      this.setupSettingsSubscription();
    }
    transformToEchartsConfig(settings) {
      let tooltipOption = null;
      let legendOption;
      const color = this.setColors(settings);
      if (settings.tooltip) {
        tooltipOption = this.transformTooltip(settings);
      }
      if (settings.legend) {
        legendOption = this.transformLegend(settings);
      }
      const seriesOption$ = this.transformSeries(settings);
      return seriesOption$.pipe((0,map/* map */.U)(series => {
        return {
          series: series ?? null,
          tooltip: tooltipOption,
          legend: legendOption,
          color
        };
      }));
    }
    /**
     * get updates from OA
     */
    connectToData() {
      this.dpConnect$ = null;
      return this.transformToEchartsConfig(this.settings.chartOptions).pipe((0,takeUntil/* takeUntil */.R)(this.destroy$), (0,tap/* tap */.b)(options => {
        this.eChartConfig.series = options.series;
        this.eChartConfig.tooltip = {
          ...options.tooltip,
          ...this.echartsColorTheme.getTooltipBaseColors()
        };
        this.eChartConfig.legend = options.legend;
        this.eChartConfig.color = options.color;
        const chartSeries = this.getChartSeries();
        const dpList = this.settings.data.filter(dataConf => this.isData(dataConf)).map(dataConf => dataConf.dataPath);
        this.disconnectFromExistingsDp();
        this.dpConnect$ = this.createDpConnectObservable(dpList, chartSeries);
        // remove loading screen after some time
        // only query data which is already in the rx-state
        this.oaRxJsFacade.getDatabyDataPaths(dpList).pipe((0,take/* take */.q)(1), (0,delay/* delay */.g)(150)).subscribe(() => this.finishLoading());
        // initial assignment
        this.eChartConfig = {
          ...this.eChartConfig
        };
        if (this.dpConnect$) {
          this.subscribeToDpConnectObservable();
        }
      }));
    }
    convertRadius(chartType) {
      if (chartType.type === 'pie') {
        return [String(0) + '%', String(chartType.pieRadius) + '%'];
      } else {
        return [String(chartType.radius[0]) + '%', String(chartType.radius[1]) + '%'];
      }
    }
    createDpConnectObservable(dpList, chartSeries) {
      return this.oaRxJsFacade.dpConnect(dpList).pipe((0,map/* map */.U)(resultObject => {
        return resultObject ? Object.keys(resultObject).map((key, idx) => {
          return {
            value: resultObject[key],
            name: chartSeries[idx].name,
            tooltip: chartSeries[idx].tooltip,
            label: chartSeries[idx].label
          };
        }) : [];
      }),
      // distinctUntilChanged((a, b) => a.every((v, i) => v === b[i])),
      (0,shareReplay/* shareReplay */.d)({
        refCount: true,
        bufferSize: 1
      }));
    }
    /**
     * if value subscription is reset, dbDisconnect is called
     */
    disconnectFromExistingsDp() {
      this.dataSubscriptions.unsubscribe();
      this.dataSubscriptions = new Subscription/* Subscription */.w0();
    }
    getChartSeries() {
      return this.eChartConfig.series['data'].map((serie, idx) => ({
        name: serie.name,
        dataPath: this.settings.chartOptions.series[idx].dpe.dataPath,
        tooltip: serie.tooltip,
        label: serie.label
      })).filter(dataConf => this.isData(dataConf));
    }
    getConfigsForSeries(settings) {
      const configs$ = [];
      settings?.chartOptions?.series.forEach(serie => {
        if (serie.dpe.dataPath && (serie?.formatSettings?.type === models_src_index_ts_.FormatSettingsType.Oa || serie?.unitSettings?.type === models_src_index_ts_.UnitSettingsType.Oa)) {
          this.oaRxJsFacade.fetchConfig(serie.dpe.dataPath);
          const config$ = this.oaRxJsFacade.getConfigs(serie.dpe.dataPath).pipe((0,filter/* filter */.h)(value => value !== null && value !== undefined), (0,take/* take */.q)(1), (0,tap/* tap */.b)(value => {
            if (serie.formatSettings?.type == models_src_index_ts_.FormatSettingsType.Oa) {
              serie.formatSettings.value = value.format;
            }
            if (serie.unitSettings?.type == models_src_index_ts_.UnitSettingsType.Oa) {
              serie.unitSettings.value = value.unit;
            }
          }));
          configs$.push(config$);
        }
      });
      if (configs$.length > 0) {
        return (0,forkJoin/* forkJoin */.D)(configs$).pipe((0,takeUntil/* takeUntil */.R)(this.destroy$));
      } else {
        return (0,of.of)(null);
      }
    }
    getFormatStringForSerie(serie, value) {
      if (!serie) {
        return '' + value;
      }
      if (serie.formatSettings.type === models_src_index_ts_.FormatSettingsType.Oa && [models_src_index_ts_.WinccOaTypes.int, models_src_index_ts_.WinccOaTypes.uint, models_src_index_ts_.WinccOaTypes.long, models_src_index_ts_.WinccOaTypes.ulong].includes(serie.dpe.dataType)) {
        serie.formatSettings.value = '%0.0f';
      }
      return this.formatter.transform(value, serie.formatSettings.value);
    }
    /**
     * Checks if data path is set
     * @param data  Data | Data[] | undefined
     * @returns boolean
     */
    isData(data) {
      return !!data && data.dataPath !== undefined;
    }
    /**
     * Checks if data is an array of data
     * @param data  Data | Data[] | undefined
     * @returns boolean
     */
    isDataArray(data) {
      return Array.isArray(data) && data.findIndex(dataConf => dataConf.dataPath != '') !== -1;
    }
    labelFormater(serie, label) {
      return params => {
        const outVal = [];
        if (params.name && (label.formatter === 'name' || label.formatter === 'name_percent' || label.formatter === 'name_value')) {
          outVal.push(params.name);
        }
        if (params.value && (label.formatter === 'value' || label.formatter === 'name_value')) {
          outVal.push(this.getFormatStringForSerie(serie, params.value));
        }
        if (params.percent && (label.formatter === 'percent' || label.formatter === 'name_percent')) {
          outVal.push(params.percent + ' %');
        }
        return outVal.join('    ');
      };
    }
    setColors(settings) {
      const colors = [];
      settings.series.forEach(serie => {
        if (serie.dpe.dataPath) {
          colors.push(serie.color);
        }
      });
      return colors;
    }
    /**
     * Sets up the subscription to the settings
     */
    setupSettingsSubscription() {
      const sub = this.settings$.subscribe(() => {
        if (this.settings) {
          this.startLoading();
        }
        this.updateWidget();
      });
      this.subscriptions.add(sub);
    }
    subscribeToDpConnectObservable() {
      const sub = this.dpConnect$.subscribe(data => this.eChartConfigMerge$.next({
        series: [{
          data
        }]
      }));
      this.dataSubscriptions.add(sub);
    }
    transformEmphasis(settings) {
      return settings.label.show && settings.label.position === 'center' ? {
        label: {
          show: true
        }
      } : undefined;
    }
    transformItemStyle(settings) {
      return settings.chartType.type === 'roundedDoughnut' ? {
        borderRadius: 10,
        borderColor: this.echartsColorTheme.getThemeColor('--color-base1000'),
        borderWidth: 2
      } : undefined;
    }
    transformLabel(label) {
      if (label.show) {
        return {
          show: !(label.position === 'center'),
          position: label.position,
          color: this.echartsColorTheme.getThemeColor('--color-base000')
        };
      } else {
        return {
          show: false
        };
      }
    }
    transformLabelLine(settings) {
      return settings.label.position === 'outside' ? settings.labelLine : undefined;
    }
    // eslint-disable-next-line max-lines-per-function
    transformLegend(settings) {
      const echartLegend = {
        show: settings.legend.show,
        orient: settings.legend.orient,
        top: undefined,
        left: undefined,
        right: undefined,
        bottom: undefined,
        textStyle: {
          color: this.echartsColorTheme.getBaseFontColor()
        }
      };
      if (settings.legend.show) {
        switch (settings.legend.position) {
          case 'topleft':
            echartLegend.top = 0;
            echartLegend.left = 0;
            break;
          case 'topright':
            echartLegend.top = 0;
            echartLegend.right = 0;
            break;
          case 'bottomleft':
            echartLegend.bottom = 0;
            echartLegend.left = 0;
            break;
          case 'bottomright':
            echartLegend.bottom = 0;
            echartLegend.right = 0;
        }
      }
      return echartLegend;
    }
    transformRoseType(settings) {
      return settings.chartType.type === 'nightingale' ? settings.chartType.roseType : undefined;
    }
    transformSerieData(serie, label) {
      const eChartConfig = {
        tooltip: {
          valueFormatter: value => this.getFormatStringForSerie(serie, value)
        },
        label: {
          formatter: this.labelFormater(serie, label)
        }
      };
      let seriesNameConfig$;
      if (serie.dpe.dataPath) {
        seriesNameConfig$ = this.advancedNameService.getAdvancedName(serie.name, this.settings.data, serie.unitSettings?.value, this.MAX_NAME_LENGTH).pipe((0,filter/* filter */.h)(name => name && name.length > 0), (0,timeout/* timeout */.V)({
          each: this.WAITING_TIME_OBSERVABLE,
          with: () => (0,of.of)(' ')
        }), (0,take/* take */.q)(1), (0,map/* map */.U)(name => {
          return {
            name,
            ...eChartConfig
          };
        }));
      } else {
        seriesNameConfig$ = (0,of.of)({
          name: '',
          ...eChartConfig
        });
      }
      return seriesNameConfig$;
    }
    transformSeries(settings) {
      const series = {
        type: 'pie',
        radius: this.convertRadius(settings.chartType),
        roseType: this.transformRoseType(settings),
        itemStyle: this.transformItemStyle(settings),
        label: this.transformLabel(settings.label),
        emphasis: this.transformEmphasis(settings),
        labelLine: this.transformLabelLine(settings),
        data: []
      };
      let seriesData$ = [];
      if (settings.series && settings.series.length > 0) {
        seriesData$ = settings.series.map(serie => this.transformSerieData(serie, settings.label));
      } else {
        seriesData$.push((0,of.of)({}));
      }
      return (0,forkJoin/* forkJoin */.D)(seriesData$).pipe((0,map/* map */.U)(data => {
        return {
          ...series,
          data
        };
      }));
    }
    transformTooltip(settings) {
      if (settings.tooltip.show) {
        return {
          ...settings.tooltip,
          trigger: 'item'
        };
      } else {
        return {
          show: false
        };
      }
    }
    /**
     * when settings change, reconnect to OA
     */
    updateWidget() {
      if (this.settings) {
        if (this.isDataArray(this.settings.data)) {
          this.getConfigsForSeries(this.settings).pipe((0,switchMap/* switchMap */.w)(() => this.connectToData())).subscribe(() => {
            if (!this.dpConnect$) {
              // remove loading if no value$ is set
              this.finishLoading();
            }
          });
        } else {
          this.disconnectFromExistingsDp();
          this.finishLoading();
        }
      }
    }
    static #_ = this.ɵfac = function PieContainerComponent_Factory(t) {
      return new (t || PieContainerComponent)(core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.OaRxJsFacade), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.AdvancedNameService), core_mjs_["ɵɵdirectiveInject"](src_index_ts_.StringFormatPipe), core_mjs_["ɵɵdirectiveInject"](index_ts_.EchartsColorThemeService));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core_mjs_["ɵɵdefineComponent"]({
      type: PieContainerComponent,
      selectors: [["wui-pie-container"]],
      features: [core_mjs_["ɵɵProvidersFeature"]([PieUiComponent]), core_mjs_["ɵɵInheritDefinitionFeature"]],
      decls: 1,
      vars: 4,
      consts: [[1, "full-width-and-height", 3, "chartOptions", "resize", "chartOptions$", "allowAnimation"]],
      template: function PieContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵelement"](0, "wui-pie-ui", 0);
        }
        if (rf & 2) {
          core_mjs_["ɵɵproperty"]("chartOptions", ctx.eChartConfig)("resize", ctx.resize)("chartOptions$", ctx.eChartConfigMerge$)("allowAnimation", true);
        }
      },
      dependencies: [PieUiComponent],
      styles: ["[_nghost-%COMP%] {\n  width: 100%;\n  height: 100%;\n}\n\n.full-width-and-height[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n}"]
    });
  }
  return PieContainerComponent;
})();
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/debounceTime.js
var debounceTime = __webpack_require__(9221);
;// CONCATENATED MODULE: ./libs/dashboard/widgets/pie/src/lib/pie-settings/pie-settings.component.ts
/// <reference types="webpack-env" />




































function PieSettingsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = core_mjs_["ɵɵgetCurrentView"]();
    core_mjs_["ɵɵelementStart"](0, "div", 41)(1, "sie-button", 42);
    core_mjs_["ɵɵlistener"]("click", function PieSettingsComponent_div_17_Template_sie_button_click_1_listener() {
      core_mjs_["ɵɵrestoreView"](_r13);
      const ctx_r12 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r12.addSeries());
    })("dragover", function PieSettingsComponent_div_17_Template_sie_button_dragover_1_listener() {
      core_mjs_["ɵɵrestoreView"](_r13);
      const ctx_r14 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](!ctx_r14.getNextEmptySeries() ? ctx_r14.addSeries() : null);
    });
    core_mjs_["ɵɵtext"](2);
    core_mjs_["ɵɵpipe"](3, "translate");
    core_mjs_["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵproperty"]("type", ctx_r0.ButtonType.Secondary);
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵtextInterpolate1"]("", core_mjs_["ɵɵpipeBind1"](3, 2, "WUI_Dashboard.Widget.Trend.AddSerie"), " ");
  }
}
function PieSettingsComponent_wui_container_18_span_4_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "span");
    core_mjs_["ɵɵtext"](1, " : ");
    core_mjs_["ɵɵelement"](2, "wui-data-display-name", 48);
    core_mjs_["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const serie_r15 = core_mjs_["ɵɵnextContext"]().$implicit;
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵproperty"]("data", serie_r15.get("dpe").value);
  }
}
function PieSettingsComponent_wui_container_18_sie_button_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = core_mjs_["ɵɵgetCurrentView"]();
    core_mjs_["ɵɵelementStart"](0, "sie-button", 49);
    core_mjs_["ɵɵlistener"]("click", function PieSettingsComponent_wui_container_18_sie_button_6_Template_sie_button_click_0_listener() {
      core_mjs_["ɵɵrestoreView"](_r22);
      const serie_r15 = core_mjs_["ɵɵnextContext"]().$implicit;
      const ctx_r20 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r20.removeSerie(serie_r15));
    });
    core_mjs_["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const i_r16 = core_mjs_["ɵɵnextContext"]().index;
    const ctx_r18 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("type", ctx_r18.ButtonType.Ghost)("icon", ctx_r18.Icon.Delete)("iconOnly", true);
    core_mjs_["ɵɵattribute"]("data-cy", "button_trend_settings_delete_series_" + i_r16);
  }
}
const pie_settings_component_c0 = function (a0) {
  return {
    i: a0
  };
};
const pie_settings_component_c1 = function (a0) {
  return [a0];
};
const pie_settings_component_c2 = function () {
  return [];
};
function PieSettingsComponent_wui_container_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r25 = core_mjs_["ɵɵgetCurrentView"]();
    core_mjs_["ɵɵelementStart"](0, "wui-container", 43)(1, "wui-container-title");
    core_mjs_["ɵɵtext"](2);
    core_mjs_["ɵɵpipe"](3, "translate");
    core_mjs_["ɵɵtemplate"](4, PieSettingsComponent_wui_container_18_span_4_Template, 3, 1, "span", 44);
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](5, "wui-container-title-actions");
    core_mjs_["ɵɵtemplate"](6, PieSettingsComponent_wui_container_18_sie_button_6_Template, 1, 4, "sie-button", 45);
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](7, "wui-container-content")(8, "wui-form-group", 46);
    core_mjs_["ɵɵpipe"](9, "isDirty");
    core_mjs_["ɵɵelementStart"](10, "wui-data-selector-input", 47);
    core_mjs_["ɵɵlistener"]("dataSelect", function PieSettingsComponent_wui_container_18_Template_wui_data_selector_input_dataSelect_10_listener() {
      core_mjs_["ɵɵrestoreView"](_r25);
      const ctx_r24 = core_mjs_["ɵɵnextContext"]();
      return core_mjs_["ɵɵresetView"](ctx_r24.populateDataField());
    });
    core_mjs_["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const serie_r15 = ctx.$implicit;
    const i_r16 = ctx.index;
    const ctx_r1 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵpropertyInterpolate"]("formGroupName", i_r16);
    core_mjs_["ɵɵproperty"]("type", ctx_r1.ContainerType.Collapsable)("collapsed", false);
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind2"](3, 14, "WUI_Dashboard.Widget.Trend.Series.Serie", core_mjs_["ɵɵpureFunction1"](19, pie_settings_component_c0, i_r16 + 1)), " ");
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵproperty"]("ngIf", !!serie_r15.get("dpe").value.dataPath);
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵproperty"]("ngIf", ctx_r1.series.controls.length > 1);
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵpropertyInterpolate1"]("for", "input_dpe_", i_r16, "");
    core_mjs_["ɵɵproperty"]("size", ctx_r1.InputGroupSize.Large)("isDirty", core_mjs_["ɵɵpipeBind1"](9, 17, core_mjs_["ɵɵpureFunction1"](21, pie_settings_component_c1, serie_r15.get("dpe"))))("isInvalid", serie_r15.get("dpe").invalid)("isTouched", serie_r15.get("dpe").touched)("validatorErrors", serie_r15.get("dpe").invalid ? core_mjs_["ɵɵpureFunction1"](23, pie_settings_component_c1, ctx_r1.REQUIRED_INPUT_VALIDATION_ERROR) : core_mjs_["ɵɵpureFunction0"](25, pie_settings_component_c2));
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵpropertyInterpolate1"]("id", "input_dpe_", i_r16, "");
    core_mjs_["ɵɵproperty"]("dataTypes", ctx_r1.dataTypes);
  }
}
function PieSettingsComponent_p_slider_61_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "p-slider", 50);
  }
  if (rf & 2) {
    core_mjs_["ɵɵproperty"]("min", 1)("max", 100);
  }
}
function PieSettingsComponent_p_slider_62_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "p-slider", 51);
  }
  if (rf & 2) {
    core_mjs_["ɵɵproperty"]("range", true)("min", 0)("max", 100);
  }
}
function PieSettingsComponent_wui_input_group_63_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "wui-input-group", 25);
    core_mjs_["ɵɵpipe"](1, "translate");
    core_mjs_["ɵɵpipe"](2, "isDirty");
    core_mjs_["ɵɵelementStart"](3, "sie-select-wrapper")(4, "select", 52)(5, "option", 53);
    core_mjs_["ɵɵtext"](6);
    core_mjs_["ɵɵpipe"](7, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](8, "option", 54);
    core_mjs_["ɵɵtext"](9);
    core_mjs_["ɵɵpipe"](10, "translate");
    core_mjs_["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r4 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r4.InputGroupSize.Small)("label", core_mjs_["ɵɵpipeBind1"](1, 5, "WDK_pie.Widget.pie.roseType.title"))("isDirty", core_mjs_["ɵɵpipeBind1"](2, 7, core_mjs_["ɵɵpureFunction1"](13, pie_settings_component_c1, ctx_r4.roseTypeControl)));
    core_mjs_["ɵɵadvance"](6);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](7, 9, "WDK_pie.Widget.pie.roseType.area"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](10, 11, "WDK_pie.Widget.pie.roseType.radius"), " ");
  }
}
function PieSettingsComponent_wui_checkbox_66_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "wui-checkbox", 55);
  }
  if (rf & 2) {
    const ctx_r5 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r5.InputGroupSize.Small);
  }
}
function PieSettingsComponent_wui_input_group_71_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "wui-input-group", 56);
    core_mjs_["ɵɵpipe"](1, "isDirty");
    core_mjs_["ɵɵelementStart"](2, "sie-select-wrapper")(3, "select", 57)(4, "option", 58);
    core_mjs_["ɵɵtext"](5);
    core_mjs_["ɵɵpipe"](6, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](7, "option", 59);
    core_mjs_["ɵɵtext"](8);
    core_mjs_["ɵɵpipe"](9, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](10, "option", 60);
    core_mjs_["ɵɵtext"](11);
    core_mjs_["ɵɵpipe"](12, "translate");
    core_mjs_["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r6 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r6.InputGroupSize.Small)("isDirty", core_mjs_["ɵɵpipeBind1"](1, 5, core_mjs_["ɵɵpureFunction1"](13, pie_settings_component_c1, ctx_r6.labelPositionControl)));
    core_mjs_["ɵɵadvance"](5);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](6, 7, "WDK_pie.Widget.pie.chartLabel.position.outside"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](9, 9, "WDK_pie.Widget.pie.chartLabel.position.inside"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](12, 11, "WDK_pie.Widget.pie.chartLabel.position.center"), " ");
  }
}
const pie_settings_component_c3 = function () {
  return ["chartOptions", "labelLine", "show"];
};
function PieSettingsComponent_wui_checkbox_72_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelement"](0, "wui-checkbox", 61);
    core_mjs_["ɵɵpipe"](1, "translate");
    core_mjs_["ɵɵpipe"](2, "translate");
  }
  if (rf & 2) {
    const ctx_r7 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("heading", core_mjs_["ɵɵpipeBind1"](1, 4, "WDK_pie.Widget.pie.chartLabelLine.title"))("label", core_mjs_["ɵɵpipeBind1"](2, 6, "WDK_pie.Widget.pie.chartLabelLine.show"))("size", ctx_r7.InputGroupSize.Small)("formControl", ctx_r7.settingsForm.get(core_mjs_["ɵɵpureFunction0"](8, pie_settings_component_c3)));
  }
}
function PieSettingsComponent_wui_input_group_73_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "wui-input-group", 62);
    core_mjs_["ɵɵpipe"](1, "translate");
    core_mjs_["ɵɵpipe"](2, "isDirty");
    core_mjs_["ɵɵelementStart"](3, "sie-select-wrapper")(4, "select", 63)(5, "option", 64);
    core_mjs_["ɵɵtext"](6);
    core_mjs_["ɵɵpipe"](7, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](8, "option", 65);
    core_mjs_["ɵɵtext"](9);
    core_mjs_["ɵɵpipe"](10, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](11, "option", 66);
    core_mjs_["ɵɵtext"](12);
    core_mjs_["ɵɵpipe"](13, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](14, "option", 67);
    core_mjs_["ɵɵtext"](15);
    core_mjs_["ɵɵpipe"](16, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](17, "option", 68);
    core_mjs_["ɵɵtext"](18);
    core_mjs_["ɵɵpipe"](19, "translate");
    core_mjs_["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r8 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r8.InputGroupSize.Small)("label", core_mjs_["ɵɵpipeBind1"](1, 8, "WDK_pie.Widget.pie.chartLabel.formatter.title"))("isDirty", core_mjs_["ɵɵpipeBind1"](2, 10, core_mjs_["ɵɵpureFunction1"](22, pie_settings_component_c1, ctx_r8.labelFormatterControl)));
    core_mjs_["ɵɵadvance"](6);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](7, 12, "WDK_pie.Widget.pie.chartLabel.formatter.name"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](10, 14, "WDK_pie.Widget.pie.chartLabel.formatter.value"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](13, 16, "WDK_pie.Widget.pie.chartLabel.formatter.percent"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](16, 18, "WDK_pie.Widget.pie.chartLabel.formatter.name_value"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](19, 20, "WDK_pie.Widget.pie.chartLabel.formatter.name_percent"), " ");
  }
}
function PieSettingsComponent_wui_input_group_76_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "wui-input-group", 69);
    core_mjs_["ɵɵpipe"](1, "isDirty");
    core_mjs_["ɵɵelementStart"](2, "sie-select-wrapper")(3, "select", 70)(4, "option", 71);
    core_mjs_["ɵɵtext"](5);
    core_mjs_["ɵɵpipe"](6, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](7, "option", 72);
    core_mjs_["ɵɵtext"](8);
    core_mjs_["ɵɵpipe"](9, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](10, "option", 73);
    core_mjs_["ɵɵtext"](11);
    core_mjs_["ɵɵpipe"](12, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](13, "option", 74);
    core_mjs_["ɵɵtext"](14);
    core_mjs_["ɵɵpipe"](15, "translate");
    core_mjs_["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r9 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r9.InputGroupSize.Small)("isDirty", core_mjs_["ɵɵpipeBind1"](1, 6, core_mjs_["ɵɵpureFunction1"](16, pie_settings_component_c1, ctx_r9.legendPositionControl)));
    core_mjs_["ɵɵadvance"](5);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](6, 8, "WUI_Dashboard.Widget.Trend.Legend.Position.TopLeft"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](9, 10, "WUI_Dashboard.Widget.Trend.Legend.Position.TopRight"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](12, 12, "WUI_Dashboard.Widget.Trend.Legend.Position.BottomLeft"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](15, 14, "WUI_Dashboard.Widget.Trend.Legend.Position.BottomRight"), " ");
  }
}
function PieSettingsComponent_wui_input_group_77_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "wui-input-group", 25);
    core_mjs_["ɵɵpipe"](1, "translate");
    core_mjs_["ɵɵpipe"](2, "isDirty");
    core_mjs_["ɵɵelementStart"](3, "sie-select-wrapper")(4, "select", 75)(5, "option", 76);
    core_mjs_["ɵɵtext"](6);
    core_mjs_["ɵɵpipe"](7, "translate");
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](8, "option", 77);
    core_mjs_["ɵɵtext"](9);
    core_mjs_["ɵɵpipe"](10, "translate");
    core_mjs_["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r10 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵproperty"]("size", ctx_r10.InputGroupSize.Small)("label", core_mjs_["ɵɵpipeBind1"](1, 5, "WDK_pie.Widget.pie.legend.orient"))("isDirty", core_mjs_["ɵɵpipeBind1"](2, 7, core_mjs_["ɵɵpureFunction1"](13, pie_settings_component_c1, ctx_r10.legendOrientControl)));
    core_mjs_["ɵɵadvance"](6);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](7, 9, "WUI_Dashboard.Widget.Trend.Legend.Orient.Horizontal"), " ");
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](10, 11, "WUI_Dashboard.Widget.Trend.Legend.Orient.Vertical"), " ");
  }
}
function PieSettingsComponent_wui_container_79_span_5_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "span");
    core_mjs_["ɵɵtext"](1, " : ");
    core_mjs_["ɵɵelement"](2, "wui-data-display-name", 48);
    core_mjs_["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const serie_r26 = core_mjs_["ɵɵnextContext"]().$implicit;
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵproperty"]("data", serie_r26.get("dpe").value);
  }
}
const pie_settings_component_c4 = function (a0, a1) {
  return [a0, a1];
};
function PieSettingsComponent_wui_container_79_Template(rf, ctx) {
  if (rf & 1) {
    core_mjs_["ɵɵelementStart"](0, "wui-container", 43)(1, "wui-container-title")(2, "span");
    core_mjs_["ɵɵtext"](3);
    core_mjs_["ɵɵpipe"](4, "translate");
    core_mjs_["ɵɵtemplate"](5, PieSettingsComponent_wui_container_79_span_5_Template, 3, 1, "span", 44);
    core_mjs_["ɵɵelementEnd"]()();
    core_mjs_["ɵɵelementStart"](6, "wui-container-content")(7, "wui-form-group", 78);
    core_mjs_["ɵɵpipe"](8, "isDirty");
    core_mjs_["ɵɵpipe"](9, "hasRequiredField");
    core_mjs_["ɵɵelement"](10, "wui-advanced-name-input", 79);
    core_mjs_["ɵɵelementEnd"]();
    core_mjs_["ɵɵelementStart"](11, "wui-form-group", 9)(12, "wui-input-group", 80);
    core_mjs_["ɵɵpipe"](13, "isDirty");
    core_mjs_["ɵɵelement"](14, "wui-color-picker", 81);
    core_mjs_["ɵɵelementEnd"]()();
    core_mjs_["ɵɵelement"](15, "wui-format-settings", 82)(16, "wui-unit-settings", 83);
    core_mjs_["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const serie_r26 = ctx.$implicit;
    const i_r27 = ctx.index;
    const ctx_r11 = core_mjs_["ɵɵnextContext"]();
    core_mjs_["ɵɵpropertyInterpolate"]("formGroupName", i_r27);
    core_mjs_["ɵɵproperty"]("type", ctx_r11.ContainerType.Collapsable)("collapsed", true);
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵattribute"]("data-cy", "container_Titel_" + i_r27);
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind2"](4, 26, "WUI_Dashboard.Widget.Trend.Series.Serie", core_mjs_["ɵɵpureFunction1"](35, pie_settings_component_c0, i_r27 + 1)), " ");
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵproperty"]("ngIf", !!serie_r26.get("dpe").value.dataPath);
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵpropertyInterpolate1"]("for", "input_name_", i_r27, "");
    core_mjs_["ɵɵproperty"]("size", ctx_r11.InputGroupSize.Large)("isDirty", core_mjs_["ɵɵpipeBind1"](8, 29, core_mjs_["ɵɵpureFunction1"](37, pie_settings_component_c1, serie_r26.get("name"))))("isInvalid", serie_r26.get("name").invalid)("isTouched", serie_r26.get("name").touched)("isRequired", core_mjs_["ɵɵpipeBind1"](9, 31, serie_r26.get("name")));
    core_mjs_["ɵɵadvance"](3);
    core_mjs_["ɵɵpropertyInterpolate1"]("id", "input_name_", i_r27, "");
    core_mjs_["ɵɵproperty"]("data", serie_r26.get("dpe").value)("validatorErrors", core_mjs_["ɵɵpureFunction2"](39, pie_settings_component_c4, serie_r26.get("name").getError("notEmptyCheck"), serie_r26.get("name").getError("maxLengthCheck")))("maxLength", ctx_r11.maxNameLength);
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵproperty"]("size", ctx_r11.InputGroupSize.Small);
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵpropertyInterpolate1"]("for", "serie_color_", i_r27, "");
    core_mjs_["ɵɵproperty"]("isDirty", core_mjs_["ɵɵpipeBind1"](13, 33, core_mjs_["ɵɵpureFunction1"](42, pie_settings_component_c1, serie_r26.get("color"))));
    core_mjs_["ɵɵattribute"]("data-cy", "input_pie_settings_color_" + i_r27);
    core_mjs_["ɵɵadvance"](2);
    core_mjs_["ɵɵpropertyInterpolate1"]("id", "serie_color_", i_r27, "");
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵproperty"]("dataPath", ctx_r11.getDataPathForSerie(i_r27))("dataType", ctx_r11.getDataTypeForSerie(i_r27))("validatorErrors", core_mjs_["ɵɵpureFunction1"](44, pie_settings_component_c1, serie_r26.get("formatSettings").getError("maxValue")));
    core_mjs_["ɵɵadvance"](1);
    core_mjs_["ɵɵproperty"]("dataPath", ctx_r11.getDataPathForSerie(i_r27))("validatorErrors", core_mjs_["ɵɵpureFunction1"](46, pie_settings_component_c1, serie_r26.get("unitSettings").getError("maxLengthCheck")));
  }
}
const pie_settings_component_c5 = function () {
  return ["chartOptions", "series"];
};
const pie_settings_component_c6 = function () {
  return ["chartOptions", "chartType", "type"];
};
const pie_settings_component_c7 = function () {
  return ["chartOptions", "label", "show"];
};
const pie_settings_component_c8 = function () {
  return ["chartOptions", "label", "position"];
};
const pie_settings_component_c9 = function () {
  return ["chartOptions", "legend", "show"];
};
let PieSettingsComponent = /*#__PURE__*/(() => {
  class PieSettingsComponent extends index_ts_.DashboardWidgetSettingsComponent {
    constructor(notificationService, formBuilder, translateService, dashboardFacade, contextRegionFacade) {
      super(dashboardFacade, contextRegionFacade);
      this.notificationService = notificationService;
      this.formBuilder = formBuilder;
      this.translateService = translateService;
      this.REQUIRED_INPUT_VALIDATION_ERROR = {
        errorKey: 'required',
        message: 'WUI_Dashboard.Widget.Trend.Series.DpeError',
        params: {},
        condition: []
      };
      this.SERIES_NAME_FIELD_TRANSLATION_KEY = 'WUI_Dashboard.Widget.Trend.Series.Name';
      this.maxNameLength = 30;
      this.ButtonType = models_src_index_ts_.ButtonType;
      this.Color = models_src_index_ts_.Color;
      this.ContainerType = models_src_index_ts_.ContainerType;
      this.Icon = models_src_index_ts_.Icon;
      this.InputGroupSize = models_src_index_ts_.InputGroupSize;
      this.assetUrl = __webpack_require__.p;
      this.queryAlertColor = models_src_index_ts_.Color.Error;
      this.queryAlertIcon = models_src_index_ts_.Icon.CancelCircle;
      this.queryPostfixDisabled = false;
    }
    get labelFormatterControl() {
      return this.settingsForm.get(['chartOptions', 'label', 'formatter']);
    }
    get labelPositionControl() {
      return this.settingsForm.get(['chartOptions', 'label', 'position']);
    }
    get legendOrientControl() {
      return this.settingsForm.get(['chartOptions', 'legend', 'orient']);
    }
    get legendPositionControl() {
      return this.settingsForm.get(['chartOptions', 'legend', 'position']);
    }
    get pieRadiusControl() {
      return this.settingsForm.get(['chartOptions', 'chartType', 'pieRadius']);
    }
    get radiusControl() {
      return this.settingsForm.get(['chartOptions', 'chartType', 'radius']);
    }
    get roseTypeControl() {
      return this.settingsForm.get(['chartOptions', 'chartType', 'roseType']);
    }
    get series() {
      return this.settingsForm.get(['chartOptions', 'series']);
    }
    get typeControl() {
      return this.settingsForm.get(['chartOptions', 'chartType', 'type']);
    }
    addSeries(data = {
      dataPath: null,
      dataType: null
    }) {
      const series = this.series;
      if (series.controls.length >= 10) {
        return;
      }
      series.push(this.formBuilder.group({
        name: [{
          queryName: true,
          nameSource: models_src_index_ts_.TitleSource.Description,
          nameDataPath: data.dataPath
        }, [src_index_ts_.AdvancedNameValidators.required({
          _field: this.SERIES_NAME_FIELD_TRANSLATION_KEY
        }, undefined, this.translateService), src_index_ts_.AdvancedNameValidators.maxLength(this.maxNameLength, {
          _field: this.SERIES_NAME_FIELD_TRANSLATION_KEY
        }, undefined, this.translateService)]],
        dpe: [data, src_index_ts_.DataSelectorValidators.required],
        color: [this.getNextColor()],
        formatSettings: this.setFormatSettingsFormGroup(),
        unitSettings: this.setUnitSettingsFormGroup()
      }));
    }
    formInit() {
      this.settingsForm = this.formBuilder.nonNullable.group({
        data: [this.settings?.data ?? []],
        generalSettings: [this.settings?.generalSettings ?? this.getGeneralSetting()],
        chartOptions: this.formBuilder.nonNullable.group({
          series: this.formBuilder.nonNullable.array([]),
          chartType: this.formBuilder.nonNullable.group({
            type: [this.settings?.chartOptions.chartType.type ?? 'pie'],
            pieRadius: [this.settings?.chartOptions.chartType.pieRadius ?? 50],
            radius: [this.settings?.chartOptions.chartType.radius ?? [25, 75]],
            roseType: [this.settings?.chartOptions.chartType.roseType ?? 'area']
          }),
          legend: this.formBuilder.nonNullable.group({
            show: [this.settings?.chartOptions.legend.show ?? true],
            orient: [this.settings?.chartOptions.legend.orient ?? 'vertical'],
            position: [this.settings?.chartOptions.legend.position ?? 'topright']
          }),
          tooltip: this.formBuilder.nonNullable.group({
            show: [this.settings?.chartOptions.tooltip.show ?? true]
          }),
          label: this.formBuilder.nonNullable.group({
            show: [this.settings?.chartOptions.label.show ?? true],
            position: [this.settings?.chartOptions.label.position ?? 'outside'],
            formatter: [this.settings?.chartOptions.label.formatter ?? 'value']
          }),
          labelLine: this.formBuilder.nonNullable.group({
            show: [this.settings?.chartOptions.labelLine.show ?? true]
          })
        })
      });
    }
    getDataPathForSerie(index) {
      const serie = this.series.controls;
      return serie[index]?.get('dpe')?.value['dataPath'];
    }
    getDataTypeForSerie(index) {
      const serie = this.series.controls;
      return serie[index]?.get('dpe')?.value['dataType'];
    }
    getNextEmptySeries() {
      return this.series.controls.find(serie => !serie.get('dpe')?.value || !serie.get('dpe')?.value.dataPath);
    }
    ngOnInit() {
      // Update form with previously stored settings
      this.formInit();
      this.groupControls();
      if (this.settings) {
        // fill in each data series
        this.settings.chartOptions.series.forEach(serie => {
          this.series.push(this.createSeriesFromControl(serie));
        });
        // update all form fields
      }
      this.initialFormValue = this.settingsForm.value;
      this.data$ = this.getDataObservable(this.settingsForm);
      // any form changes will be forwarded to container component after some time
      this.subscriptions.push(this.settingsForm.valueChanges.pipe((0,debounceTime/* debounceTime */.b)(500)).subscribe(settings => {
        if (!this.unsavedChanges(settings, this.initialFormValue)) this.settingsForm.markAsPristine();
        this.emitSettings(settings);
        this.updateFormState(this.settingsForm);
      }));
      this.resetFromState(this.settingsForm);
      this.updateFormState(this.settingsForm);
      this.emitSettings(this.settingsForm.value);
      super.ngOnInit();
    }
    onDataDrop(data) {
      let notAddedCount = 0;
      data.forEach(data => {
        // re-use empty series
        const serie = this.getNextEmptySeries();
        if (serie) {
          serie.get('dpe')?.patchValue(data);
        } else if (this.series.controls.length < 10) {
          this.addSeries(data);
        } else {
          notAddedCount++;
        }
      });
      this.populateDataField();
      if (notAddedCount > 0) {
        this.notificationService.createMultiLangNotification(models_src_index_ts_.NotificationType.Informative, 'WUI_General.Notification.Information', 'WUI_Dashboard.Widget.Trend.MaxSeries', undefined, 8000, {
          availableData: data.length,
          notSuitableData: notAddedCount
        });
      }
    }
    populateDataField() {
      const tmpData = [];
      this.series.controls.forEach(serie => {
        const data = serie.get('dpe')?.value;
        if (data && data.dataPath && tmpData.every(tmp => tmp.dataPath !== data.dataPath)) {
          tmpData.push(data);
        }
      });
      this.settingsForm.get('data')?.setValue(tmpData);
    }
    removeSerie(serie) {
      const series = this.series;
      const idx = series.controls.findIndex(seriesItem => seriesItem === serie);
      if (idx > -1) {
        series.removeAt(idx);
        this.populateDataField();
      }
    }
    createSeriesFromControl(serie) {
      return this.formBuilder.nonNullable.group({
        name: [serie.name, [src_index_ts_.AdvancedNameValidators.required({
          _field: this.SERIES_NAME_FIELD_TRANSLATION_KEY
        }, undefined, this.translateService), src_index_ts_.AdvancedNameValidators.maxLength(this.maxNameLength, {
          _field: this.SERIES_NAME_FIELD_TRANSLATION_KEY
        }, undefined, this.translateService)]],
        dpe: [serie.dpe, src_index_ts_.DataSelectorValidators.required],
        color: [serie.color ?? null],
        formatSettings: this.setFormatSettingsFormGroup(serie.formatSettings),
        unitSettings: this.setUnitSettingsFormGroup(serie.unitSettings)
      });
    }
    getNextColor() {
      return models_src_index_ts_.MDSP_COLORS.find(color => {
        return !this.series.controls.find(serie => serie.get(['color'])?.value === color);
      });
    }
    groupControls() {
      this.chartTypeGroup = [this.settingsForm.get(['chartOptions', 'chartType', 'radius']), this.settingsForm.get(['chartOptions', 'chartType', 'roseType'])];
      this.widgetOptionsGroup = [this.settingsForm.get(['chartOptions', 'tooltip']), this.settingsForm.get(['chartOptions', 'legend']), this.settingsForm.get(['chartOptions', 'chartType'])];
    }
    static #_ = this.ɵfac = function PieSettingsComponent_Factory(t) {
      return new (t || PieSettingsComponent)(core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.WebUiNotificationsService), core_mjs_["ɵɵdirectiveInject"](forms_mjs_.UntypedFormBuilder), core_mjs_["ɵɵdirectiveInject"](ngx_translate_core_mjs_.TranslateService), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.DashboardFacade), core_mjs_["ɵɵdirectiveInject"](abstract_services_src_index_ts_.ContextRegionFacade));
    };
    static #_2 = this.ɵcmp = /*@__PURE__*/core_mjs_["ɵɵdefineComponent"]({
      type: PieSettingsComponent,
      selectors: [["wui-pie-settings"]],
      features: [core_mjs_["ɵɵInheritDefinitionFeature"]],
      decls: 80,
      vars: 126,
      consts: [[3, "formGroup"], [3, "type", "isDirty", "isInvalid"], ["formControlName", "generalSettings", 3, "data"], ["formGroupName", "chartOptions", 3, "type", "collapsed", "isDirty", "isInvalid"], ["formArrayName", "series"], [3, "dataTypes", "structureMode", "dataSelect"], ["style", "text-align: right; flex-grow: 1", 4, "ngIf"], [3, "type", "collapsed", "formGroupName", 4, "ngFor", "ngForOf"], ["formGroupName", "chartOptions", 3, "type", "collapsed", "isInvalid", "isDirty"], [3, "size"], ["formGroupName", "chartType", 3, "size", "label", "isDirty"], [1, "radioButtonWrapper"], ["type", "radio", "formControlName", "type", "id", "type-pie", "value", "pie", "data-cy", "radio_button_pie_chart", 1, "inputGroup__radioButton"], ["for", "type-pie"], ["alt", "Pie image", "title", "Pie image", 1, "custom-image", 3, "src"], ["type", "radio", "formControlName", "type", "id", "type-nightingale", "value", "nightingale", "data-cy", "radio_button_nightingale_chart", 1, "inputGroup__radioButton"], ["for", "type-nightingale"], ["alt", "Nightingale image", "title", "Nightingale image", 1, "custom-image", 3, "src"], ["type", "radio", "formControlName", "type", "id", "type-doughnut", "value", "doughnut", "data-cy", "radio_button_doughnut_chart", 1, "inputGroup__radioButton"], ["for", "type-doughnut"], ["alt", "Doughnut image", "title", "Doughnut image", 1, "custom-image", 3, "src"], ["type", "radio", "formControlName", "type", "id", "type-roundedDoughnut", "value", "roundedDoughnut", "data-cy", "radio_button_rounded_doughnut_chart", 1, "inputGroup__radioButton"], ["for", "type-roundedDoughnut"], ["alt", "Rounded Doughnut image", "title", "Rounded Doughnut image", 1, "custom-image", 3, "src"], ["formGroupName", "chartType", 3, "omitInputGroup", "isDirty", "isInvalid", "isTouched", "size"], [3, "size", "label", "isDirty"], [2, "padding-top", "0.75rem"], ["formControlName", "pieRadius", 3, "min", "max", 4, "ngIf"], ["formControlName", "radius", 3, "range", "min", "max", 4, "ngIf"], [3, "size", "label", "isDirty", 4, "ngIf"], ["formGroupName", "tooltip"], ["label", "WUI_Dashboard.Widget.Trend.ShowTooltip", "data-cy", "checkbox_pie_settings_tooltip", "formControlName", "show", "for", "showTooltip", 3, "size", 4, "wuiFormGroupItems"], [3, "omitInputGroup", "size"], ["for", "showLabel", 2, "margin-bottom", "0.5rem", 3, "heading", "label", "size", "formControl"], ["label", "WUI_Dashboard.Widget.Trend.Legend.Position.Title", "formGroupName", "label", "style", "margin-left: 0.5rem", 3, "size", "isDirty", 4, "ngIf"], ["for", "showLabelLine", "style", "margin-left: 0.5rem", 3, "heading", "label", "size", "formControl", 4, "ngIf"], ["formGroupName", "label", "style", "margin-left: 0.5rem", 3, "size", "label", "isDirty", 4, "ngIf"], ["formGroupName", "legend", 3, "size", "omitInputGroup"], ["heading", "WUI_Dashboard.Widget.Trend.Legend.Title", "label", "WUI_Dashboard.Widget.Trend.Legend.Show", "for", "showLegend", "data-cy", "checkbox_pie_settings_showLegend", 2, "margin-bottom", "0.5rem", 3, "size", "formControl"], ["label", "WUI_Dashboard.Widget.Trend.Legend.Position.Title", "style", "margin-left: 0.5rem", 3, "size", "isDirty", 4, "ngIf"], ["formGroupName", "series"], [2, "text-align", "right", "flex-grow", "1"], ["data-cy", "button_trend_settings_addSeries", 1, "button--secondary", 3, "type", "click", "dragover"], [3, "type", "collapsed", "formGroupName"], [4, "ngIf"], ["class", "button-right", 3, "type", "icon", "iconOnly", "click", 4, "ngIf"], [3, "size", "for", "isDirty", "isInvalid", "isTouched", "validatorErrors"], ["formControlName", "dpe", 3, "dataTypes", "id", "dataSelect"], [3, "data"], [1, "button-right", 3, "type", "icon", "iconOnly", "click"], ["formControlName", "pieRadius", 3, "min", "max"], ["formControlName", "radius", 3, "range", "min", "max"], ["sieSelect", "", "id", "roseType", "formControlName", "roseType", "data-cy", "select_rose_type"], ["value", "area"], ["value", "radius"], ["label", "WUI_Dashboard.Widget.Trend.ShowTooltip", "data-cy", "checkbox_pie_settings_tooltip", "formControlName", "show", "for", "showTooltip", 3, "size"], ["label", "WUI_Dashboard.Widget.Trend.Legend.Position.Title", "formGroupName", "label", 2, "margin-left", "0.5rem", 3, "size", "isDirty"], ["sieSelect", "", "id", "labelPosition", "formControlName", "position", "data-cy", "select_label_position"], ["value", "outside"], ["value", "inside"], ["value", "center"], ["for", "showLabelLine", 2, "margin-left", "0.5rem", 3, "heading", "label", "size", "formControl"], ["formGroupName", "label", 2, "margin-left", "0.5rem", 3, "size", "label", "isDirty"], ["sieSelect", "", "id", "labelFormatter", "formControlName", "formatter", "data-cy", "select_pie_settings_text"], ["value", "name"], ["value", "value"], ["value", "percent"], ["value", "name_value"], ["value", "name_percent"], ["label", "WUI_Dashboard.Widget.Trend.Legend.Position.Title", 2, "margin-left", "0.5rem", 3, "size", "isDirty"], ["sieSelect", "", "id", "legendPosition", "formControlName", "position", "data-cy", "select_legend_position"], ["value", "topleft"], ["value", "topright"], ["value", "bottomleft"], ["value", "bottomright"], ["sieSelect", "", "id", "legendOrient", "formControlName", "orient", "data-cy", "select_trend_settings_LegendOrient"], ["value", "horizontal"], ["value", "vertical"], ["label", "WUI_Dashboard.Widget.Trend.Series.Name", 3, "size", "for", "isDirty", "isInvalid", "isTouched", "isRequired"], ["formControlName", "name", 3, "data", "validatorErrors", "id", "maxLength"], ["label", "WUI_Dashboard.Widget.Trend.Series.LineStyle.Color", 3, "for", "isDirty"], ["formControlName", "color", 3, "id"], ["formControlName", "formatSettings", "id", "formatSettings", 3, "dataPath", "dataType", "validatorErrors"], ["formControlName", "unitSettings", "id", "unitSettings", 3, "dataPath", "validatorErrors"]],
      template: function PieSettingsComponent_Template(rf, ctx) {
        if (rf & 1) {
          core_mjs_["ɵɵelementStart"](0, "wui-form", 0)(1, "wui-container-group")(2, "wui-container", 1);
          core_mjs_["ɵɵpipe"](3, "isDirty");
          core_mjs_["ɵɵelementStart"](4, "wui-container-title");
          core_mjs_["ɵɵtext"](5);
          core_mjs_["ɵɵpipe"](6, "translate");
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](7, "wui-container-content");
          core_mjs_["ɵɵelement"](8, "wui-general-settings", 2);
          core_mjs_["ɵɵpipe"](9, "async");
          core_mjs_["ɵɵelementEnd"]()();
          core_mjs_["ɵɵelementStart"](10, "wui-container", 3);
          core_mjs_["ɵɵpipe"](11, "isDirty");
          core_mjs_["ɵɵelementStart"](12, "wui-container-title");
          core_mjs_["ɵɵtext"](13);
          core_mjs_["ɵɵpipe"](14, "translate");
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](15, "wui-container-content", 4)(16, "wui-data-selector-input", 5);
          core_mjs_["ɵɵlistener"]("dataSelect", function PieSettingsComponent_Template_wui_data_selector_input_dataSelect_16_listener($event) {
            return ctx.onDataDrop($event);
          });
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵtemplate"](17, PieSettingsComponent_div_17_Template, 4, 4, "div", 6);
          core_mjs_["ɵɵtemplate"](18, PieSettingsComponent_wui_container_18_Template, 11, 26, "wui-container", 7);
          core_mjs_["ɵɵelementEnd"]()();
          core_mjs_["ɵɵelementStart"](19, "wui-container", 8);
          core_mjs_["ɵɵpipe"](20, "isInvalid");
          core_mjs_["ɵɵpipe"](21, "isDirty");
          core_mjs_["ɵɵelementStart"](22, "wui-container-title");
          core_mjs_["ɵɵtext"](23);
          core_mjs_["ɵɵpipe"](24, "translate");
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](25, "wui-container-content")(26, "wui-form-group", 9)(27, "wui-input-group", 10);
          core_mjs_["ɵɵpipe"](28, "translate");
          core_mjs_["ɵɵpipe"](29, "isDirty");
          core_mjs_["ɵɵelementStart"](30, "div", 11);
          core_mjs_["ɵɵelement"](31, "input", 12);
          core_mjs_["ɵɵelementStart"](32, "label", 13);
          core_mjs_["ɵɵtext"](33);
          core_mjs_["ɵɵpipe"](34, "translate");
          core_mjs_["ɵɵelement"](35, "img", 14);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelement"](36, "input", 15);
          core_mjs_["ɵɵelementStart"](37, "label", 16);
          core_mjs_["ɵɵtext"](38);
          core_mjs_["ɵɵpipe"](39, "translate");
          core_mjs_["ɵɵelement"](40, "img", 17);
          core_mjs_["ɵɵelementEnd"]()();
          core_mjs_["ɵɵelementStart"](41, "div", 11);
          core_mjs_["ɵɵelement"](42, "input", 18);
          core_mjs_["ɵɵelementStart"](43, "label", 19);
          core_mjs_["ɵɵtext"](44);
          core_mjs_["ɵɵpipe"](45, "translate");
          core_mjs_["ɵɵelement"](46, "img", 20);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelement"](47, "input", 21);
          core_mjs_["ɵɵelementStart"](48, "label", 22);
          core_mjs_["ɵɵtext"](49);
          core_mjs_["ɵɵpipe"](50, "translate");
          core_mjs_["ɵɵelement"](51, "img", 23);
          core_mjs_["ɵɵelementEnd"]()()()();
          core_mjs_["ɵɵelementStart"](52, "wui-form-group", 24);
          core_mjs_["ɵɵpipe"](53, "isDirty");
          core_mjs_["ɵɵpipe"](54, "isInvalid");
          core_mjs_["ɵɵpipe"](55, "isTouched");
          core_mjs_["ɵɵelementStart"](56, "wui-input-group", 25);
          core_mjs_["ɵɵpipe"](57, "translate");
          core_mjs_["ɵɵpipe"](58, "isDirty");
          core_mjs_["ɵɵpipe"](59, "isDirty");
          core_mjs_["ɵɵelement"](60, "div", 26);
          core_mjs_["ɵɵtemplate"](61, PieSettingsComponent_p_slider_61_Template, 1, 2, "p-slider", 27);
          core_mjs_["ɵɵtemplate"](62, PieSettingsComponent_p_slider_62_Template, 1, 3, "p-slider", 28);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵtemplate"](63, PieSettingsComponent_wui_input_group_63_Template, 11, 15, "wui-input-group", 29);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](64, "wui-form-group", 9);
          core_mjs_["ɵɵelementContainerStart"](65, 30);
          core_mjs_["ɵɵtemplate"](66, PieSettingsComponent_wui_checkbox_66_Template, 1, 1, "wui-checkbox", 31);
          core_mjs_["ɵɵelementContainerEnd"]();
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](67, "wui-form-group", 32);
          core_mjs_["ɵɵelement"](68, "wui-checkbox", 33);
          core_mjs_["ɵɵpipe"](69, "translate");
          core_mjs_["ɵɵpipe"](70, "translate");
          core_mjs_["ɵɵtemplate"](71, PieSettingsComponent_wui_input_group_71_Template, 13, 15, "wui-input-group", 34);
          core_mjs_["ɵɵtemplate"](72, PieSettingsComponent_wui_checkbox_72_Template, 3, 9, "wui-checkbox", 35);
          core_mjs_["ɵɵtemplate"](73, PieSettingsComponent_wui_input_group_73_Template, 20, 24, "wui-input-group", 36);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](74, "wui-form-group", 37);
          core_mjs_["ɵɵelement"](75, "wui-checkbox", 38);
          core_mjs_["ɵɵtemplate"](76, PieSettingsComponent_wui_input_group_76_Template, 16, 18, "wui-input-group", 39);
          core_mjs_["ɵɵtemplate"](77, PieSettingsComponent_wui_input_group_77_Template, 11, 15, "wui-input-group", 29);
          core_mjs_["ɵɵelementEnd"]();
          core_mjs_["ɵɵelementStart"](78, "div", 40);
          core_mjs_["ɵɵtemplate"](79, PieSettingsComponent_wui_container_79_Template, 17, 48, "wui-container", 7);
          core_mjs_["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          let tmp_40_0;
          let tmp_41_0;
          let tmp_50_0;
          let tmp_51_0;
          let tmp_52_0;
          let tmp_57_0;
          let tmp_58_0;
          core_mjs_["ɵɵproperty"]("formGroup", ctx.settingsForm);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ContainerType.Default)("isDirty", core_mjs_["ɵɵpipeBind1"](3, 60, core_mjs_["ɵɵpureFunction1"](104, pie_settings_component_c1, ctx.settingsForm.get("generalSettings"))))("isInvalid", ctx.settingsForm.get("generalSettings").invalid);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](6, 62, "WUI_Dashboard.Widget.General"), " ");
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("data", core_mjs_["ɵɵpipeBind1"](9, 64, ctx.data$));
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("type", ctx.ContainerType.Collapsable)("collapsed", ctx.collapsed)("isDirty", core_mjs_["ɵɵpipeBind1"](11, 66, core_mjs_["ɵɵpureFunction1"](107, pie_settings_component_c1, ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](106, pie_settings_component_c5)))))("isInvalid", ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](109, pie_settings_component_c5)).invalid);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](14, 68, "WUI_Dashboard.Widget.Data"), " ");
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("dataTypes", ctx.dataTypes)("structureMode", true);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ctx.series.controls.length < 10);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngForOf", ctx.series.controls);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("type", ctx.ContainerType.Collapsable)("collapsed", ctx.collapsed)("isInvalid", core_mjs_["ɵɵpipeBind1"](20, 70, ctx.widgetOptionsGroup))("isDirty", core_mjs_["ɵɵpipeBind1"](21, 72, ctx.widgetOptionsGroup));
          core_mjs_["ɵɵadvance"](4);
          core_mjs_["ɵɵtextInterpolate1"](" ", core_mjs_["ɵɵpipeBind1"](24, 74, "WUI_Dashboard.Widget.Options"), " ");
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Large);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Large)("label", core_mjs_["ɵɵpipeBind1"](28, 76, "WDK_pie.Widget.pie.type.Title"))("isDirty", core_mjs_["ɵɵpipeBind1"](29, 78, core_mjs_["ɵɵpureFunction1"](110, pie_settings_component_c1, ctx.typeControl)));
          core_mjs_["ɵɵadvance"](6);
          core_mjs_["ɵɵtextInterpolate1"]("", core_mjs_["ɵɵpipeBind1"](34, 80, "WDK_pie.Widget.pie.type.Pie"), " ");
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵpropertyInterpolate1"]("src", "", ctx.assetUrl, "assets/pie.png", core_mjs_["ɵɵsanitizeUrl"]);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵtextInterpolate1"]("", core_mjs_["ɵɵpipeBind1"](39, 82, "WDK_pie.Widget.pie.type.Nightingale"), " ");
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵpropertyInterpolate1"]("src", "", ctx.assetUrl, "assets/nightingale.png", core_mjs_["ɵɵsanitizeUrl"]);
          core_mjs_["ɵɵadvance"](4);
          core_mjs_["ɵɵtextInterpolate1"]("", core_mjs_["ɵɵpipeBind1"](45, 84, "WDK_pie.Widget.pie.type.Doughnut"), " ");
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵpropertyInterpolate1"]("src", "", ctx.assetUrl, "assets/doughnut.png", core_mjs_["ɵɵsanitizeUrl"]);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵtextInterpolate1"]("", core_mjs_["ɵɵpipeBind1"](50, 86, "WDK_pie.Widget.pie.type.RoundedDoughnut"), " ");
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵpropertyInterpolate1"]("src", "", ctx.assetUrl, "assets/roundedDoughnut.png", core_mjs_["ɵɵsanitizeUrl"]);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("omitInputGroup", true)("isDirty", core_mjs_["ɵɵpipeBind1"](53, 88, ctx.chartTypeGroup))("isInvalid", core_mjs_["ɵɵpipeBind1"](54, 90, ctx.chartTypeGroup))("isTouched", core_mjs_["ɵɵpipeBind1"](55, 92, ctx.chartTypeGroup))("size", ctx.InputGroupSize.Small);
          core_mjs_["ɵɵadvance"](4);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Small)("label", core_mjs_["ɵɵpipeBind1"](57, 94, "WDK_pie.Widget.pie.radius"))("isDirty", core_mjs_["ɵɵpipeBind1"](58, 96, core_mjs_["ɵɵpureFunction1"](112, pie_settings_component_c1, ctx.pieRadiusControl)) || core_mjs_["ɵɵpipeBind1"](59, 98, core_mjs_["ɵɵpureFunction1"](114, pie_settings_component_c1, ctx.radiusControl)));
          core_mjs_["ɵɵadvance"](5);
          core_mjs_["ɵɵproperty"]("ngIf", ((tmp_40_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](116, pie_settings_component_c6))) == null ? null : tmp_40_0.value) === "pie");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ((tmp_41_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](117, pie_settings_component_c6))) == null ? null : tmp_41_0.value) !== "pie");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", (ctx.typeControl == null ? null : ctx.typeControl.value) === "nightingale");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Small);
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("omitInputGroup", true)("size", ctx.InputGroupSize.Large);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("heading", core_mjs_["ɵɵpipeBind1"](69, 100, "WDK_pie.Widget.pie.chartLabel.title"))("label", core_mjs_["ɵɵpipeBind1"](70, 102, "WDK_pie.Widget.pie.chartLabel.show"))("size", ctx.InputGroupSize.Small)("formControl", ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](118, pie_settings_component_c7)));
          core_mjs_["ɵɵadvance"](3);
          core_mjs_["ɵɵproperty"]("ngIf", (tmp_50_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](119, pie_settings_component_c7))) == null ? null : tmp_50_0.value);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", ((tmp_51_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](120, pie_settings_component_c7))) == null ? null : tmp_51_0.value) && ((tmp_51_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](121, pie_settings_component_c8))) == null ? null : tmp_51_0.value) === "outside");
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", (tmp_52_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](122, pie_settings_component_c7))) == null ? null : tmp_52_0.value);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Large)("omitInputGroup", true);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("size", ctx.InputGroupSize.Small)("formControl", ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](123, pie_settings_component_c9)));
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", (tmp_57_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](124, pie_settings_component_c9))) == null ? null : tmp_57_0.value);
          core_mjs_["ɵɵadvance"](1);
          core_mjs_["ɵɵproperty"]("ngIf", (tmp_58_0 = ctx.settingsForm.get(core_mjs_["ɵɵpureFunction0"](125, pie_settings_component_c9))) == null ? null : tmp_58_0.value);
          core_mjs_["ɵɵadvance"](2);
          core_mjs_["ɵɵproperty"]("ngForOf", ctx.series.controls);
        }
      },
      dependencies: [common_mjs_.NgForOf, common_mjs_.NgIf, Slider, src_index_ts_.GeneralSettingsComponent, src_index_ts_.ColorPickerComponent, src_index_ts_.FormGroupComponent, src_index_ts_.FormGroupItemDirective, src_index_ts_.InputGroupComponent, src_index_ts_.FormComponent, src_index_ts_.CheckboxComponent, src_index_ts_.ContainerComponent, src_index_ts_.ContainerTitleComponent, src_index_ts_.ContainerTitleActionsComponent, src_index_ts_.ContainerContentComponent, src_index_ts_.ContainerGroupComponent, src_index_ts_.AdvancedNameInputComponent, src_index_ts_.DataSelectorInputComponent, siemens_di_pa_sw_reusable_components_uxt_form/* SelectDirective */.MB, siemens_di_pa_sw_reusable_components_uxt_form/* SelectWrapperComponent */.Wk, siemens_di_pa_sw_reusable_components_uxt_button/* ButtonComponent */.r0, forms_mjs_.NgSelectOption, forms_mjs_["ɵNgSelectMultipleOption"], forms_mjs_.DefaultValueAccessor, forms_mjs_.SelectControlValueAccessor, forms_mjs_.RadioControlValueAccessor, forms_mjs_.NgControlStatus, forms_mjs_.NgControlStatusGroup, forms_mjs_.FormControlDirective, forms_mjs_.FormGroupDirective, forms_mjs_.FormControlName, forms_mjs_.FormGroupName, forms_mjs_.FormArrayName, src_index_ts_.DataDisplayNameComponent, src_index_ts_.UnitSettingsComponent, src_index_ts_.FormatSettingsComponent, common_mjs_.AsyncPipe, ngx_translate_core_mjs_.TranslatePipe, src_index_ts_.HasRequiredFieldPipe, src_index_ts_.IsDirtyPipe, src_index_ts_.IsInvalidPipe, src_index_ts_.IsTouchedPipe],
      styles: ["img[_ngcontent-%COMP%] {\n  width: 6rem;\n  height: 6rem;\n  margin-right: 4rem;\n}"]
    });
  }
  return PieSettingsComponent;
})();
;// CONCATENATED MODULE: ./libs/dashboard/widgets/pie/src/lib/dashboard-widgets-pie.module.ts
























let PieLibModule = /*#__PURE__*/(() => {
  class PieLibModule extends index_ts_.DashboardWidgetModule {
    constructor() {
      super();
      this.createWidgetSettings = createWidgetSettings;
    }
    resolveWidget(viewContainerRef, moduleRef) {
      return viewContainerRef.createComponent(PieContainerComponent, {
        ngModuleRef: moduleRef
      }).instance;
    }
    resolveWidgetSettings(viewContainerRef, moduleRef) {
      return viewContainerRef.createComponent(PieSettingsComponent, {
        ngModuleRef: moduleRef
      }).instance;
    }
    static #_ = this.ɵfac = function PieLibModule_Factory(t) {
      return new (t || PieLibModule)();
    };
    static #_2 = this.ɵmod = /*@__PURE__*/core_mjs_["ɵɵdefineNgModule"]({
      type: PieLibModule
    });
    static #_3 = this.ɵinj = /*@__PURE__*/core_mjs_["ɵɵdefineInjector"]({
      providers: [src_index_ts_.StringFormatPipe],
      imports: [common_mjs_.CommonModule, SliderModule, ngx_translate_core_mjs_.TranslateModule, src_index_ts_.SettingsFormElementsModule, siemens_di_pa_sw_reusable_components_uxt_form/* SieFormModule */.H$, siemens_di_pa_sw_reusable_components_uxt_button/* SieButtonModule */.cH, siemens_di_pa_sw_reusable_components_uxt_badge/* SieBadgeModule */.T, siemens_di_pa_sw_reusable_components_uxt_card/* SieCardModule */.SE, siemens_di_pa_sw_reusable_components_uxt_container/* SieContainerModule */.o4, SieContentHeaderModule, siemens_di_pa_sw_reusable_components_uxt_icon/* SieIconModule */.A, forms_mjs_.ReactiveFormsModule.withConfig({
        callSetDisabledState: 'whenDisabledForLegacyCode'
      }), ngx_color_picker/* ColorPickerModule */.e4, ngx_echarts/* NgxEchartsModule */.Ns.forRoot({
        echarts: echarts
      }), src_index_ts_.DataDisplayNameComponentModule, src_index_ts_.UnitSettingsComponent, src_index_ts_.FormatSettingsComponent]
    });
  }
  return PieLibModule;
})();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && core_mjs_["ɵɵsetNgModuleScope"](PieLibModule, {
    declarations: [PieContainerComponent, PieSettingsComponent, PieUiComponent],
    imports: [common_mjs_.CommonModule, SliderModule, ngx_translate_core_mjs_.TranslateModule, src_index_ts_.SettingsFormElementsModule, siemens_di_pa_sw_reusable_components_uxt_form/* SieFormModule */.H$, siemens_di_pa_sw_reusable_components_uxt_button/* SieButtonModule */.cH, siemens_di_pa_sw_reusable_components_uxt_badge/* SieBadgeModule */.T, siemens_di_pa_sw_reusable_components_uxt_card/* SieCardModule */.SE, siemens_di_pa_sw_reusable_components_uxt_container/* SieContainerModule */.o4, SieContentHeaderModule, siemens_di_pa_sw_reusable_components_uxt_icon/* SieIconModule */.A, forms_mjs_.ReactiveFormsModule, ngx_color_picker/* ColorPickerModule */.e4, ngx_echarts/* NgxEchartsModule */.Ns, src_index_ts_.DataDisplayNameComponentModule, src_index_ts_.UnitSettingsComponent, src_index_ts_.FormatSettingsComponent]
  });
})();
;// CONCATENATED MODULE: ./libs/dashboard/widgets/pie/src/index.ts




/***/ }),

/***/ 5291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ timeout)
/* harmony export */ });
/* unused harmony export TimeoutError */
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8307);
/* harmony import */ var _util_isDate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3270);
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5849);
/* harmony import */ var _observable_innerFrom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1599);
/* harmony import */ var _util_createErrorClass__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(789);
/* harmony import */ var _OperatorSubscriber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6735);
/* harmony import */ var _util_executeSchedule__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7237);







const TimeoutError = (0,_util_createErrorClass__WEBPACK_IMPORTED_MODULE_0__/* .createErrorClass */ .d)(_super => function TimeoutErrorImpl(info = null) {
  _super(this);
  this.message = 'Timeout has occurred';
  this.name = 'TimeoutError';
  this.info = info;
});
function timeout(config, schedulerArg) {
  const {
    first,
    each,
    with: _with = timeoutErrorFactory,
    scheduler = schedulerArg !== null && schedulerArg !== void 0 ? schedulerArg : _scheduler_async__WEBPACK_IMPORTED_MODULE_1__/* .asyncScheduler */ .z,
    meta = null
  } = (0,_util_isDate__WEBPACK_IMPORTED_MODULE_2__/* .isValidDate */ .q)(config) ? {
    first: config
  } : typeof config === 'number' ? {
    each: config
  } : config;
  if (first == null && each == null) {
    throw new TypeError('No timeout provided.');
  }
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_3__/* .operate */ .e)((source, subscriber) => {
    let originalSourceSubscription;
    let timerSubscription;
    let lastValue = null;
    let seen = 0;
    const startTimer = delay => {
      timerSubscription = (0,_util_executeSchedule__WEBPACK_IMPORTED_MODULE_4__/* .executeSchedule */ .f)(subscriber, scheduler, () => {
        try {
          originalSourceSubscription.unsubscribe();
          (0,_observable_innerFrom__WEBPACK_IMPORTED_MODULE_5__/* .innerFrom */ .Xf)(_with({
            meta,
            lastValue,
            seen
          })).subscribe(subscriber);
        } catch (err) {
          subscriber.error(err);
        }
      }, delay);
    };
    originalSourceSubscription = source.subscribe((0,_OperatorSubscriber__WEBPACK_IMPORTED_MODULE_6__/* .createOperatorSubscriber */ .x)(subscriber, value => {
      timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      seen++;
      subscriber.next(lastValue = value);
      each > 0 && startTimer(each);
    }, undefined, undefined, () => {
      if (!(timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.closed)) {
        timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      }
      lastValue = null;
    }));
    !seen && startTimer(first != null ? typeof first === 'number' ? first : +first - scheduler.now() : each);
  });
}
function timeoutErrorFactory(info) {
  throw new TimeoutError(info);
}
//# sourceMappingURL=timeout.js.map

/***/ }),

/***/ 3810:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  _w: () => (/* binding */ NgxEchartsDirective),
  Ns: () => (/* binding */ NgxEchartsModule)
});

// UNUSED EXPORTS: NGX_ECHARTS_CONFIG, provideEcharts, provideEchartsCore

// EXTERNAL MODULE: ../../node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(4795);
// EXTERNAL MODULE: consume shared module (default) @angular/core@^16.0.0 (singleton) (fallback: ../../node_modules/@angular/core/fesm2022/core.mjs)
var core_mjs_ = __webpack_require__(7161);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/ReplaySubject.js
var ReplaySubject = __webpack_require__(9706);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/Subscription.js + 1 modules
var Subscription = __webpack_require__(8870);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/Subject.js + 1 modules
var Subject = __webpack_require__(8611);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/scheduler/async.js
var scheduler_async = __webpack_require__(8307);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/Observable.js
var Observable = __webpack_require__(7815);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/util/lift.js
var lift = __webpack_require__(5849);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/OperatorSubscriber.js
var OperatorSubscriber = __webpack_require__(6735);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/innerFrom.js
var innerFrom = __webpack_require__(1599);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/throttle.js



function throttle(durationSelector, config) {
  return (0,lift/* operate */.e)((source, subscriber) => {
    const {
      leading = true,
      trailing = false
    } = config !== null && config !== void 0 ? config : {};
    let hasValue = false;
    let sendValue = null;
    let throttled = null;
    let isComplete = false;
    const endThrottling = () => {
      throttled === null || throttled === void 0 ? void 0 : throttled.unsubscribe();
      throttled = null;
      if (trailing) {
        send();
        isComplete && subscriber.complete();
      }
    };
    const cleanupThrottling = () => {
      throttled = null;
      isComplete && subscriber.complete();
    };
    const startThrottle = value => throttled = (0,innerFrom/* innerFrom */.Xf)(durationSelector(value)).subscribe((0,OperatorSubscriber/* createOperatorSubscriber */.x)(subscriber, endThrottling, cleanupThrottling));
    const send = () => {
      if (hasValue) {
        hasValue = false;
        const value = sendValue;
        sendValue = null;
        subscriber.next(value);
        !isComplete && startThrottle(value);
      }
    };
    source.subscribe((0,OperatorSubscriber/* createOperatorSubscriber */.x)(subscriber, value => {
      hasValue = true;
      sendValue = value;
      !(throttled && !throttled.closed) && (leading ? send() : startThrottle(value));
    }, () => {
      isComplete = true;
      !(trailing && hasValue && throttled && !throttled.closed) && subscriber.complete();
    }));
  });
}
//# sourceMappingURL=throttle.js.map
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/timer.js
var timer = __webpack_require__(4231);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/throttleTime.js



function throttleTime(duration, scheduler = scheduler_async/* asyncScheduler */.z, config) {
  const duration$ = (0,timer/* timer */.H)(duration, scheduler);
  return throttle(() => duration$, config);
}
//# sourceMappingURL=throttleTime.js.map
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/switchMap.js
var switchMap = __webpack_require__(5700);
;// CONCATENATED MODULE: ../../node_modules/ngx-echarts/fesm2022/ngx-echarts.mjs





class ChangeFilterV2 {
  constructor() {
    this.subject = new ReplaySubject/* ReplaySubject */.t(1);
    this.subscriptions = new Subscription/* Subscription */.w0();
  }
  doFilter(changes) {
    this.subject.next(changes);
  }
  dispose() {
    this.subscriptions.unsubscribe();
  }
  notEmpty(key, handler) {
    this.subscriptions.add(this.subject.subscribe(changes => {
      if (changes[key]) {
        const value = changes[key].currentValue;
        if (value !== undefined && value !== null) {
          handler(value);
        }
      }
    }));
  }
  has(key, handler) {
    this.subscriptions.add(this.subject.subscribe(changes => {
      if (changes[key]) {
        const value = changes[key].currentValue;
        handler(value);
      }
    }));
  }
  notFirst(key, handler) {
    this.subscriptions.add(this.subject.subscribe(changes => {
      if (changes[key] && !changes[key].isFirstChange()) {
        const value = changes[key].currentValue;
        handler(value);
      }
    }));
  }
  notFirstAndEmpty(key, handler) {
    this.subscriptions.add(this.subject.subscribe(changes => {
      if (changes[key] && !changes[key].isFirstChange()) {
        const value = changes[key].currentValue;
        if (value !== undefined && value !== null) {
          handler(value);
        }
      }
    }));
  }
}
const NGX_ECHARTS_CONFIG = new core_mjs_.InjectionToken('NGX_ECHARTS_CONFIG');
let NgxEchartsDirective = /*#__PURE__*/(() => {
  class NgxEchartsDirective {
    constructor(config, el, ngZone) {
      this.el = el;
      this.ngZone = ngZone;
      this.options = null;
      this.theme = null;
      this.initOpts = null;
      this.merge = null;
      this.autoResize = true;
      this.loading = false;
      this.loadingType = 'default';
      this.loadingOpts = null;
      // ngx-echarts events
      this.chartInit = new core_mjs_.EventEmitter();
      this.optionsError = new core_mjs_.EventEmitter();
      // echarts mouse events
      this.chartClick = this.createLazyEvent('click');
      this.chartDblClick = this.createLazyEvent('dblclick');
      this.chartMouseDown = this.createLazyEvent('mousedown');
      this.chartMouseMove = this.createLazyEvent('mousemove');
      this.chartMouseUp = this.createLazyEvent('mouseup');
      this.chartMouseOver = this.createLazyEvent('mouseover');
      this.chartMouseOut = this.createLazyEvent('mouseout');
      this.chartGlobalOut = this.createLazyEvent('globalout');
      this.chartContextMenu = this.createLazyEvent('contextmenu');
      // echarts events
      this.chartHighlight = this.createLazyEvent('highlight');
      this.chartDownplay = this.createLazyEvent('downplay');
      this.chartSelectChanged = this.createLazyEvent('selectchanged');
      this.chartLegendSelectChanged = this.createLazyEvent('legendselectchanged');
      this.chartLegendSelected = this.createLazyEvent('legendselected');
      this.chartLegendUnselected = this.createLazyEvent('legendunselected');
      this.chartLegendLegendSelectAll = this.createLazyEvent('legendselectall');
      this.chartLegendLegendInverseSelect = this.createLazyEvent('legendinverseselect');
      this.chartLegendScroll = this.createLazyEvent('legendscroll');
      this.chartDataZoom = this.createLazyEvent('datazoom');
      this.chartDataRangeSelected = this.createLazyEvent('datarangeselected');
      this.chartGraphRoam = this.createLazyEvent('graphroam');
      this.chartGeoRoam = this.createLazyEvent('georoam');
      this.chartTreeRoam = this.createLazyEvent('treeroam');
      this.chartTimelineChanged = this.createLazyEvent('timelinechanged');
      this.chartTimelinePlayChanged = this.createLazyEvent('timelineplaychanged');
      this.chartRestore = this.createLazyEvent('restore');
      this.chartDataViewChanged = this.createLazyEvent('dataviewchanged');
      this.chartMagicTypeChanged = this.createLazyEvent('magictypechanged');
      this.chartGeoSelectChanged = this.createLazyEvent('geoselectchanged');
      this.chartGeoSelected = this.createLazyEvent('geoselected');
      this.chartGeoUnselected = this.createLazyEvent('geounselected');
      this.chartAxisAreaSelected = this.createLazyEvent('axisareaselected');
      this.chartBrush = this.createLazyEvent('brush');
      this.chartBrushEnd = this.createLazyEvent('brushend');
      this.chartBrushSelected = this.createLazyEvent('brushselected');
      this.chartGlobalCursorTaken = this.createLazyEvent('globalcursortaken');
      this.chartRendered = this.createLazyEvent('rendered');
      this.chartFinished = this.createLazyEvent('finished');
      this.animationFrameID = null;
      this.chart$ = new ReplaySubject/* ReplaySubject */.t(1);
      this.resize$ = new Subject/* Subject */.x();
      this.changeFilter = new ChangeFilterV2();
      this.echarts = config.echarts;
    }
    ngOnChanges(changes) {
      this.changeFilter.doFilter(changes);
    }
    ngOnInit() {
      if (!window.ResizeObserver) {
        throw new Error('please install a polyfill for ResizeObserver');
      }
      this.resizeSub = this.resize$.pipe(throttleTime(100, scheduler_async/* asyncScheduler */.z, {
        leading: false,
        trailing: true
      })).subscribe(() => this.resize());
      if (this.autoResize) {
        this.resizeOb = this.ngZone.runOutsideAngular(() => new window.ResizeObserver(() => {
          this.animationFrameID = window.requestAnimationFrame(() => this.resize$.next());
        }));
        this.resizeOb.observe(this.el.nativeElement);
      }
      this.changeFilter.notFirstAndEmpty('options', opt => this.onOptionsChange(opt));
      this.changeFilter.notFirstAndEmpty('merge', opt => this.setOption(opt));
      this.changeFilter.has('loading', v => this.toggleLoading(!!v));
      this.changeFilter.notFirst('theme', () => this.refreshChart());
    }
    ngOnDestroy() {
      window.clearTimeout(this.initChartTimer);
      if (this.resizeSub) {
        this.resizeSub.unsubscribe();
      }
      if (this.animationFrameID) {
        window.cancelAnimationFrame(this.animationFrameID);
      }
      if (this.resizeOb) {
        this.resizeOb.unobserve(this.el.nativeElement);
      }
      if (this.loadingSub) {
        this.loadingSub.unsubscribe();
      }
      this.changeFilter.dispose();
      this.dispose();
    }
    ngAfterViewInit() {
      this.initChartTimer = window.setTimeout(() => this.initChart());
    }
    dispose() {
      if (this.chart) {
        if (!this.chart.isDisposed()) {
          this.chart.dispose();
        }
        this.chart = null;
      }
    }
    /**
     * resize chart
     */
    resize() {
      if (this.chart) {
        this.chart.resize();
      }
    }
    toggleLoading(loading) {
      if (this.chart) {
        loading ? this.chart.showLoading(this.loadingType, this.loadingOpts) : this.chart.hideLoading();
      } else {
        this.loadingSub = this.chart$.subscribe(chart => loading ? chart.showLoading(this.loadingType, this.loadingOpts) : chart.hideLoading());
      }
    }
    setOption(option, opts) {
      if (this.chart) {
        try {
          this.chart.setOption(option, opts);
        } catch (e) {
          console.error(e);
          this.optionsError.emit(e);
        }
      }
    }
    /**
     * dispose old chart and create a new one.
     */
    refreshChart() {
      var _this = this;
      return (0,asyncToGenerator/* default */.Z)(function* () {
        _this.dispose();
        yield _this.initChart();
      })();
    }
    createChart() {
      const dom = this.el.nativeElement;
      if (window && window.getComputedStyle) {
        const prop = window.getComputedStyle(dom, null).getPropertyValue('height');
        if ((!prop || prop === '0px') && (!dom.style.height || dom.style.height === '0px')) {
          dom.style.height = '400px';
        }
      }
      // here a bit tricky: we check if the echarts module is provided as function returning native import('...') then use the promise
      // otherwise create the function that imitates behaviour above with a provided as is module
      return this.ngZone.runOutsideAngular(() => {
        const load = typeof this.echarts === 'function' ? this.echarts : () => Promise.resolve(this.echarts);
        return load().then(({
          init
        }) => init(dom, this.theme, this.initOpts));
      });
    }
    initChart() {
      var _this2 = this;
      return (0,asyncToGenerator/* default */.Z)(function* () {
        yield _this2.onOptionsChange(_this2.options);
        if (_this2.merge && _this2.chart) {
          _this2.setOption(_this2.merge);
        }
      })();
    }
    onOptionsChange(opt) {
      var _this3 = this;
      return (0,asyncToGenerator/* default */.Z)(function* () {
        if (!opt) {
          return;
        }
        if (_this3.chart) {
          _this3.setOption(_this3.options, true);
        } else {
          _this3.chart = yield _this3.createChart();
          _this3.chart$.next(_this3.chart);
          _this3.chartInit.emit(_this3.chart);
          _this3.setOption(_this3.options, true);
        }
      })();
    }
    // allows to lazily bind to only those events that are requested through the `@Output` by parent components
    // see https://stackoverflow.com/questions/51787972/optimal-reentering-the-ngzone-from-eventemitter-event for more info
    createLazyEvent(eventName) {
      return this.chartInit.pipe((0,switchMap/* switchMap */.w)(chart => new Observable/* Observable */.y(observer => {
        chart.on(eventName, data => this.ngZone.run(() => observer.next(data)));
        return () => {
          if (this.chart) {
            if (!this.chart.isDisposed()) {
              chart.off(eventName);
            }
          }
        };
      })));
    }
    static #_ = this.ɵfac = function NgxEchartsDirective_Factory(t) {
      return new (t || NgxEchartsDirective)(core_mjs_["ɵɵdirectiveInject"](NGX_ECHARTS_CONFIG), core_mjs_["ɵɵdirectiveInject"](core_mjs_.ElementRef), core_mjs_["ɵɵdirectiveInject"](core_mjs_.NgZone));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */core_mjs_["ɵɵdefineDirective"]({
      type: NgxEchartsDirective,
      selectors: [["echarts"], ["", "echarts", ""]],
      inputs: {
        options: "options",
        theme: "theme",
        initOpts: "initOpts",
        merge: "merge",
        autoResize: "autoResize",
        loading: "loading",
        loadingType: "loadingType",
        loadingOpts: "loadingOpts"
      },
      outputs: {
        chartInit: "chartInit",
        optionsError: "optionsError",
        chartClick: "chartClick",
        chartDblClick: "chartDblClick",
        chartMouseDown: "chartMouseDown",
        chartMouseMove: "chartMouseMove",
        chartMouseUp: "chartMouseUp",
        chartMouseOver: "chartMouseOver",
        chartMouseOut: "chartMouseOut",
        chartGlobalOut: "chartGlobalOut",
        chartContextMenu: "chartContextMenu",
        chartHighlight: "chartHighlight",
        chartDownplay: "chartDownplay",
        chartSelectChanged: "chartSelectChanged",
        chartLegendSelectChanged: "chartLegendSelectChanged",
        chartLegendSelected: "chartLegendSelected",
        chartLegendUnselected: "chartLegendUnselected",
        chartLegendLegendSelectAll: "chartLegendLegendSelectAll",
        chartLegendLegendInverseSelect: "chartLegendLegendInverseSelect",
        chartLegendScroll: "chartLegendScroll",
        chartDataZoom: "chartDataZoom",
        chartDataRangeSelected: "chartDataRangeSelected",
        chartGraphRoam: "chartGraphRoam",
        chartGeoRoam: "chartGeoRoam",
        chartTreeRoam: "chartTreeRoam",
        chartTimelineChanged: "chartTimelineChanged",
        chartTimelinePlayChanged: "chartTimelinePlayChanged",
        chartRestore: "chartRestore",
        chartDataViewChanged: "chartDataViewChanged",
        chartMagicTypeChanged: "chartMagicTypeChanged",
        chartGeoSelectChanged: "chartGeoSelectChanged",
        chartGeoSelected: "chartGeoSelected",
        chartGeoUnselected: "chartGeoUnselected",
        chartAxisAreaSelected: "chartAxisAreaSelected",
        chartBrush: "chartBrush",
        chartBrushEnd: "chartBrushEnd",
        chartBrushSelected: "chartBrushSelected",
        chartGlobalCursorTaken: "chartGlobalCursorTaken",
        chartRendered: "chartRendered",
        chartFinished: "chartFinished"
      },
      exportAs: ["echarts"],
      standalone: true,
      features: [core_mjs_["ɵɵNgOnChangesFeature"]]
    });
  }
  return NgxEchartsDirective;
})();
(function () {
  ( false) && 0;
})();
const provideEcharts = () => {
  return {
    provide: NGX_ECHARTS_CONFIG,
    useFactory: () => ({
      echarts: () => __webpack_require__.e(/* import() */ 942).then(__webpack_require__.bind(__webpack_require__, 4942))
    })
  };
};
const provideEchartsCore = config => {
  return {
    provide: NGX_ECHARTS_CONFIG,
    useValue: config
  };
};
let NgxEchartsModule = /*#__PURE__*/(() => {
  class NgxEchartsModule {
    static forRoot(config) {
      return {
        ngModule: NgxEchartsModule,
        providers: [provideEchartsCore(config)]
      };
    }
    static forChild() {
      return {
        ngModule: NgxEchartsModule
      };
    }
    static #_ = this.ɵfac = function NgxEchartsModule_Factory(t) {
      return new (t || NgxEchartsModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */core_mjs_["ɵɵdefineNgModule"]({
      type: NgxEchartsModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */core_mjs_["ɵɵdefineInjector"]({});
  }
  return NgxEchartsModule;
})();
(function () {
  ( false) && 0;
})();

/*
 * Public API Surface of ngx-echarts
 */

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=ngx-echarts.mjs.map

/***/ })

}]);