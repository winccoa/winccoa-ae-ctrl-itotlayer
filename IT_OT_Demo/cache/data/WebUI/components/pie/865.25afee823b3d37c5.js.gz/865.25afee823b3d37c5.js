"use strict";
(self["webpackChunkpie"] = self["webpackChunkpie"] || []).push([[865],{

/***/ 484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ auditTime)
});

// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/scheduler/async.js
var scheduler_async = __webpack_require__(4874);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/util/lift.js
var lift = __webpack_require__(5680);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/innerFrom.js
var innerFrom = __webpack_require__(7152);
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/OperatorSubscriber.js
var OperatorSubscriber = __webpack_require__(90);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/audit.js



function audit(durationSelector) {
  return (0,lift/* operate */.N)((source, subscriber) => {
    let hasValue = false;
    let lastValue = null;
    let durationSubscriber = null;
    let isComplete = false;
    const endDuration = () => {
      durationSubscriber === null || durationSubscriber === void 0 ? void 0 : durationSubscriber.unsubscribe();
      durationSubscriber = null;
      if (hasValue) {
        hasValue = false;
        const value = lastValue;
        lastValue = null;
        subscriber.next(value);
      }
      isComplete && subscriber.complete();
    };
    const cleanupDuration = () => {
      durationSubscriber = null;
      isComplete && subscriber.complete();
    };
    source.subscribe((0,OperatorSubscriber/* createOperatorSubscriber */._)(subscriber, value => {
      hasValue = true;
      lastValue = value;
      if (!durationSubscriber) {
        (0,innerFrom/* innerFrom */.Tg)(durationSelector(value)).subscribe(durationSubscriber = (0,OperatorSubscriber/* createOperatorSubscriber */._)(subscriber, endDuration, cleanupDuration));
      }
    }, () => {
      isComplete = true;
      (!hasValue || !durationSubscriber || durationSubscriber.closed) && subscriber.complete();
    }));
  });
}
//# sourceMappingURL=audit.js.map
// EXTERNAL MODULE: ../../node_modules/rxjs/dist/esm/internal/observable/timer.js
var timer = __webpack_require__(1981);
;// CONCATENATED MODULE: ../../node_modules/rxjs/dist/esm/internal/operators/auditTime.js



function auditTime(duration, scheduler = scheduler_async/* asyncScheduler */.E) {
  return audit(() => (0,timer/* timer */.O)(duration, scheduler));
}
//# sourceMappingURL=auditTime.js.map

/***/ }),

/***/ 1718:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ SieBadgeModule)
/* harmony export */ });
/* unused harmony export BadgeComponent */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(463);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5782);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9710);








const _c0 = (/* unused pure expression or super */ null && (["*"]));
function BadgeComponent_sie_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelement(0, "sie-icon", 3);
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r0.icon)("flip", ctx_r0.iconFlip);
  }
}
function BadgeComponent_a_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 4);
    i0.ɵɵlistener("click", function BadgeComponent_a_4_Template_a_click_0_listener($event) {
      i0.ɵɵrestoreView(_r2);
      const ctx_r0 = i0.ɵɵnextContext();
      ctx_r0.onBadgeCloseClicked();
      return i0.ɵɵresetView($event.stopPropagation());
    });
    i0.ɵɵelementEnd();
  }
}
let BadgeComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class BadgeComponent {
    constructor() {
      this.type = 'dark';
      this.backgroundColor = null;
      this.color = null;
      this.large = false;
      this.interactive = false;
      this.disabled = false;
      this.noEllipsis = false;
      this.icon = null;
      this.iconFlip = null;
      this.closeBadge = new EventEmitter();
    }
    onBadgeCloseClicked() {
      this.closeBadge.emit();
    }
    static #_ = this.ɵfac = function BadgeComponent_Factory(t) {
      return new (t || BadgeComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: BadgeComponent,
      selectors: [["sie-badge"]],
      inputs: {
        type: "type",
        backgroundColor: "backgroundColor",
        color: "color",
        large: "large",
        interactive: "interactive",
        disabled: "disabled",
        noEllipsis: "noEllipsis",
        icon: "icon",
        iconFlip: "iconFlip"
      },
      outputs: {
        closeBadge: "closeBadge"
      },
      ngContentSelectors: _c0,
      decls: 5,
      vars: 11,
      consts: [["sieBackgroundColor", "", "sieColor", "", 1, "span", "badge", 3, "ngClass", "backgroundColor", "color"], ["type", "bold", 3, "icon", "flip", 4, "ngIf"], ["class", "a badge__close", 3, "click", 4, "ngIf"], ["type", "bold", 3, "icon", "flip"], [1, "a", "badge__close", 3, "click"]],
      template: function BadgeComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "span", 0);
          i0.ɵɵtemplate(1, BadgeComponent_sie_icon_1_Template, 1, 2, "sie-icon", 1);
          i0.ɵɵelementStart(2, "span");
          i0.ɵɵprojection(3);
          i0.ɵɵelementEnd();
          i0.ɵɵtemplate(4, BadgeComponent_a_4_Template, 1, 0, "a", 2);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵclassProp("badge--large", ctx.large)("badge--noEllipsis", ctx.noEllipsis)("is-disabled", ctx.disabled);
          i0.ɵɵproperty("ngClass", "badge--" + ctx.type)("backgroundColor", ctx.backgroundColor)("color", ctx.color);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.icon);
          i0.ɵɵadvance(3);
          i0.ɵɵproperty("ngIf", ctx.interactive);
        }
      },
      dependencies: [i1.NgClass, i1.NgIf, i2.BackgroundColorDirective, i2.ColorDirective, i3.IconComponent],
      styles: ["sie-badge .badge>sie-icon:first-child{padding-right:2px;font-size:16px}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return BadgeComponent;
})()));
(() => {
  ( false) && 0;
})();
let SieBadgeModule = /*#__PURE__*/(() => {
  class SieBadgeModule {
    static #_ = this.ɵfac = function SieBadgeModule_Factory(t) {
      return new (t || SieBadgeModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieBadgeModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .SieColorModule */ .$e, _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_3__/* .SieIconModule */ .j]
    });
  }
  return SieBadgeModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-badge.mjs.map

/***/ }),

/***/ 2613:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EJ: () => (/* binding */ SieButtonModule),
/* harmony export */   Qp: () => (/* binding */ ButtonComponent)
/* harmony export */ });
/* unused harmony export ButtonGroupComponent */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(463);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9710);






const _c0 = ["*"];
function ButtonComponent_sie_icon_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "sie-icon", 2);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("icon", ctx_r0.icon)("type", ctx_r0.iconType)("flip", ctx_r0.iconFlip);
  }
}
function ButtonComponent_sie_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "sie-icon", 2);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("icon", ctx_r0.icon)("type", ctx_r0.iconType)("flip", ctx_r0.iconFlip);
  }
}
function ButtonComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ButtonComponent_div_3_Template_div_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"]($event.stopPropagation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
}
const _c1 = (/* unused pure expression or super */ null && ([[["sie-button"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-button"]));
let ButtonComponent = /*#__PURE__*/(() => {
  class ButtonComponent {
    onKeyupEnter() {
      if (!this.disabled && this.elementRef.nativeElement) {
        this.elementRef.nativeElement.click();
      }
    }
    constructor(elementRef) {
      this.elementRef = elementRef;
      this.type = 'primary';
      this.icon = null;
      this.iconType = null;
      this.iconFlip = null;
      this.iconOnly = false;
      this.iconPosition = 'left';
      this.disabled = false;
      this.activated = false;
      this.danger = false;
      this.additionalCssClasses = null;
      this.tabIndex = 0;
      this.role = 'button';
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['button'];
      hostClassesArray.push(`button--${this.type}`);
      if (this.additionalCssClasses) {
        hostClassesArray.push(this.additionalCssClasses);
      }
      if (this.iconOnly) {
        hostClassesArray.push('has-icon-only');
      }
      if (this.disabled) {
        hostClassesArray.push('is-disabled');
      }
      if (this.activated) {
        hostClassesArray.push('is-activated');
      }
      if (this.danger) {
        hostClassesArray.push('is-dangerButton');
      }
      if (this.iconPosition === 'right') {
        hostClassesArray.push('has-icon-right');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function ButtonComponent_Factory(t) {
      return new (t || ButtonComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: ButtonComponent,
      selectors: [["sie-button"]],
      hostVars: 4,
      hostBindings: function ButtonComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup.enter", function ButtonComponent_keyup_enter_HostBindingHandler() {
            return ctx.onKeyupEnter();
          });
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵhostProperty"]("tabindex", ctx.tabIndex);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("role", ctx.role);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      inputs: {
        type: "type",
        icon: "icon",
        iconType: "iconType",
        iconFlip: "iconFlip",
        iconOnly: "iconOnly",
        iconPosition: "iconPosition",
        disabled: "disabled",
        activated: "activated",
        danger: "danger",
        additionalCssClasses: "additionalCssClasses",
        tabIndex: "tabIndex"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]],
      ngContentSelectors: _c0,
      decls: 4,
      vars: 3,
      consts: [[3, "icon", "type", "flip", 4, "ngIf"], ["class", "button__disabledOverlay", 3, "click", 4, "ngIf"], [3, "icon", "type", "flip"], [1, "button__disabledOverlay", 3, "click"]],
      template: function ButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, ButtonComponent_sie_icon_0_Template, 1, 3, "sie-icon", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojection"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, ButtonComponent_sie_icon_2_Template, 1, 3, "sie-icon", 0)(3, ButtonComponent_div_3_Template, 1, 0, "div", 1);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.icon && ctx.iconPosition === "left");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.icon && ctx.iconPosition === "right");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.disabled);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.NgIf, _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_2__/* .IconComponent */ .R],
      styles: ["sie-button{position:relative;-webkit-user-select:none;user-select:none}sie-button .button__disabledOverlay{position:absolute;cursor:not-allowed;inset:-1px}sie-button:focus:not(:focus-visible){outline:0!important}.uxt.uxt-defaults sie-button.button--ghost,.uxt.uxt-defaults sie-button.button--primaryContentAction,.uxt.uxt-defaults sie-button.button--secondaryContentAction{transition:background-color .2s ease-in-out,color .2s ease-in-out!important}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ButtonComponent;
})();
(() => {
  ( false) && 0;
})();
let ButtonGroupComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ButtonGroupComponent {
    constructor() {
      this.hostClasses = 'buttonGroup';
    }
    static #_ = this.ɵfac = function ButtonGroupComponent_Factory(t) {
      return new (t || ButtonGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ButtonGroupComponent,
      selectors: [["sie-button-group"]],
      hostVars: 2,
      hostBindings: function ButtonGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c2,
      decls: 1,
      vars: 0,
      template: function ButtonGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ButtonGroupComponent;
})()));
(() => {
  ( false) && 0;
})();
let SieButtonModule = /*#__PURE__*/(() => {
  class SieButtonModule {
    static #_ = this.ɵfac = function SieButtonModule_Factory(t) {
      return new (t || SieButtonModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieButtonModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_icon__WEBPACK_IMPORTED_MODULE_2__/* .SieIconModule */ .j]
    });
  }
  return SieButtonModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-button.mjs.map

/***/ }),

/***/ 9099:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   yd: () => (/* binding */ SieCardModule)
/* harmony export */ });
/* unused harmony exports CardComponent, CardContentComponent, CardFooterComponent, CardGridColumnComponent, CardGridComponent, CardGridRowComponent, CardMenuComponent, CardSublineComponent, CardTitleComponent */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(463);




const _c0 = (/* unused pure expression or super */ null && (["*"]));
const _c1 = (/* unused pure expression or super */ null && ([[["sie-card-menu"]], [["sie-card-title"]], [["sie-card-subline"]], [["sie-card-content"]], [["sie-card-footer"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-card-menu", "sie-card-title", "sie-card-subline", "sie-card-content", "sie-card-footer"]));
function CardComponent_div_0_h3_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "h3", 6);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
  }
}
function CardComponent_div_0_p_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 7);
    i0.ɵɵprojection(1, 2);
    i0.ɵɵelementEnd();
  }
}
function CardComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 3);
    i0.ɵɵprojection(1);
    i0.ɵɵtemplate(2, CardComponent_div_0_h3_2_Template, 2, 0, "h3", 4)(3, CardComponent_div_0_p_3_Template, 2, 0, "p", 5);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.cardTitleComponent);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.cardSublineComponent);
  }
}
function CardComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵprojection(1, 3);
    i0.ɵɵelementEnd();
  }
}
function CardComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9);
    i0.ɵɵprojection(1, 4);
    i0.ɵɵelementEnd();
  }
}
let CardContentComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardContentComponent {
    static #_ = this.ɵfac = function CardContentComponent_Factory(t) {
      return new (t || CardContentComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardContentComponent,
      selectors: [["sie-card-content"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardContentComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardContentComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardFooterComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardFooterComponent {
    static #_ = this.ɵfac = function CardFooterComponent_Factory(t) {
      return new (t || CardFooterComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardFooterComponent,
      selectors: [["sie-card-footer"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardFooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardFooterComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardSublineComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardSublineComponent {
    static #_ = this.ɵfac = function CardSublineComponent_Factory(t) {
      return new (t || CardSublineComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardSublineComponent,
      selectors: [["sie-card-subline"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardSublineComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardSublineComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardTitleComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardTitleComponent {
    static #_ = this.ɵfac = function CardTitleComponent_Factory(t) {
      return new (t || CardTitleComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardTitleComponent,
      selectors: [["sie-card-title"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardTitleComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardTitleComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardComponent {
    constructor() {
      this.centered = false;
      this.hostClasses = 'card';
    }
    static #_ = this.ɵfac = function CardComponent_Factory(t) {
      return new (t || CardComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardComponent,
      selectors: [["sie-card"]],
      contentQueries: function CardComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i0.ɵɵcontentQuery(dirIndex, CardTitleComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, CardSublineComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, CardContentComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, CardFooterComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardTitleComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardSublineComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardContentComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cardFooterComponent = _t.first);
        }
      },
      hostVars: 4,
      hostBindings: function CardComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
          i0.ɵɵclassProp("card--centered", ctx.centered);
        }
      },
      inputs: {
        centered: "centered"
      },
      ngContentSelectors: _c2,
      decls: 3,
      vars: 3,
      consts: [["class", "card__header", 4, "ngIf"], ["class", "card__content", 4, "ngIf"], ["class", "card__footer", 4, "ngIf"], [1, "card__header"], ["class", "card__title", 4, "ngIf"], ["class", "card__subline", 4, "ngIf"], [1, "card__title"], [1, "card__subline"], [1, "card__content"], [1, "card__footer"]],
      template: function CardComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵtemplate(0, CardComponent_div_0_Template, 4, 2, "div", 0)(1, CardComponent_div_1_Template, 2, 0, "div", 1)(2, CardComponent_div_2_Template, 2, 0, "div", 2);
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.cardTitleComponent || ctx.cardSublineComponent);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.cardContentComponent);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.cardFooterComponent);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["sie-card sie-card-title a{position:static!important}sie-card sie-card-content p{padding:0 24px;font-size:14px}sie-card sie-card-content p:first-child{margin-top:0}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardMenuComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardMenuComponent {
    static #_ = this.ɵfac = function CardMenuComponent_Factory(t) {
      return new (t || CardMenuComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardMenuComponent,
      selectors: [["sie-card-menu"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardMenuComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardMenuComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardGridComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardGridComponent {
    static #_ = this.ɵfac = function CardGridComponent_Factory(t) {
      return new (t || CardGridComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardGridComponent,
      selectors: [["sie-card-grid"]],
      ngContentSelectors: _c0,
      decls: 2,
      vars: 0,
      consts: [[1, "cards", "cards--simpleGrid"]],
      template: function CardGridComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "div", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardGridComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardGridColumnComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardGridColumnComponent {
    constructor() {
      this.hostClasses = 'cards__col';
    }
    static #_ = this.ɵfac = function CardGridColumnComponent_Factory(t) {
      return new (t || CardGridColumnComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardGridColumnComponent,
      selectors: [["sie-card-grid-column"]],
      hostVars: 2,
      hostBindings: function CardGridColumnComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardGridColumnComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardGridColumnComponent;
})()));
(() => {
  ( false) && 0;
})();
let CardGridRowComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CardGridRowComponent {
    constructor() {
      this.hostClasses = 'cards__row';
    }
    static #_ = this.ɵfac = function CardGridRowComponent_Factory(t) {
      return new (t || CardGridRowComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CardGridRowComponent,
      selectors: [["sie-card-grid-row"]],
      hostVars: 2,
      hostBindings: function CardGridRowComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function CardGridRowComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return CardGridRowComponent;
})()));
(() => {
  ( false) && 0;
})();
let SieCardModule = /*#__PURE__*/(() => {
  class SieCardModule {
    static #_ = this.ɵfac = function SieCardModule_Factory(t) {
      return new (t || SieCardModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieCardModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule]
    });
  }
  return SieCardModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-card.mjs.map

/***/ }),

/***/ 5782:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $e: () => (/* binding */ SieColorModule),
/* harmony export */   D$: () => (/* binding */ BackgroundColorDirective),
/* harmony export */   Fy: () => (/* binding */ ColorDirective)
/* harmony export */ });
/* unused harmony exports BorderColorDirective, ToColorHexPipe, toColorHex */
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(463);



const COLOR_CLASS_MAP = new Map([
// Base colors
['base000', 'base000'], ['base200', 'base200'], ['base450', 'base450'], ['base600', 'base600'], ['base750', 'base750'], ['base800', 'base800'], ['base900', 'base900'], ['base950', 'base950'], ['base1000', 'base1000'],
// Primary colors
['primaryDarker', 'primary-darker'], ['primaryDark', 'primary-dark'], ['primary', 'primary'], ['primaryLight', 'primary-light'], ['primaryLighter', 'primary-lighter'], ['primaryLightest', 'primary-lightest'],
// Functional colors
['infoDark', 'info-dark'], ['info', 'info'], ['infoLight', 'info-light'], ['infoLighter', 'info-lighter'], ['warningDark', 'warning-dark'], ['warning', 'warning'], ['warningLight', 'warning-light'], ['warningLighter', 'warning-lighter'], ['errorDark', 'error-dark'], ['error', 'error'], ['errorLight', 'error-light'], ['errorLighter', 'error-lighter'], ['successDark', 'success-dark'], ['success', 'success'], ['successLight', 'success-light'], ['successLighter', 'success-lighter'],
// OS Bar / Launchpad colors
['firefly', 'firefly'], ['aquaHaze', 'aquaHaze'],
// Charting colors
['charting01', 'charting01'], ['charting02', 'charting02'], ['charting03', 'charting03'], ['charting04', 'charting04'], ['charting05', 'charting05'], ['charting06', 'charting06'], ['charting07', 'charting07'], ['charting08', 'charting08'], ['charting09', 'charting09'], ['charting10', 'charting10'], ['charting11', 'charting11'], ['charting12', 'charting12'], ['charting13', 'charting13'], ['charting14', 'charting14'], ['charting15', 'charting15'], ['charting16', 'charting16'], ['charting17', 'charting17'], ['charting18', 'charting18'], ['charting19', 'charting19'], ['charting20', 'charting20'], ['charting21', 'charting21']]);
const COLOR_HEX_MAP = new Map([
// Base colors
['base000', '#000000'], ['base200', '#323232'], ['base450', '#595959'], ['base600', '#969696'], ['base750', '#BEBEBE'], ['base800', '#D2D2D2'], ['base900', '#F0F0F0'], ['base950', '#F6F6F6'], ['base1000', '#FFFFFF'],
// Primary colors
['primaryDarker', '#354C80'], ['primaryDark', '#005CBF'], ['primary', '#006FE6'], ['primaryLight', '#009EFF'], ['primaryLighter', '#7FB7F2'], ['primaryLightest', '#CCE2FA'],
// Functional colors
['infoDark', '#235461'], ['info', '#006FE6'], ['infoLight', '#BBD0D7'], ['infoLighter', '#D1E8F0'], ['warningDark', '#665E48'], ['warning', '#FFC800'], ['warningLight', '#E6DBB7'], ['warningLighter', '#FFEDB5'], ['errorDark', '#811211'], ['error', '#F62447'], ['errorLight', '#D6B4B4'], ['errorLighter', '#FCD3D2'], ['successDark', '#5E6919'], ['success', '#65C728'], ['successLight', '#C8D1BA'], ['successLighter', '#E6EED1'],
// OS Bar / Launchpad colors
['firefly', '#1E2832'], ['aquaHaze', '#DCE1E6'],
// Charting colors
['charting01', '#08889E'], ['charting02', '#FFB900'], ['charting03', '#AAB414'], ['charting04', '#8068E7'], ['charting05', '#AF235F'], ['charting06', '#794934'], ['charting07', '#006FE6'], ['charting08', '#879BAA'], ['charting09', '#EB780A'], ['charting10', '#554A50'], ['charting11', '#647D2D'], ['charting12', '#50BED7'], ['charting13', '#B98F72'], ['charting14', '#C8C8B7'], ['charting15', '#A985A8'], ['charting16', '#FF9EBC'], ['charting17', '#530E00'], ['charting18', '#789CFF'], ['charting19', '#F62447'], ['charting20', '#FFC800'], ['charting21', '#65C728']]);
let BackgroundColorDirective = /*#__PURE__*/(() => {
  class BackgroundColorDirective {
    constructor(renderer, elementRef) {
      this.renderer = renderer;
      this.elementRef = elementRef;
      this.backgroundColor = null;
      this.backgroundColorForced = false;
    }
    ngOnChanges() {
      if (this.addedClassName) {
        this.renderer.removeClass(this.elementRef.nativeElement, this.addedClassName);
      }
      if (this.backgroundColor) {
        const className = this.getClassName(this.backgroundColor, this.backgroundColorForced);
        this.renderer.addClass(this.elementRef.nativeElement, className);
        this.addedClassName = className;
      }
    }
    getClassName(backgroundColor, backgroundColorForced) {
      return `has-bgColor-${backgroundColorForced ? 'forced-' : ''}${COLOR_CLASS_MAP.get(backgroundColor)}`;
    }
    static #_ = this.ɵfac = function BackgroundColorDirective_Factory(t) {
      return new (t || BackgroundColorDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
      type: BackgroundColorDirective,
      selectors: [["", "sieBackgroundColor", ""]],
      inputs: {
        backgroundColor: "backgroundColor",
        backgroundColorForced: "backgroundColorForced"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]]
    });
  }
  return BackgroundColorDirective;
})();
(() => {
  ( false) && 0;
})();
let BorderColorDirective = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class BorderColorDirective {
    constructor(renderer, elementRef) {
      this.renderer = renderer;
      this.elementRef = elementRef;
      this.borderColor = null;
      this.borderColorForced = false;
    }
    ngOnChanges() {
      if (this.addedClassName) {
        this.renderer.removeClass(this.elementRef.nativeElement, this.addedClassName);
      }
      if (this.borderColor) {
        const className = this.getClassName(this.borderColor, this.borderColorForced);
        this.renderer.addClass(this.elementRef.nativeElement, className);
        this.addedClassName = className;
      }
    }
    getClassName(borderColor, borderColorForced) {
      return `has-borderColor-${borderColorForced ? 'forced-' : ''}${COLOR_CLASS_MAP.get(borderColor)}`;
    }
    static #_ = this.ɵfac = function BorderColorDirective_Factory(t) {
      return new (t || BorderColorDirective)(i0.ɵɵdirectiveInject(i0.Renderer2), i0.ɵɵdirectiveInject(i0.ElementRef));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */i0.ɵɵdefineDirective({
      type: BorderColorDirective,
      selectors: [["", "sieBorderColor", ""]],
      inputs: {
        borderColor: "borderColor",
        borderColorForced: "borderColorForced"
      },
      features: [i0.ɵɵNgOnChangesFeature]
    });
  }
  return BorderColorDirective;
})()));
(() => {
  ( false) && 0;
})();
let ColorDirective = /*#__PURE__*/(() => {
  class ColorDirective {
    constructor(renderer, elementRef) {
      this.renderer = renderer;
      this.elementRef = elementRef;
      this.color = null;
      this.colorForced = false;
    }
    ngOnChanges() {
      if (this.addedClassName) {
        this.renderer.removeClass(this.elementRef.nativeElement, this.addedClassName);
      }
      if (this.color) {
        const className = this.getClassName(this.color, this.colorForced);
        this.renderer.addClass(this.elementRef.nativeElement, className);
        this.addedClassName = className;
      }
    }
    getClassName(color, colorForced) {
      return `has-color-${colorForced ? 'forced-' : ''}${COLOR_CLASS_MAP.get(color)}`;
    }
    static #_ = this.ɵfac = function ColorDirective_Factory(t) {
      return new (t || ColorDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
      type: ColorDirective,
      selectors: [["", "sieColor", ""]],
      inputs: {
        color: "color",
        colorForced: "colorForced"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]]
    });
  }
  return ColorDirective;
})();
(() => {
  ( false) && 0;
})();
let ToColorHexPipe = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ToColorHexPipe {
    transform(color) {
      return toColorHex(color);
    }
    static #_ = this.ɵfac = function ToColorHexPipe_Factory(t) {
      return new (t || ToColorHexPipe)();
    };
    static #_2 = this.ɵpipe = /* @__PURE__ */i0.ɵɵdefinePipe({
      name: "sieToColorHex",
      type: ToColorHexPipe,
      pure: true
    });
  }
  return ToColorHexPipe;
})()));
(() => {
  ( false) && 0;
})();
function toColorHex(color) {
  return COLOR_HEX_MAP.get(color) ?? null;
}
let SieColorModule = /*#__PURE__*/(() => {
  class SieColorModule {
    static #_ = this.ɵfac = function SieColorModule_Factory(t) {
      return new (t || SieColorModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
      type: SieColorModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule]
    });
  }
  return SieColorModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-color.mjs.map

/***/ }),

/***/ 2182:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f0: () => (/* binding */ SieContainerModule)
/* harmony export */ });
/* unused harmony exports ContainerComponent, ContainerContentComponent, ContainerContentDividerComponent, ContainerGroupComponent, ContainerTitleActionsComponent, ContainerTitleComponent, ContainerTitleMetaComponent */
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(463);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3081);




const _c0 = (/* unused pure expression or super */ null && (["*"]));
const _c1 = (/* unused pure expression or super */ null && ([[["sie-container-title-meta"]], [["sie-container-title-actions"]], [["sie-container-content"]], [["sie-container-title"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-container-title-meta", "sie-container-title-actions", "sie-container-content", "sie-container-title"]));
function ContainerComponent_div_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainer(0);
  }
}
function ContainerComponent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9);
    i0.ɵɵprojection(1);
    i0.ɵɵelementEnd();
  }
}
function ContainerComponent_div_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 10);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
  }
}
function ContainerComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtemplate(1, ContainerComponent_div_0_ng_container_1_Template, 1, 0, "ng-container", 6)(2, ContainerComponent_div_0_div_2_Template, 2, 0, "div", 7)(3, ContainerComponent_div_0_div_3_Template, 2, 0, "div", 8);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    const defaultContainerTitle_r2 = i0.ɵɵreference(3);
    const collapsableContainerTitle_r3 = i0.ɵɵreference(5);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r0.type === "collapsable" ? collapsableContainerTitle_r3 : defaultContainerTitle_r2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.containerTitleMetaComponent);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.containerTitleActionsComponent);
  }
}
function ContainerComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵprojection(1, 2);
    i0.ɵɵelementEnd();
  }
}
function ContainerComponent_ng_template_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainer(0);
  }
}
function ContainerComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 12);
    i0.ɵɵtemplate(1, ContainerComponent_ng_template_2_ng_container_1_Template, 1, 0, "ng-container", 6);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    i0.ɵɵnextContext();
    const containerTitleContent_r4 = i0.ɵɵreference(7);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", containerTitleContent_r4);
  }
}
function ContainerComponent_ng_template_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainer(0);
  }
}
function ContainerComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 13);
    i0.ɵɵlistener("click", function ContainerComponent_ng_template_4_Template_a_click_0_listener() {
      i0.ɵɵrestoreView(_r5);
      const ctx_r0 = i0.ɵɵnextContext();
      return i0.ɵɵresetView(ctx_r0.toggleCollapsedState());
    });
    i0.ɵɵtemplate(1, ContainerComponent_ng_template_4_ng_container_1_Template, 1, 0, "ng-container", 6);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    i0.ɵɵnextContext();
    const containerTitleContent_r4 = i0.ɵɵreference(7);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", containerTitleContent_r4);
  }
}
function ContainerComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵprojection(0, 3);
  }
}
const _c3 = (/* unused pure expression or super */ null && ([[["sie-container"]]]));
const _c4 = (/* unused pure expression or super */ null && (["sie-container"]));
let ContainerContentComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerContentComponent {
    static #_ = this.ɵfac = function ContainerContentComponent_Factory(t) {
      return new (t || ContainerContentComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerContentComponent,
      selectors: [["sie-container-content"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerContentComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerContentComponent;
})()));
(() => {
  ( false) && 0;
})();
let ContainerTitleComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerTitleComponent {
    static #_ = this.ɵfac = function ContainerTitleComponent_Factory(t) {
      return new (t || ContainerTitleComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerTitleComponent,
      selectors: [["sie-container-title"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerTitleComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerTitleComponent;
})()));
(() => {
  ( false) && 0;
})();
let ContainerTitleActionsComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerTitleActionsComponent {
    static #_ = this.ɵfac = function ContainerTitleActionsComponent_Factory(t) {
      return new (t || ContainerTitleActionsComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerTitleActionsComponent,
      selectors: [["sie-container-title-actions"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerTitleActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerTitleActionsComponent;
})()));
(() => {
  ( false) && 0;
})();
let ContainerTitleMetaComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerTitleMetaComponent {
    static #_ = this.ɵfac = function ContainerTitleMetaComponent_Factory(t) {
      return new (t || ContainerTitleMetaComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerTitleMetaComponent,
      selectors: [["sie-container-title-meta"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function ContainerTitleMetaComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerTitleMetaComponent;
})()));
(() => {
  ( false) && 0;
})();
let ContainerComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerComponent {
    constructor() {
      this.type = null;
      this.collapsed = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    toggleCollapsedState() {
      this.collapsed = !this.collapsed;
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['container'];
      if (this.type) {
        hostClassesArray.push(`container--${this.type}`);
      }
      if (this.type === 'collapsable' && this.collapsed) {
        hostClassesArray.push('is-collapsed');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function ContainerComponent_Factory(t) {
      return new (t || ContainerComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerComponent,
      selectors: [["sie-container"]],
      contentQueries: function ContainerComponent_ContentQueries(rf, ctx, dirIndex) {
        if (rf & 1) {
          i0.ɵɵcontentQuery(dirIndex, ContainerTitleComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContainerTitleMetaComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContainerTitleActionsComponent, 5);
          i0.ɵɵcontentQuery(dirIndex, ContainerContentComponent, 5);
        }
        if (rf & 2) {
          let _t;
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerTitleComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerTitleMetaComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerTitleActionsComponent = _t.first);
          i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerContentComponent = _t.first);
        }
      },
      hostVars: 2,
      hostBindings: function ContainerComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        type: "type",
        collapsed: "collapsed"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c2,
      decls: 8,
      vars: 2,
      consts: [["defaultContainerTitle", ""], ["collapsableContainerTitle", ""], ["containerTitleContent", ""], ["class", "container__title", 4, "ngIf"], ["class", "container__content", 4, "ngIf"], [1, "container__title"], [4, "ngTemplateOutlet"], ["class", "title__meta", 4, "ngIf"], ["class", "title__actions", 4, "ngIf"], [1, "title__meta"], [1, "title__actions"], [1, "container__content"], [1, "title__content"], [1, "a", "title__content", 3, "click"]],
      template: function ContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵtemplate(0, ContainerComponent_div_0_Template, 4, 3, "div", 3)(1, ContainerComponent_div_1_Template, 2, 0, "div", 4)(2, ContainerComponent_ng_template_2_Template, 2, 1, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(4, ContainerComponent_ng_template_4_Template, 2, 1, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor)(6, ContainerComponent_ng_template_6_Template, 1, 0, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.containerTitleComponent);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.containerContentComponent);
        }
      },
      dependencies: [i1.NgIf, i1.NgTemplateOutlet],
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return ContainerComponent;
})()));
(() => {
  ( false) && 0;
})();
let ContainerContentDividerComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerContentDividerComponent {
    constructor() {
      this.section = false;
    }
    static #_ = this.ɵfac = function ContainerContentDividerComponent_Factory(t) {
      return new (t || ContainerContentDividerComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerContentDividerComponent,
      selectors: [["sie-container-content-divider"]],
      inputs: {
        section: "section"
      },
      decls: 1,
      vars: 2,
      consts: [[1, "hr", "content__divider"]],
      template: function ContainerContentDividerComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵelement(0, "hr", 0);
        }
        if (rf & 2) {
          i0.ɵɵclassProp("content__divider--section", ctx.section);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return ContainerContentDividerComponent;
})()));
(() => {
  ( false) && 0;
})();
let ContainerGroupComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class ContainerGroupComponent {
    constructor() {
      this.hostClasses = 'containergroup';
    }
    static #_ = this.ɵfac = function ContainerGroupComponent_Factory(t) {
      return new (t || ContainerGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: ContainerGroupComponent,
      selectors: [["sie-container-group"]],
      hostVars: 2,
      hostBindings: function ContainerGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c4,
      decls: 1,
      vars: 0,
      template: function ContainerGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c3);
          i0.ɵɵprojection(0);
        }
      },
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return ContainerGroupComponent;
})()));
(() => {
  ( false) && 0;
})();
let SieContainerModule = /*#__PURE__*/(() => {
  class SieContainerModule {
    static #_ = this.ɵfac = function SieContainerModule_Factory(t) {
      return new (t || SieContainerModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieContainerModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]
    });
  }
  return SieContainerModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-container.mjs.map

/***/ }),

/***/ 6963:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C$: () => (/* binding */ SelectDirective),
/* harmony export */   _1: () => (/* binding */ SieFormModule),
/* harmony export */   hM: () => (/* binding */ InputTextDirective),
/* harmony export */   i4: () => (/* binding */ TextareaDirective),
/* harmony export */   jj: () => (/* binding */ CheckboxDirective),
/* harmony export */   pd: () => (/* binding */ SelectWrapperComponent)
/* harmony export */ });
/* unused harmony exports CheckboxWrapperComponent, FieldsetComponent, FormButtonsComponent, FormComponent, FormGroupComponent, FormGroupLineBreakComponent, FormRequiredMessageComponent, InputGroupComponent, InputGroupErrorComponent, RadioButtonDirective, RadioButtonWrapperComponent, SwitchComponent */
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(463);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3081);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8075);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5782);







const _c0 = ["*"];
function CheckboxWrapperComponent_ng_container_1_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function CheckboxWrapperComponent_ng_container_1_label_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function CheckboxWrapperComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, CheckboxWrapperComponent_ng_container_1_label_1_Template, 2, 2, "label", 0)(2, CheckboxWrapperComponent_ng_container_1_label_2_Template, 2, 2, "label", 1);
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
function CheckboxWrapperComponent_ng_container_2_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelement(0, "label");
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
  }
}
function CheckboxWrapperComponent_ng_container_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function CheckboxWrapperComponent_ng_container_2_p_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function CheckboxWrapperComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, CheckboxWrapperComponent_ng_container_2_label_1_Template, 1, 1, "label", 0);
    i0.ɵɵelementStart(2, "div", 3);
    i0.ɵɵtemplate(3, CheckboxWrapperComponent_ng_container_2_div_3_Template, 2, 1, "div", 4)(4, CheckboxWrapperComponent_ng_container_2_p_4_Template, 2, 1, "p", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
function FieldsetComponent_legend_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.subtitle);
  }
}
function FieldsetComponent_legend_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "legend", 1)(1, "div", 2);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, FieldsetComponent_legend_0_div_3_Template, 2, 1, "div", 3);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.title);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.subtitle);
  }
}
const _c1 = (/* unused pure expression or super */ null && ([[["sie-button"]]]));
const _c2 = (/* unused pure expression or super */ null && (["sie-button"]));
function InputGroupComponent_label_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("is-required", ctx_r0.required);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, "\n");
  }
}
function InputGroupComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 3);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.description, "\n");
  }
}
function RadioButtonWrapperComponent_ng_container_1_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function RadioButtonWrapperComponent_ng_container_1_label_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function RadioButtonWrapperComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, RadioButtonWrapperComponent_ng_container_1_label_1_Template, 2, 2, "label", 0)(2, RadioButtonWrapperComponent_ng_container_1_label_2_Template, 2, 2, "label", 1);
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
function RadioButtonWrapperComponent_ng_container_2_label_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelement(0, "label");
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("for", ctx_r0.for);
  }
}
function RadioButtonWrapperComponent_ng_container_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label);
  }
}
function RadioButtonWrapperComponent_ng_container_2_p_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description);
  }
}
function RadioButtonWrapperComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, RadioButtonWrapperComponent_ng_container_2_label_1_Template, 1, 1, "label", 0);
    i0.ɵɵelementStart(2, "div", 3);
    i0.ɵɵtemplate(3, RadioButtonWrapperComponent_ng_container_2_div_3_Template, 2, 1, "div", 4)(4, RadioButtonWrapperComponent_ng_container_2_p_4_Template, 2, 1, "p", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.label);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.description);
  }
}
const _c3 = "[_nghost-%COMP%]{display:block;font-size:initial;line-height:initial}";
function SwitchComponent_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 5);
  }
}
function SwitchComponent_label_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("for", ctx_r0.switchId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.label, " ");
  }
}
let CheckboxWrapperComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class CheckboxWrapperComponent {
    constructor() {
      this.description = null;
      this.alternative = false;
      this.shadow = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['checkboxWrapper'];
      if (this.alternative) {
        hostClassesArray.push('checkboxWrapper--alternative');
        if (this.shadow) {
          hostClassesArray.push('has-shadow');
        }
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function CheckboxWrapperComponent_Factory(t) {
      return new (t || CheckboxWrapperComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: CheckboxWrapperComponent,
      selectors: [["sie-checkbox-wrapper"]],
      hostVars: 2,
      hostBindings: function CheckboxWrapperComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        label: "label",
        description: "description",
        for: "for",
        alternative: "alternative",
        shadow: "shadow"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 2,
      consts: [[4, "ngIf"], ["class", "checkbox__description", 4, "ngIf"], [1, "checkbox__description"], [1, "checkboxWrapper--alternative__content"], ["class", "checkboxWrapper--alternative__header", 4, "ngIf"], [1, "checkboxWrapper--alternative__header"]],
      template: function CheckboxWrapperComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
          i0.ɵɵtemplate(1, CheckboxWrapperComponent_ng_container_1_Template, 3, 2, "ng-container", 0)(2, CheckboxWrapperComponent_ng_container_2_Template, 5, 3, "ng-container", 0);
        }
        if (rf & 2) {
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", !ctx.alternative);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.alternative);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["[_nghost-%COMP%]{display:block;font-size:initial;line-height:initial}"],
      changeDetection: 0
    });
  }
  return CheckboxWrapperComponent;
})()));
(() => {
  ( false) && 0;
})();
let FieldsetComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FieldsetComponent {
    constructor() {
      this.title = null;
      this.subtitle = null;
      this.alternative = false;
      this.compact = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['fieldset'];
      if (this.alternative) {
        hostClassesArray.push('fieldset--alternative');
      }
      if (this.compact) {
        hostClassesArray.push('fieldset--compact');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function FieldsetComponent_Factory(t) {
      return new (t || FieldsetComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FieldsetComponent,
      selectors: [["sie-fieldset"]],
      hostVars: 2,
      hostBindings: function FieldsetComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        title: "title",
        subtitle: "subtitle",
        alternative: "alternative",
        compact: "compact"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 1,
      consts: [["class", "legend", 4, "ngIf"], [1, "legend"], [1, "legend__title"], ["class", "legend__subtitle", 4, "ngIf"], [1, "legend__subtitle"]],
      template: function FieldsetComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵtemplate(0, FieldsetComponent_legend_0_Template, 4, 2, "legend", 0);
          i0.ɵɵelementStart(1, "div");
          i0.ɵɵprojection(2);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.title);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return FieldsetComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormComponent {
    static #_ = this.ɵfac = function FormComponent_Factory(t) {
      return new (t || FormComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormComponent,
      selectors: [["sie-form"]],
      ngContentSelectors: _c0,
      decls: 2,
      vars: 0,
      consts: [["novalidate", "", "autocomplete", "off", 1, "form"]],
      template: function FormComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "form", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormButtonsComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormButtonsComponent {
    static #_ = this.ɵfac = function FormButtonsComponent_Factory(t) {
      return new (t || FormButtonsComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormButtonsComponent,
      selectors: [["sie-form-buttons"]],
      ngContentSelectors: _c2,
      decls: 2,
      vars: 0,
      consts: [[1, "form__buttons"]],
      template: function FormButtonsComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef(_c1);
          i0.ɵɵelementStart(0, "div", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormButtonsComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormGroupComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormGroupComponent {
    constructor() {
      this.error = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['form__formGroup'];
      if (this.error) {
        hostClassesArray.push('has-error');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function FormGroupComponent_Factory(t) {
      return new (t || FormGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormGroupComponent,
      selectors: [["sie-form-group"]],
      hostVars: 2,
      hostBindings: function FormGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        error: "error"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function FormGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return FormGroupComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormGroupLineBreakComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormGroupLineBreakComponent {
    constructor() {
      this.hostClasses = 'form__lineBreak';
    }
    static #_ = this.ɵfac = function FormGroupLineBreakComponent_Factory(t) {
      return new (t || FormGroupLineBreakComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormGroupLineBreakComponent,
      selectors: [["sie-form-group-line-break"]],
      hostVars: 2,
      hostBindings: function FormGroupLineBreakComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function FormGroupLineBreakComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormGroupLineBreakComponent;
})()));
(() => {
  ( false) && 0;
})();
let FormRequiredMessageComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class FormRequiredMessageComponent {
    static #_ = this.ɵfac = function FormRequiredMessageComponent_Factory(t) {
      return new (t || FormRequiredMessageComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: FormRequiredMessageComponent,
      selectors: [["sie-form-required-message"]],
      ngContentSelectors: _c0,
      decls: 2,
      vars: 0,
      consts: [[1, "form__requiredMsg"]],
      template: function FormRequiredMessageComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "div", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return FormRequiredMessageComponent;
})()));
(() => {
  ( false) && 0;
})();
let InputGroupComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class InputGroupComponent {
    constructor() {
      this.label = null;
      this.description = null;
      this.required = false;
      this.size = null;
      this.invalid = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['inputGroup'];
      if (this.invalid) {
        hostClassesArray.push('is-invalid');
      }
      if (this.size) {
        hostClassesArray.push(`inputGroup--${this.size.toLowerCase()}`);
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function InputGroupComponent_Factory(t) {
      return new (t || InputGroupComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: InputGroupComponent,
      selectors: [["sie-input-group"]],
      hostVars: 2,
      hostBindings: function InputGroupComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        label: "label",
        description: "description",
        required: "required",
        size: "size",
        invalid: "invalid",
        for: "for"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 2,
      consts: [["class", "inputGroup__label", 3, "is-required", 4, "ngIf"], ["class", "inputGroup__description", 4, "ngIf"], [1, "inputGroup__label"], [1, "inputGroup__description"]],
      template: function InputGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵtemplate(0, InputGroupComponent_label_0_Template, 2, 4, "label", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵtemplate(2, InputGroupComponent_div_2_Template, 2, 1, "div", 1);
        }
        if (rf & 2) {
          i0.ɵɵproperty("ngIf", ctx.label);
          i0.ɵɵadvance(2);
          i0.ɵɵproperty("ngIf", ctx.description);
        }
      },
      dependencies: [i1.NgIf],
      styles: ["[_nghost-%COMP%]{display:block}"],
      changeDetection: 0
    });
  }
  return InputGroupComponent;
})()));
(() => {
  ( false) && 0;
})();
let InputGroupErrorComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class InputGroupErrorComponent {
    static #_ = this.ɵfac = function InputGroupErrorComponent_Factory(t) {
      return new (t || InputGroupErrorComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: InputGroupErrorComponent,
      selectors: [["sie-input-group-error"]],
      inputs: {
        for: "for"
      },
      ngContentSelectors: _c0,
      decls: 2,
      vars: 1,
      consts: [[1, "inputGroup--error"]],
      template: function InputGroupErrorComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵelementStart(0, "label", 0);
          i0.ɵɵprojection(1);
          i0.ɵɵelementEnd();
        }
        if (rf & 2) {
          i0.ɵɵattribute("for", ctx.for);
        }
      },
      styles: ["sie-input-group-error{display:block}sie-input-group-error .inputGroup--error{margin-bottom:0!important}sie-form-group-line-break sie-input-group-error:last-child .inputGroup--error{margin-bottom:16px!important;margin-bottom:1rem!important}sie-form-group.has-error:last-child>sie-form-group-line-break:last-child sie-input-group-error:last-child .inputGroup--error{margin-bottom:0!important}\n"],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return InputGroupErrorComponent;
})()));
(() => {
  ( false) && 0;
})();
let RadioButtonWrapperComponent = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class RadioButtonWrapperComponent {
    constructor() {
      this.description = null;
      this.alternative = false;
      this.shadow = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['radioButtonWrapper'];
      if (this.alternative) {
        hostClassesArray.push('radioButtonWrapper--alternative');
        if (this.shadow) {
          hostClassesArray.push('has-shadow');
        }
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function RadioButtonWrapperComponent_Factory(t) {
      return new (t || RadioButtonWrapperComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */i0.ɵɵdefineComponent({
      type: RadioButtonWrapperComponent,
      selectors: [["sie-radio-button-wrapper"]],
      hostVars: 2,
      hostBindings: function RadioButtonWrapperComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      },
      inputs: {
        label: "label",
        description: "description",
        for: "for",
        alternative: "alternative",
        shadow: "shadow"
      },
      features: [i0.ɵɵNgOnChangesFeature],
      ngContentSelectors: _c0,
      decls: 3,
      vars: 2,
      consts: [[4, "ngIf"], ["class", "radioButton__description", 4, "ngIf"], [1, "radioButton__description"], [1, "radioButtonWrapper--alternative__content"], ["class", "radioButtonWrapper--alternative__header", 4, "ngIf"], [1, "radioButtonWrapper--alternative__header"]],
      template: function RadioButtonWrapperComponent_Template(rf, ctx) {
        if (rf & 1) {
          i0.ɵɵprojectionDef();
          i0.ɵɵprojection(0);
          i0.ɵɵtemplate(1, RadioButtonWrapperComponent_ng_container_1_Template, 3, 2, "ng-container", 0)(2, RadioButtonWrapperComponent_ng_container_2_Template, 5, 3, "ng-container", 0);
        }
        if (rf & 2) {
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", !ctx.alternative);
          i0.ɵɵadvance();
          i0.ɵɵproperty("ngIf", ctx.alternative);
        }
      },
      dependencies: [i1.NgIf],
      styles: [_c3],
      changeDetection: 0
    });
  }
  return RadioButtonWrapperComponent;
})()));
(() => {
  ( false) && 0;
})();
let SelectWrapperComponent = /*#__PURE__*/(() => {
  class SelectWrapperComponent {
    constructor() {
      this.multiple = false;
    }
    ngOnInit() {
      if (!this.hostClasses) {
        this.setHostClasses();
      }
    }
    ngOnChanges() {
      this.setHostClasses();
    }
    setHostClasses() {
      const hostClassesArray = ['selectWrapper'];
      if (this.multiple) {
        hostClassesArray.push('selectWrapper--multiple');
      }
      this.hostClasses = hostClassesArray.join(' ');
    }
    static #_ = this.ɵfac = function SelectWrapperComponent_Factory(t) {
      return new (t || SelectWrapperComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: SelectWrapperComponent,
      selectors: [["sie-select-wrapper"]],
      hostVars: 2,
      hostBindings: function SelectWrapperComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      },
      inputs: {
        multiple: "multiple"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
      ngContentSelectors: _c0,
      decls: 1,
      vars: 0,
      template: function SelectWrapperComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
        }
      },
      styles: ["[_nghost-%COMP%]:before{top:calc(50% - 7px)!important;font-size:initial;line-height:initial}"],
      changeDetection: 0
    });
  }
  return SelectWrapperComponent;
})();
(() => {
  ( false) && 0;
})();

/* eslint-disable @typescript-eslint/ban-types */
const SWITCH_VALUE_ACCESSOR = {
  provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NG_VALUE_ACCESSOR,
  useExisting: (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(() => SwitchComponent),
  multi: true
};
let SwitchComponent = /*#__PURE__*/(() => {
  class SwitchComponent {
    constructor() {
      this.label = null;
      this.showIcon = false;
      this.size = 'medium';
      this.color = null;
    }
    registerOnChange(fn) {
      this.onChange = fn;
    }
    registerOnTouched(fn) {
      this.onTouched = fn;
    }
    setDisabledState(disabled) {
      this.disabled = disabled;
    }
    writeValue(checked) {
      this.checked = checked;
    }
    /* ControlValueAccessor - END */
    onKeyupEnter() {
      if (!this.disabled) {
        this.checked = !this.checked;
        this.onChange(this.checked);
        this.onTouched();
      }
    }
    change(event) {
      const checked = event.target.checked;
      this.checked = checked;
      this.onChange(this.checked);
      this.onTouched();
    }
    static #_ = this.ɵfac = function SwitchComponent_Factory(t) {
      return new (t || SwitchComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: SwitchComponent,
      selectors: [["sie-switch"]],
      hostBindings: function SwitchComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function SwitchComponent_keyup_enter_HostBindingHandler() {
            return ctx.onKeyupEnter();
          });
        }
      },
      inputs: {
        switchId: "switchId",
        label: "label",
        showIcon: "showIcon",
        size: "size",
        color: "color"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([SWITCH_VALUE_ACCESSOR])],
      decls: 5,
      vars: 8,
      consts: [[1, "switch", 3, "ngClass"], ["type", "checkbox", 1, "switch__checkbox", 3, "change", "id", "checked", "disabled"], ["sieBackgroundColor", "", 1, "switch__handle", 3, "backgroundColor", "for"], ["class", "switch__icon", 4, "ngIf"], ["class", "switch__label", 3, "for", 4, "ngIf"], [1, "switch__icon"], [1, "switch__label", 3, "for"]],
      template: function SwitchComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "input", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function SwitchComponent_Template_input_change_1_listener($event) {
            return ctx.change($event);
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "label", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, SwitchComponent_span_3_Template, 1, 0, "span", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, SwitchComponent_label_4_Template, 2, 2, "label", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "switch--" + ctx.size);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx.switchId)("checked", ctx.checked)("disabled", ctx.disabled);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("backgroundColor", ctx.color)("for", ctx.switchId);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showIcon);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.label);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_3__/* .BackgroundColorDirective */ .D$],
      styles: [".switch__checkbox[_ngcontent-%COMP%]:focus:not(:focus-visible){outline:0!important}"]
    });
  }
  return SwitchComponent;
})();
(() => {
  ( false) && 0;
})();
let CheckboxDirective = /*#__PURE__*/(() => {
  class CheckboxDirective {
    constructor() {
      this.hostClasses = 'inputGroup__checkbox';
    }
    static #_ = this.ɵfac = function CheckboxDirective_Factory(t) {
      return new (t || CheckboxDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: CheckboxDirective,
      selectors: [["", "sieCheckbox", ""]],
      hostVars: 2,
      hostBindings: function CheckboxDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return CheckboxDirective;
})();
(() => {
  ( false) && 0;
})();
let InputTextDirective = /*#__PURE__*/(() => {
  class InputTextDirective {
    constructor() {
      this.hostClasses = 'inputGroup__textInput';
    }
    static #_ = this.ɵfac = function InputTextDirective_Factory(t) {
      return new (t || InputTextDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: InputTextDirective,
      selectors: [["", "sieInputText", ""]],
      hostVars: 2,
      hostBindings: function InputTextDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return InputTextDirective;
})();
(() => {
  ( false) && 0;
})();
let RadioButtonDirective = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => {
  class RadioButtonDirective {
    constructor() {
      this.hostClasses = 'inputGroup__radioButton';
    }
    static #_ = this.ɵfac = function RadioButtonDirective_Factory(t) {
      return new (t || RadioButtonDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */i0.ɵɵdefineDirective({
      type: RadioButtonDirective,
      selectors: [["", "sieRadioButton", ""]],
      hostVars: 2,
      hostBindings: function RadioButtonDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          i0.ɵɵclassMap(ctx.hostClasses);
        }
      }
    });
  }
  return RadioButtonDirective;
})()));
(() => {
  ( false) && 0;
})();
let SelectDirective = /*#__PURE__*/(() => {
  class SelectDirective {
    constructor() {
      this.hostClasses = 'inputGroup__select';
    }
    static #_ = this.ɵfac = function SelectDirective_Factory(t) {
      return new (t || SelectDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: SelectDirective,
      selectors: [["", "sieSelect", ""]],
      hostVars: 2,
      hostBindings: function SelectDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return SelectDirective;
})();
(() => {
  ( false) && 0;
})();
let TextareaDirective = /*#__PURE__*/(() => {
  class TextareaDirective {
    constructor() {
      this.hostClasses = 'inputGroup__textarea';
    }
    static #_ = this.ɵfac = function TextareaDirective_Factory(t) {
      return new (t || TextareaDirective)();
    };
    static #_2 = this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: TextareaDirective,
      selectors: [["", "sieTextarea", ""]],
      hostVars: 2,
      hostBindings: function TextareaDirective_HostBindings(rf, ctx) {
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.hostClasses);
        }
      }
    });
  }
  return TextareaDirective;
})();
(() => {
  ( false) && 0;
})();
let SieFormModule = /*#__PURE__*/(() => {
  class SieFormModule {
    static #_ = this.ɵfac = function SieFormModule_Factory(t) {
      return new (t || SieFormModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieFormModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_3__/* .SieColorModule */ .$e]
    });
  }
  return SieFormModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-form.mjs.map

/***/ }),

/***/ 9710:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ IconComponent),
/* harmony export */   j: () => (/* binding */ SieIconModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(463);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3081);
/* harmony import */ var _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5782);






const _c0 = (a0, a1, a2, a3) => [a0, a1, a2, a3];
function IconComponent_span_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 1);
  }
  if (rf & 2) {
    let tmp_1_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction4"](3, _c0, ctx_r0.icon, (tmp_1_0 = ctx_r0.type) !== null && tmp_1_0 !== undefined ? tmp_1_0 : "", ctx_r0.rotate ? "is-rotated-" + ctx_r0.rotate : "", ctx_r0.flip ? "is-flipped-" + ctx_r0.flip : ""))("backgroundColor", ctx_r0.backgroundColor)("color", ctx_r0.color);
  }
}
let IconComponent = /*#__PURE__*/(() => {
  class IconComponent {
    constructor() {
      this.type = null;
      this.rotate = null;
      this.flip = null;
      this.backgroundColor = null;
      this.color = null;
    }
    static #_ = this.ɵfac = function IconComponent_Factory(t) {
      return new (t || IconComponent)();
    };
    static #_2 = this.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: IconComponent,
      selectors: [["sie-icon"]],
      inputs: {
        icon: "icon",
        type: "type",
        rotate: "rotate",
        flip: "flip",
        backgroundColor: "backgroundColor",
        color: "color"
      },
      decls: 1,
      vars: 1,
      consts: [["class", "span iconUxt", "aria-hidden", "true", "sieBackgroundColor", "", "sieColor", "", 3, "ngClass", "backgroundColor", "color", 4, "ngIf"], ["aria-hidden", "true", "sieBackgroundColor", "", "sieColor", "", 1, "span", "iconUxt", 3, "ngClass", "backgroundColor", "color"]],
      template: function IconComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, IconComponent_span_0_Template, 1, 8, "span", 0);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.icon);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .BackgroundColorDirective */ .D$, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .ColorDirective */ .Fy],
      encapsulation: 2,
      changeDetection: 0
    });
  }
  return IconComponent;
})();
(() => {
  ( false) && 0;
})();
let SieIconModule = /*#__PURE__*/(() => {
  class SieIconModule {
    static #_ = this.ɵfac = function SieIconModule_Factory(t) {
      return new (t || SieIconModule)();
    };
    static #_2 = this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: SieIconModule
    });
    static #_3 = this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _siemens_di_pa_sw_reusable_components_uxt_color__WEBPACK_IMPORTED_MODULE_2__/* .SieColorModule */ .$e]
    });
  }
  return SieIconModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=siemens-di-pa-sw-reusable-components-uxt-icon.mjs.map

/***/ }),

/***/ 6944:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   YG: () => (/* binding */ ColorPickerModule),
/* harmony export */   bk: () => (/* binding */ ColorPickerDirective)
/* harmony export */ });
/* unused harmony exports Cmyk, ColorPickerComponent, ColorPickerService, Hsla, Hsva, Rgba, SliderDirective, TextDirective */
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(463);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3081);




const _c0 = ["dialogPopup"];
const _c1 = ["hueSlider"];
const _c2 = ["alphaSlider"];
function ColorPickerComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div");
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMapInterpolate1"]("arrow arrow-", ctx_r1.cpUsePosition, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("left", ctx_r1.cpArrowPosition)("top", ctx_r1.arrowTop, "px");
  }
}
function ColorPickerComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("newValue", function ColorPickerComponent_div_3_Template_div_newValue_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onColorChange($event));
    })("dragStart", function ColorPickerComponent_div_3_Template_div_dragStart_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onDragStart("saturation-lightness"));
    })("dragEnd", function ColorPickerComponent_div_3_Template_div_dragEnd_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onDragEnd("saturation-lightness"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background-color", ctx_r1.hueSliderColor);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rgX", 1)("rgY", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("top", ctx_r1.slider == null ? null : ctx_r1.slider.v, "px")("left", ctx_r1.slider == null ? null : ctx_r1.slider.s, "px");
  }
}
function ColorPickerComponent__svg_svg_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "svg", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "path", 30)(2, "path", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ColorPickerComponent_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_button_9_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAddPresetColor($event, ctx_r1.selectedColor));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r1.cpAddColorButtonClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx_r1.cpPresetColors && ctx_r1.cpPresetColors.length >= ctx_r1.cpMaxPresetColorsLength);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r1.cpAddColorButtonText, " ");
  }
}
function ColorPickerComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 33);
  }
}
function ColorPickerComponent_div_21_input_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_21_input_6_Template_input_keyup_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_21_input_6_Template_input_newValue_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAlphaInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 1)("value", ctx_r1.cmykText == null ? null : ctx_r1.cmykText.a);
  }
}
function ColorPickerComponent_div_21_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "A");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ColorPickerComponent_div_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 34)(1, "div", 35)(2, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_21_Template_input_keyup_enter_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_21_Template_input_newValue_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onCyanInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_21_Template_input_keyup_enter_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_21_Template_input_newValue_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onMagentaInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_21_Template_input_keyup_enter_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_21_Template_input_newValue_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onYellowInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_21_Template_input_keyup_enter_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_21_Template_input_newValue_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onBlackInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, ColorPickerComponent_div_21_input_6_Template, 1, 2, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 35)(8, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "C");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "M");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Y");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "K");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, ColorPickerComponent_div_21_div_16_Template, 2, 0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx_r1.format !== 3 ? "none" : "block");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.cmykText == null ? null : ctx_r1.cmykText.c);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.cmykText == null ? null : ctx_r1.cmykText.m);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.cmykText == null ? null : ctx_r1.cmykText.y);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.cmykText == null ? null : ctx_r1.cmykText.k);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
  }
}
function ColorPickerComponent_div_22_input_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_22_input_5_Template_input_keyup_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_22_input_5_Template_input_newValue_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAlphaInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 1)("value", ctx_r1.hslaText == null ? null : ctx_r1.hslaText.a);
  }
}
function ColorPickerComponent_div_22_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "A");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ColorPickerComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 40)(1, "div", 35)(2, "input", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_22_Template_input_keyup_enter_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_22_Template_input_newValue_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onHueInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_22_Template_input_keyup_enter_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_22_Template_input_newValue_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onSaturationInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_22_Template_input_keyup_enter_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_22_Template_input_newValue_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onLightnessInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, ColorPickerComponent_div_22_input_5_Template, 1, 2, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 35)(7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "H");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "S");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "L");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, ColorPickerComponent_div_22_div_13_Template, 2, 0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx_r1.format !== 2 ? "none" : "block");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 360)("value", ctx_r1.hslaText == null ? null : ctx_r1.hslaText.h);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.hslaText == null ? null : ctx_r1.hslaText.s);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.hslaText == null ? null : ctx_r1.hslaText.l);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
  }
}
function ColorPickerComponent_div_23_input_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_23_input_5_Template_input_keyup_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r10);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_23_input_5_Template_input_newValue_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r10);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAlphaInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 1)("value", ctx_r1.rgbaText == null ? null : ctx_r1.rgbaText.a);
  }
}
function ColorPickerComponent_div_23_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "A");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ColorPickerComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 42)(1, "div", 35)(2, "input", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_23_Template_input_keyup_enter_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_23_Template_input_newValue_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onRedInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "input", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_23_Template_input_keyup_enter_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_23_Template_input_newValue_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onGreenInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_23_Template_input_keyup_enter_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_23_Template_input_newValue_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onBlueInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, ColorPickerComponent_div_23_input_5_Template, 1, 2, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 35)(7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "R");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "G");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "B");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, ColorPickerComponent_div_23_div_13_Template, 2, 0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx_r1.format !== 1 ? "none" : "block");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 255)("value", ctx_r1.rgbaText == null ? null : ctx_r1.rgbaText.r);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 255)("value", ctx_r1.rgbaText == null ? null : ctx_r1.rgbaText.g);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 255)("value", ctx_r1.rgbaText == null ? null : ctx_r1.rgbaText.b);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
  }
}
function ColorPickerComponent_div_24_input_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_24_input_3_Template_input_keyup_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r12);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_24_input_3_Template_input_newValue_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r12);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAlphaInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 1)("value", ctx_r1.hexAlpha);
  }
}
function ColorPickerComponent_div_24_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "A");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function ColorPickerComponent_div_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 44)(1, "div", 35)(2, "input", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("blur", function ColorPickerComponent_div_24_Template_input_blur_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onHexInput(null));
    })("keyup.enter", function ColorPickerComponent_div_24_Template_input_keyup_enter_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_24_Template_input_newValue_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onHexInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ColorPickerComponent_div_24_input_3_Template, 1, 2, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 35)(5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Hex");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, ColorPickerComponent_div_24_div_7_Template, 2, 0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx_r1.format !== 0 ? "none" : "block");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("hex-alpha", ctx_r1.cpAlphaChannel === "forced");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r1.hexText);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel === "forced");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel === "forced");
  }
}
function ColorPickerComponent_div_25_input_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_25_input_3_Template_input_keyup_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_25_input_3_Template_input_newValue_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAlphaInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 1)("value", ctx_r1.hslaText == null ? null : ctx_r1.hslaText.a);
  }
}
function ColorPickerComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 46)(1, "div", 35)(2, "input", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function ColorPickerComponent_div_25_Template_input_keyup_enter_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    })("newValue", function ColorPickerComponent_div_25_Template_input_newValue_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onValueInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ColorPickerComponent_div_25_input_3_Template, 1, 2, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 35)(5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "V");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "A");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rg", 100)("value", ctx_r1.hslaText == null ? null : ctx_r1.hslaText.l);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAlphaChannel !== "disabled");
  }
}
function ColorPickerComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 47)(1, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_div_26_Template_span_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r15);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onFormatToggle(-1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_div_26_Template_span_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r15);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onFormatToggle(1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
}
function ColorPickerComponent_div_27_div_4_div_1_span_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_div_27_div_4_div_1_span_1_Template_span_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r18);
      const color_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onRemovePresetColor($event, color_r17));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r1.cpRemoveColorButtonClass);
  }
}
function ColorPickerComponent_div_27_div_4_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_div_27_div_4_div_1_Template_div_click_0_listener() {
      const color_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r16).$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.setColorFromString(color_r17));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ColorPickerComponent_div_27_div_4_div_1_span_1_Template, 1, 3, "span", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r17 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background-color", color_r17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpAddColorButton);
  }
}
function ColorPickerComponent_div_27_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ColorPickerComponent_div_27_div_4_div_1_Template, 2, 3, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r1.cpPresetColorsClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r1.cpPresetColors);
  }
}
function ColorPickerComponent_div_27_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r1.cpPresetEmptyMessageClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r1.cpPresetEmptyMessage);
  }
}
function ColorPickerComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "hr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ColorPickerComponent_div_27_div_4_Template, 2, 4, "div", 51)(5, ColorPickerComponent_div_27_div_5_Template, 2, 4, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r1.cpPresetLabel);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpPresetColors == null ? null : ctx_r1.cpPresetColors.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !(ctx_r1.cpPresetColors == null ? null : ctx_r1.cpPresetColors.length) && ctx_r1.cpAddColorButton);
  }
}
function ColorPickerComponent_div_28_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_div_28_button_1_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onCancelColor($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r1.cpCancelButtonClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r1.cpCancelButtonText);
  }
}
function ColorPickerComponent_div_28_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_div_28_button_2_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r20);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onAcceptColor($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r1.cpOKButtonClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r1.cpOKButtonText);
  }
}
function ColorPickerComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ColorPickerComponent_div_28_button_1_Template, 2, 4, "button", 57)(2, ColorPickerComponent_div_28_button_2_Template, 2, 4, "button", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpCancelButton);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.cpOKButton);
  }
}
function ColorPickerComponent_div_29_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function ColorPickerComponent_div_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ColorPickerComponent_div_29_ng_container_1_Template, 1, 0, "ng-container", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.cpExtraTemplate);
  }
}
var ColorFormats = /*#__PURE__*/function (ColorFormats) {
  ColorFormats[ColorFormats["HEX"] = 0] = "HEX";
  ColorFormats[ColorFormats["RGBA"] = 1] = "RGBA";
  ColorFormats[ColorFormats["HSLA"] = 2] = "HSLA";
  ColorFormats[ColorFormats["CMYK"] = 3] = "CMYK";
  return ColorFormats;
}(ColorFormats || {});
class Rgba {
  r;
  g;
  b;
  a;
  constructor(r, g, b, a) {
    this.r = r;
    this.g = g;
    this.b = b;
    this.a = a;
  }
}
class Hsva {
  h;
  s;
  v;
  a;
  constructor(h, s, v, a) {
    this.h = h;
    this.s = s;
    this.v = v;
    this.a = a;
  }
}
class Hsla {
  h;
  s;
  l;
  a;
  constructor(h, s, l, a) {
    this.h = h;
    this.s = s;
    this.l = l;
    this.a = a;
  }
}
class Cmyk {
  c;
  m;
  y;
  k;
  a;
  constructor(c, m, y, k, a = 1) {
    this.c = c;
    this.m = m;
    this.y = y;
    this.k = k;
    this.a = a;
  }
}
function calculateAutoPositioning(elBounds, triggerElBounds) {
  // Defaults
  let usePositionX = 'right';
  let usePositionY = 'bottom';
  // Calculate collisions
  const {
    height,
    width
  } = elBounds;
  const {
    top,
    left
  } = triggerElBounds;
  const bottom = top + triggerElBounds.height;
  const right = left + triggerElBounds.width;
  const collisionTop = top - height < 0;
  const collisionBottom = bottom + height > (window.innerHeight || document.documentElement.clientHeight);
  const collisionLeft = left - width < 0;
  const collisionRight = right + width > (window.innerWidth || document.documentElement.clientWidth);
  const collisionAll = collisionTop && collisionBottom && collisionLeft && collisionRight;
  // Generate X & Y position values
  if (collisionBottom) {
    usePositionY = 'top';
  }
  if (collisionTop) {
    usePositionY = 'bottom';
  }
  if (collisionLeft) {
    usePositionX = 'right';
  }
  if (collisionRight) {
    usePositionX = 'left';
  }
  // Choose the largest gap available
  if (collisionAll) {
    const postions = ['left', 'right', 'top', 'bottom'];
    return postions.reduce((prev, next) => elBounds[prev] > elBounds[next] ? prev : next);
  }
  if (collisionLeft && collisionRight) {
    if (collisionTop) {
      return 'bottom';
    }
    if (collisionBottom) {
      return 'top';
    }
    return top > bottom ? 'top' : 'bottom';
  }
  if (collisionTop && collisionBottom) {
    if (collisionLeft) {
      return 'right';
    }
    if (collisionRight) {
      return 'left';
    }
    return left > right ? 'left' : 'right';
  }
  return `${usePositionY}-${usePositionX}`;
}
function detectIE() {
  let ua = '';
  if (typeof navigator !== 'undefined') {
    ua = navigator.userAgent.toLowerCase();
  }
  const msie = ua.indexOf('msie ');
  if (msie > 0) {
    // IE 10 or older => return version number
    return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
  }
  // Other browser
  return false;
}
let TextDirective = /*#__PURE__*/(() => {
  class TextDirective {
    rg;
    text;
    newValue = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    inputChange(event) {
      const value = event.target.value;
      if (this.rg === undefined) {
        this.newValue.emit(value);
      } else {
        const numeric = parseFloat(value);
        this.newValue.emit({
          v: numeric,
          rg: this.rg
        });
      }
    }
    static ɵfac = function TextDirective_Factory(t) {
      return new (t || TextDirective)();
    };
    static ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: TextDirective,
      selectors: [["", "text", ""]],
      hostBindings: function TextDirective_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("input", function TextDirective_input_HostBindingHandler($event) {
            return ctx.inputChange($event);
          });
        }
      },
      inputs: {
        rg: "rg",
        text: "text"
      },
      outputs: {
        newValue: "newValue"
      }
    });
  }
  return TextDirective;
})();
(() => {
  ( false) && 0;
})();
let SliderDirective = /*#__PURE__*/(() => {
  class SliderDirective {
    elRef;
    listenerMove;
    listenerStop;
    rgX;
    rgY;
    slider;
    dragEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    dragStart = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    newValue = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    mouseDown(event) {
      this.start(event);
    }
    touchStart(event) {
      this.start(event);
    }
    constructor(elRef) {
      this.elRef = elRef;
      this.listenerMove = event => this.move(event);
      this.listenerStop = () => this.stop();
    }
    move(event) {
      event.preventDefault();
      this.setCursor(event);
    }
    start(event) {
      this.setCursor(event);
      event.stopPropagation();
      document.addEventListener('mouseup', this.listenerStop);
      document.addEventListener('touchend', this.listenerStop);
      document.addEventListener('mousemove', this.listenerMove);
      document.addEventListener('touchmove', this.listenerMove);
      this.dragStart.emit();
    }
    stop() {
      document.removeEventListener('mouseup', this.listenerStop);
      document.removeEventListener('touchend', this.listenerStop);
      document.removeEventListener('mousemove', this.listenerMove);
      document.removeEventListener('touchmove', this.listenerMove);
      this.dragEnd.emit();
    }
    getX(event) {
      const position = this.elRef.nativeElement.getBoundingClientRect();
      const pageX = event.pageX !== undefined ? event.pageX : event.touches[0].pageX;
      return pageX - position.left - window.pageXOffset;
    }
    getY(event) {
      const position = this.elRef.nativeElement.getBoundingClientRect();
      const pageY = event.pageY !== undefined ? event.pageY : event.touches[0].pageY;
      return pageY - position.top - window.pageYOffset;
    }
    setCursor(event) {
      const width = this.elRef.nativeElement.offsetWidth;
      const height = this.elRef.nativeElement.offsetHeight;
      const x = Math.max(0, Math.min(this.getX(event), width));
      const y = Math.max(0, Math.min(this.getY(event), height));
      if (this.rgX !== undefined && this.rgY !== undefined) {
        this.newValue.emit({
          s: x / width,
          v: 1 - y / height,
          rgX: this.rgX,
          rgY: this.rgY
        });
      } else if (this.rgX === undefined && this.rgY !== undefined) {
        this.newValue.emit({
          v: y / height,
          rgY: this.rgY
        });
      } else if (this.rgX !== undefined && this.rgY === undefined) {
        this.newValue.emit({
          v: x / width,
          rgX: this.rgX
        });
      }
    }
    static ɵfac = function SliderDirective_Factory(t) {
      return new (t || SliderDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef));
    };
    static ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: SliderDirective,
      selectors: [["", "slider", ""]],
      hostBindings: function SliderDirective_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mousedown", function SliderDirective_mousedown_HostBindingHandler($event) {
            return ctx.mouseDown($event);
          })("touchstart", function SliderDirective_touchstart_HostBindingHandler($event) {
            return ctx.touchStart($event);
          });
        }
      },
      inputs: {
        rgX: "rgX",
        rgY: "rgY",
        slider: "slider"
      },
      outputs: {
        dragEnd: "dragEnd",
        dragStart: "dragStart",
        newValue: "newValue"
      }
    });
  }
  return SliderDirective;
})();
(() => {
  ( false) && 0;
})();
class SliderPosition {
  h;
  s;
  v;
  a;
  constructor(h, s, v, a) {
    this.h = h;
    this.s = s;
    this.v = v;
    this.a = a;
  }
}
class SliderDimension {
  h;
  s;
  v;
  a;
  constructor(h, s, v, a) {
    this.h = h;
    this.s = s;
    this.v = v;
    this.a = a;
  }
}
let ColorPickerService = /*#__PURE__*/(() => {
  class ColorPickerService {
    active = null;
    setActive(active) {
      if (this.active && this.active !== active && this.active.cpDialogDisplay !== 'inline') {
        this.active.closeDialog();
      }
      this.active = active;
    }
    hsva2hsla(hsva) {
      const h = hsva.h,
        s = hsva.s,
        v = hsva.v,
        a = hsva.a;
      if (v === 0) {
        return new Hsla(h, 0, 0, a);
      } else if (s === 0 && v === 1) {
        return new Hsla(h, 1, 1, a);
      } else {
        const l = v * (2 - s) / 2;
        return new Hsla(h, v * s / (1 - Math.abs(2 * l - 1)), l, a);
      }
    }
    hsla2hsva(hsla) {
      const h = Math.min(hsla.h, 1),
        s = Math.min(hsla.s, 1);
      const l = Math.min(hsla.l, 1),
        a = Math.min(hsla.a, 1);
      if (l === 0) {
        return new Hsva(h, 0, 0, a);
      } else {
        const v = l + s * (1 - Math.abs(2 * l - 1)) / 2;
        return new Hsva(h, 2 * (v - l) / v, v, a);
      }
    }
    hsvaToRgba(hsva) {
      let r, g, b;
      const h = hsva.h,
        s = hsva.s,
        v = hsva.v,
        a = hsva.a;
      const i = Math.floor(h * 6);
      const f = h * 6 - i;
      const p = v * (1 - s);
      const q = v * (1 - f * s);
      const t = v * (1 - (1 - f) * s);
      switch (i % 6) {
        case 0:
          r = v, g = t, b = p;
          break;
        case 1:
          r = q, g = v, b = p;
          break;
        case 2:
          r = p, g = v, b = t;
          break;
        case 3:
          r = p, g = q, b = v;
          break;
        case 4:
          r = t, g = p, b = v;
          break;
        case 5:
          r = v, g = p, b = q;
          break;
        default:
          r = 0, g = 0, b = 0;
      }
      return new Rgba(r, g, b, a);
    }
    cmykToRgb(cmyk) {
      const r = (1 - cmyk.c) * (1 - cmyk.k);
      const g = (1 - cmyk.m) * (1 - cmyk.k);
      const b = (1 - cmyk.y) * (1 - cmyk.k);
      return new Rgba(r, g, b, cmyk.a);
    }
    rgbaToCmyk(rgba) {
      const k = 1 - Math.max(rgba.r, rgba.g, rgba.b);
      if (k === 1) {
        return new Cmyk(0, 0, 0, 1, rgba.a);
      } else {
        const c = (1 - rgba.r - k) / (1 - k);
        const m = (1 - rgba.g - k) / (1 - k);
        const y = (1 - rgba.b - k) / (1 - k);
        return new Cmyk(c, m, y, k, rgba.a);
      }
    }
    rgbaToHsva(rgba) {
      let h, s;
      const r = Math.min(rgba.r, 1),
        g = Math.min(rgba.g, 1);
      const b = Math.min(rgba.b, 1),
        a = Math.min(rgba.a, 1);
      const max = Math.max(r, g, b),
        min = Math.min(r, g, b);
      const v = max,
        d = max - min;
      s = max === 0 ? 0 : d / max;
      if (max === min) {
        h = 0;
      } else {
        switch (max) {
          case r:
            h = (g - b) / d + (g < b ? 6 : 0);
            break;
          case g:
            h = (b - r) / d + 2;
            break;
          case b:
            h = (r - g) / d + 4;
            break;
          default:
            h = 0;
        }
        h /= 6;
      }
      return new Hsva(h, s, v, a);
    }
    rgbaToHex(rgba, allowHex8) {
      /* eslint-disable no-bitwise */
      let hex = '#' + (1 << 24 | rgba.r << 16 | rgba.g << 8 | rgba.b).toString(16).substr(1);
      if (allowHex8) {
        hex += (1 << 8 | Math.round(rgba.a * 255)).toString(16).substr(1);
      }
      /* eslint-enable no-bitwise */
      return hex;
    }
    normalizeCMYK(cmyk) {
      return new Cmyk(cmyk.c / 100, cmyk.m / 100, cmyk.y / 100, cmyk.k / 100, cmyk.a);
    }
    denormalizeCMYK(cmyk) {
      return new Cmyk(Math.floor(cmyk.c * 100), Math.floor(cmyk.m * 100), Math.floor(cmyk.y * 100), Math.floor(cmyk.k * 100), cmyk.a);
    }
    denormalizeRGBA(rgba) {
      return new Rgba(Math.round(rgba.r * 255), Math.round(rgba.g * 255), Math.round(rgba.b * 255), rgba.a);
    }
    stringToHsva(colorString = '', allowHex8 = false) {
      let hsva = null;
      colorString = (colorString || '').toLowerCase();
      const stringParsers = [{
        re: /(rgb)a?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*%?,\s*(\d{1,3})\s*%?(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/,
        parse: function (execResult) {
          return new Rgba(parseInt(execResult[2], 10) / 255, parseInt(execResult[3], 10) / 255, parseInt(execResult[4], 10) / 255, isNaN(parseFloat(execResult[5])) ? 1 : parseFloat(execResult[5]));
        }
      }, {
        re: /(hsl)a?\(\s*(\d{1,3})\s*,\s*(\d{1,3})%\s*,\s*(\d{1,3})%\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/,
        parse: function (execResult) {
          return new Hsla(parseInt(execResult[2], 10) / 360, parseInt(execResult[3], 10) / 100, parseInt(execResult[4], 10) / 100, isNaN(parseFloat(execResult[5])) ? 1 : parseFloat(execResult[5]));
        }
      }];
      if (allowHex8) {
        stringParsers.push({
          re: /#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})?$/,
          parse: function (execResult) {
            return new Rgba(parseInt(execResult[1], 16) / 255, parseInt(execResult[2], 16) / 255, parseInt(execResult[3], 16) / 255, parseInt(execResult[4] || 'FF', 16) / 255);
          }
        });
      } else {
        stringParsers.push({
          re: /#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})$/,
          parse: function (execResult) {
            return new Rgba(parseInt(execResult[1], 16) / 255, parseInt(execResult[2], 16) / 255, parseInt(execResult[3], 16) / 255, 1);
          }
        });
      }
      stringParsers.push({
        re: /#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])$/,
        parse: function (execResult) {
          return new Rgba(parseInt(execResult[1] + execResult[1], 16) / 255, parseInt(execResult[2] + execResult[2], 16) / 255, parseInt(execResult[3] + execResult[3], 16) / 255, 1);
        }
      });
      for (const key in stringParsers) {
        if (stringParsers.hasOwnProperty(key)) {
          const parser = stringParsers[key];
          const match = parser.re.exec(colorString),
            color = match && parser.parse(match);
          if (color) {
            if (color instanceof Rgba) {
              hsva = this.rgbaToHsva(color);
            } else if (color instanceof Hsla) {
              hsva = this.hsla2hsva(color);
            }
            return hsva;
          }
        }
      }
      return hsva;
    }
    outputFormat(hsva, outputFormat, alphaChannel) {
      if (outputFormat === 'auto') {
        outputFormat = hsva.a < 1 ? 'rgba' : 'hex';
      }
      switch (outputFormat) {
        case 'hsla':
          const hsla = this.hsva2hsla(hsva);
          const hslaText = new Hsla(Math.round(hsla.h * 360), Math.round(hsla.s * 100), Math.round(hsla.l * 100), Math.round(hsla.a * 100) / 100);
          if (hsva.a < 1 || alphaChannel === 'always') {
            return 'hsla(' + hslaText.h + ',' + hslaText.s + '%,' + hslaText.l + '%,' + hslaText.a + ')';
          } else {
            return 'hsl(' + hslaText.h + ',' + hslaText.s + '%,' + hslaText.l + '%)';
          }
        case 'rgba':
          const rgba = this.denormalizeRGBA(this.hsvaToRgba(hsva));
          if (hsva.a < 1 || alphaChannel === 'always') {
            return 'rgba(' + rgba.r + ',' + rgba.g + ',' + rgba.b + ',' + Math.round(rgba.a * 100) / 100 + ')';
          } else {
            return 'rgb(' + rgba.r + ',' + rgba.g + ',' + rgba.b + ')';
          }
        default:
          const allowHex8 = alphaChannel === 'always' || alphaChannel === 'forced';
          return this.rgbaToHex(this.denormalizeRGBA(this.hsvaToRgba(hsva)), allowHex8);
      }
    }
    static ɵfac = function ColorPickerService_Factory(t) {
      return new (t || ColorPickerService)();
    };
    static ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
      token: ColorPickerService,
      factory: ColorPickerService.ɵfac
    });
  }
  return ColorPickerService;
})();
(() => {
  ( false) && 0;
})();

// Do not store that on the class instance since the condition will be run
// every time the class is created.
const SUPPORTS_TOUCH = typeof window !== 'undefined' && 'ontouchstart' in window;
let ColorPickerComponent = /*#__PURE__*/(() => {
  class ColorPickerComponent {
    ngZone;
    elRef;
    cdRef;
    document;
    platformId;
    service;
    isIE10 = false;
    cmyk;
    hsva;
    width;
    height;
    cmykColor;
    outputColor;
    initialColor;
    fallbackColor;
    listenerResize;
    listenerMouseDown;
    directiveInstance;
    sliderH;
    sliderDimMax;
    directiveElementRef;
    dialogArrowSize = 10;
    dialogArrowOffset = 15;
    dialogInputFields = [ColorFormats.HEX, ColorFormats.RGBA, ColorFormats.HSLA, ColorFormats.CMYK];
    useRootViewContainer = false;
    show;
    hidden;
    top;
    left;
    position;
    format;
    slider;
    hexText;
    hexAlpha;
    cmykText;
    hslaText;
    rgbaText;
    arrowTop;
    selectedColor;
    hueSliderColor;
    alphaSliderColor;
    cpWidth;
    cpHeight;
    cpColorMode;
    cpCmykEnabled;
    cpAlphaChannel;
    cpOutputFormat;
    cpDisableInput;
    cpDialogDisplay;
    cpIgnoredElements;
    cpSaveClickOutside;
    cpCloseClickOutside;
    cpPosition;
    cpUsePosition;
    cpPositionOffset;
    cpOKButton;
    cpOKButtonText;
    cpOKButtonClass;
    cpCancelButton;
    cpCancelButtonText;
    cpCancelButtonClass;
    cpEyeDropper;
    eyeDropperSupported;
    cpPresetLabel;
    cpPresetColors;
    cpPresetColorsClass;
    cpMaxPresetColorsLength;
    cpPresetEmptyMessage;
    cpPresetEmptyMessageClass;
    cpAddColorButton;
    cpAddColorButtonText;
    cpAddColorButtonClass;
    cpRemoveColorButtonClass;
    cpArrowPosition;
    cpTriggerElement;
    cpExtraTemplate;
    dialogElement;
    hueSlider;
    alphaSlider;
    handleEsc(event) {
      if (this.show && this.cpDialogDisplay === 'popup') {
        this.onCancelColor(event);
      }
    }
    handleEnter(event) {
      if (this.show && this.cpDialogDisplay === 'popup') {
        this.onAcceptColor(event);
      }
    }
    constructor(ngZone, elRef, cdRef, document, platformId, service) {
      this.ngZone = ngZone;
      this.elRef = elRef;
      this.cdRef = cdRef;
      this.document = document;
      this.platformId = platformId;
      this.service = service;
      this.eyeDropperSupported = (0,_angular_common__WEBPACK_IMPORTED_MODULE_1__.isPlatformBrowser)(this.platformId) && 'EyeDropper' in this.document.defaultView;
    }
    ngOnInit() {
      this.slider = new SliderPosition(0, 0, 0, 0);
      const hueWidth = this.hueSlider.nativeElement.offsetWidth || 140;
      const alphaWidth = this.alphaSlider.nativeElement.offsetWidth || 140;
      this.sliderDimMax = new SliderDimension(hueWidth, this.cpWidth, 130, alphaWidth);
      if (this.cpCmykEnabled) {
        this.format = ColorFormats.CMYK;
      } else if (this.cpOutputFormat === 'rgba') {
        this.format = ColorFormats.RGBA;
      } else if (this.cpOutputFormat === 'hsla') {
        this.format = ColorFormats.HSLA;
      } else {
        this.format = ColorFormats.HEX;
      }
      this.listenerMouseDown = event => {
        this.onMouseDown(event);
      };
      this.listenerResize = () => {
        this.onResize();
      };
      this.openDialog(this.initialColor, false);
    }
    ngOnDestroy() {
      this.closeDialog();
    }
    ngAfterViewInit() {
      if (this.cpWidth !== 230 || this.cpDialogDisplay === 'inline') {
        const hueWidth = this.hueSlider.nativeElement.offsetWidth || 140;
        const alphaWidth = this.alphaSlider.nativeElement.offsetWidth || 140;
        this.sliderDimMax = new SliderDimension(hueWidth, this.cpWidth, 130, alphaWidth);
        this.updateColorPicker(false);
        this.cdRef.detectChanges();
      }
    }
    openDialog(color, emit = true) {
      this.service.setActive(this);
      if (!this.width) {
        this.cpWidth = this.directiveElementRef.nativeElement.offsetWidth;
      }
      if (!this.height) {
        this.height = 320;
      }
      this.setInitialColor(color);
      this.setColorFromString(color, emit);
      this.openColorPicker();
    }
    closeDialog() {
      this.closeColorPicker();
    }
    setupDialog(instance, elementRef, color, cpWidth, cpHeight, cpDialogDisplay, cpFallbackColor, cpColorMode, cpCmykEnabled, cpAlphaChannel, cpOutputFormat, cpDisableInput, cpIgnoredElements, cpSaveClickOutside, cpCloseClickOutside, cpUseRootViewContainer, cpPosition, cpPositionOffset, cpPositionRelativeToArrow, cpPresetLabel, cpPresetColors, cpPresetColorsClass, cpMaxPresetColorsLength, cpPresetEmptyMessage, cpPresetEmptyMessageClass, cpOKButton, cpOKButtonClass, cpOKButtonText, cpCancelButton, cpCancelButtonClass, cpCancelButtonText, cpAddColorButton, cpAddColorButtonClass, cpAddColorButtonText, cpRemoveColorButtonClass, cpEyeDropper, cpTriggerElement, cpExtraTemplate) {
      this.setInitialColor(color);
      this.setColorMode(cpColorMode);
      this.isIE10 = detectIE() === 10;
      this.directiveInstance = instance;
      this.directiveElementRef = elementRef;
      this.cpDisableInput = cpDisableInput;
      this.cpCmykEnabled = cpCmykEnabled;
      this.cpAlphaChannel = cpAlphaChannel;
      this.cpOutputFormat = cpOutputFormat;
      this.cpDialogDisplay = cpDialogDisplay;
      this.cpIgnoredElements = cpIgnoredElements;
      this.cpSaveClickOutside = cpSaveClickOutside;
      this.cpCloseClickOutside = cpCloseClickOutside;
      this.useRootViewContainer = cpUseRootViewContainer;
      this.width = this.cpWidth = parseInt(cpWidth, 10);
      this.height = this.cpHeight = parseInt(cpHeight, 10);
      this.cpPosition = cpPosition;
      this.cpPositionOffset = parseInt(cpPositionOffset, 10);
      this.cpOKButton = cpOKButton;
      this.cpOKButtonText = cpOKButtonText;
      this.cpOKButtonClass = cpOKButtonClass;
      this.cpCancelButton = cpCancelButton;
      this.cpCancelButtonText = cpCancelButtonText;
      this.cpCancelButtonClass = cpCancelButtonClass;
      this.cpEyeDropper = cpEyeDropper;
      this.fallbackColor = cpFallbackColor || '#fff';
      this.setPresetConfig(cpPresetLabel, cpPresetColors);
      this.cpPresetColorsClass = cpPresetColorsClass;
      this.cpMaxPresetColorsLength = cpMaxPresetColorsLength;
      this.cpPresetEmptyMessage = cpPresetEmptyMessage;
      this.cpPresetEmptyMessageClass = cpPresetEmptyMessageClass;
      this.cpAddColorButton = cpAddColorButton;
      this.cpAddColorButtonText = cpAddColorButtonText;
      this.cpAddColorButtonClass = cpAddColorButtonClass;
      this.cpRemoveColorButtonClass = cpRemoveColorButtonClass;
      this.cpTriggerElement = cpTriggerElement;
      this.cpExtraTemplate = cpExtraTemplate;
      if (!cpPositionRelativeToArrow) {
        this.dialogArrowOffset = 0;
      }
      if (cpDialogDisplay === 'inline') {
        this.dialogArrowSize = 0;
        this.dialogArrowOffset = 0;
      }
      if (cpOutputFormat === 'hex' && cpAlphaChannel !== 'always' && cpAlphaChannel !== 'forced') {
        this.cpAlphaChannel = 'disabled';
      }
    }
    setColorMode(mode) {
      switch (mode.toString().toUpperCase()) {
        case '1':
        case 'C':
        case 'COLOR':
          this.cpColorMode = 1;
          break;
        case '2':
        case 'G':
        case 'GRAYSCALE':
          this.cpColorMode = 2;
          break;
        case '3':
        case 'P':
        case 'PRESETS':
          this.cpColorMode = 3;
          break;
        default:
          this.cpColorMode = 1;
      }
    }
    setInitialColor(color) {
      this.initialColor = color;
    }
    setPresetConfig(cpPresetLabel, cpPresetColors) {
      this.cpPresetLabel = cpPresetLabel;
      this.cpPresetColors = cpPresetColors;
    }
    setColorFromString(value, emit = true, update = true) {
      let hsva;
      if (this.cpAlphaChannel === 'always' || this.cpAlphaChannel === 'forced') {
        hsva = this.service.stringToHsva(value, true);
        if (!hsva && !this.hsva) {
          hsva = this.service.stringToHsva(value, false);
        }
      } else {
        hsva = this.service.stringToHsva(value, false);
      }
      if (!hsva && !this.hsva) {
        hsva = this.service.stringToHsva(this.fallbackColor, false);
      }
      if (hsva) {
        this.hsva = hsva;
        this.sliderH = this.hsva.h;
        if (this.cpOutputFormat === 'hex' && this.cpAlphaChannel === 'disabled') {
          this.hsva.a = 1;
        }
        this.updateColorPicker(emit, update);
      }
    }
    onResize() {
      if (this.position === 'fixed') {
        this.setDialogPosition();
      } else if (this.cpDialogDisplay !== 'inline') {
        this.closeColorPicker();
      }
    }
    onDragEnd(slider) {
      this.directiveInstance.sliderDragEnd({
        slider: slider,
        color: this.outputColor
      });
    }
    onDragStart(slider) {
      this.directiveInstance.sliderDragStart({
        slider: slider,
        color: this.outputColor
      });
    }
    onMouseDown(event) {
      if (this.show && !this.isIE10 && this.cpDialogDisplay === 'popup' && event.target !== this.directiveElementRef.nativeElement && !this.isDescendant(this.elRef.nativeElement, event.target) && !this.isDescendant(this.directiveElementRef.nativeElement, event.target) && this.cpIgnoredElements.filter(item => item === event.target).length === 0) {
        this.ngZone.run(() => {
          if (this.cpSaveClickOutside) {
            this.directiveInstance.colorSelected(this.outputColor);
          } else {
            this.hsva = null;
            this.setColorFromString(this.initialColor, false);
            if (this.cpCmykEnabled) {
              this.directiveInstance.cmykChanged(this.cmykColor);
            }
            this.directiveInstance.colorChanged(this.initialColor);
            this.directiveInstance.colorCanceled();
          }
          if (this.cpCloseClickOutside) {
            this.closeColorPicker();
          }
        });
      }
    }
    onAcceptColor(event) {
      event.stopPropagation();
      if (this.outputColor) {
        this.directiveInstance.colorSelected(this.outputColor);
      }
      if (this.cpDialogDisplay === 'popup') {
        this.closeColorPicker();
      }
    }
    onCancelColor(event) {
      this.hsva = null;
      event.stopPropagation();
      this.directiveInstance.colorCanceled();
      this.setColorFromString(this.initialColor, true);
      if (this.cpDialogDisplay === 'popup') {
        if (this.cpCmykEnabled) {
          this.directiveInstance.cmykChanged(this.cmykColor);
        }
        this.directiveInstance.colorChanged(this.initialColor, true);
        this.closeColorPicker();
      }
    }
    onEyeDropper() {
      if (!this.eyeDropperSupported) return;
      const eyeDropper = new window.EyeDropper();
      eyeDropper.open().then(eyeDropperResult => {
        this.setColorFromString(eyeDropperResult.sRGBHex, true);
      });
    }
    onFormatToggle(change) {
      const availableFormats = this.dialogInputFields.length - (this.cpCmykEnabled ? 0 : 1);
      const nextFormat = ((this.dialogInputFields.indexOf(this.format) + change) % availableFormats + availableFormats) % availableFormats;
      this.format = this.dialogInputFields[nextFormat];
    }
    onColorChange(value) {
      this.hsva.s = value.s / value.rgX;
      this.hsva.v = value.v / value.rgY;
      this.updateColorPicker();
      this.directiveInstance.sliderChanged({
        slider: 'lightness',
        value: this.hsva.v,
        color: this.outputColor
      });
      this.directiveInstance.sliderChanged({
        slider: 'saturation',
        value: this.hsva.s,
        color: this.outputColor
      });
    }
    onHueChange(value) {
      this.hsva.h = value.v / value.rgX;
      this.sliderH = this.hsva.h;
      this.updateColorPicker();
      this.directiveInstance.sliderChanged({
        slider: 'hue',
        value: this.hsva.h,
        color: this.outputColor
      });
    }
    onValueChange(value) {
      this.hsva.v = value.v / value.rgX;
      this.updateColorPicker();
      this.directiveInstance.sliderChanged({
        slider: 'value',
        value: this.hsva.v,
        color: this.outputColor
      });
    }
    onAlphaChange(value) {
      this.hsva.a = value.v / value.rgX;
      this.updateColorPicker();
      this.directiveInstance.sliderChanged({
        slider: 'alpha',
        value: this.hsva.a,
        color: this.outputColor
      });
    }
    onHexInput(value) {
      if (value === null) {
        this.updateColorPicker();
      } else {
        if (value && value[0] !== '#') {
          value = '#' + value;
        }
        let validHex = /^#([a-f0-9]{3}|[a-f0-9]{6})$/gi;
        if (this.cpAlphaChannel === 'always') {
          validHex = /^#([a-f0-9]{3}|[a-f0-9]{6}|[a-f0-9]{8})$/gi;
        }
        const valid = validHex.test(value);
        if (valid) {
          if (value.length < 5) {
            value = '#' + value.substring(1).split('').map(c => c + c).join('');
          }
          if (this.cpAlphaChannel === 'forced') {
            value += Math.round(this.hsva.a * 255).toString(16);
          }
          this.setColorFromString(value, true, false);
        }
        this.directiveInstance.inputChanged({
          input: 'hex',
          valid: valid,
          value: value,
          color: this.outputColor
        });
      }
    }
    onRedInput(value) {
      const rgba = this.service.hsvaToRgba(this.hsva);
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        rgba.r = value.v / value.rg;
        this.hsva = this.service.rgbaToHsva(rgba);
        this.sliderH = this.hsva.h;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'red',
        valid: valid,
        value: rgba.r,
        color: this.outputColor
      });
    }
    onBlueInput(value) {
      const rgba = this.service.hsvaToRgba(this.hsva);
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        rgba.b = value.v / value.rg;
        this.hsva = this.service.rgbaToHsva(rgba);
        this.sliderH = this.hsva.h;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'blue',
        valid: valid,
        value: rgba.b,
        color: this.outputColor
      });
    }
    onGreenInput(value) {
      const rgba = this.service.hsvaToRgba(this.hsva);
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        rgba.g = value.v / value.rg;
        this.hsva = this.service.rgbaToHsva(rgba);
        this.sliderH = this.hsva.h;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'green',
        valid: valid,
        value: rgba.g,
        color: this.outputColor
      });
    }
    onHueInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.hsva.h = value.v / value.rg;
        this.sliderH = this.hsva.h;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'hue',
        valid: valid,
        value: this.hsva.h,
        color: this.outputColor
      });
    }
    onValueInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.hsva.v = value.v / value.rg;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'value',
        valid: valid,
        value: this.hsva.v,
        color: this.outputColor
      });
    }
    onAlphaInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.hsva.a = value.v / value.rg;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'alpha',
        valid: valid,
        value: this.hsva.a,
        color: this.outputColor
      });
    }
    onLightnessInput(value) {
      const hsla = this.service.hsva2hsla(this.hsva);
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        hsla.l = value.v / value.rg;
        this.hsva = this.service.hsla2hsva(hsla);
        this.sliderH = this.hsva.h;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'lightness',
        valid: valid,
        value: hsla.l,
        color: this.outputColor
      });
    }
    onSaturationInput(value) {
      const hsla = this.service.hsva2hsla(this.hsva);
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        hsla.s = value.v / value.rg;
        this.hsva = this.service.hsla2hsva(hsla);
        this.sliderH = this.hsva.h;
        this.updateColorPicker();
      }
      this.directiveInstance.inputChanged({
        input: 'saturation',
        valid: valid,
        value: hsla.s,
        color: this.outputColor
      });
    }
    onCyanInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.cmyk.c = value.v;
        this.updateColorPicker(false, true, true);
      }
      this.directiveInstance.inputChanged({
        input: 'cyan',
        valid: true,
        value: this.cmyk.c,
        color: this.outputColor
      });
    }
    onMagentaInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.cmyk.m = value.v;
        this.updateColorPicker(false, true, true);
      }
      this.directiveInstance.inputChanged({
        input: 'magenta',
        valid: true,
        value: this.cmyk.m,
        color: this.outputColor
      });
    }
    onYellowInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.cmyk.y = value.v;
        this.updateColorPicker(false, true, true);
      }
      this.directiveInstance.inputChanged({
        input: 'yellow',
        valid: true,
        value: this.cmyk.y,
        color: this.outputColor
      });
    }
    onBlackInput(value) {
      const valid = !isNaN(value.v) && value.v >= 0 && value.v <= value.rg;
      if (valid) {
        this.cmyk.k = value.v;
        this.updateColorPicker(false, true, true);
      }
      this.directiveInstance.inputChanged({
        input: 'black',
        valid: true,
        value: this.cmyk.k,
        color: this.outputColor
      });
    }
    onAddPresetColor(event, value) {
      event.stopPropagation();
      if (!this.cpPresetColors.filter(color => color === value).length) {
        this.cpPresetColors = this.cpPresetColors.concat(value);
        this.directiveInstance.presetColorsChanged(this.cpPresetColors);
      }
    }
    onRemovePresetColor(event, value) {
      event.stopPropagation();
      this.cpPresetColors = this.cpPresetColors.filter(color => color !== value);
      this.directiveInstance.presetColorsChanged(this.cpPresetColors);
    }
    // Private helper functions for the color picker dialog status
    openColorPicker() {
      if (!this.show) {
        this.show = true;
        this.hidden = true;
        setTimeout(() => {
          this.hidden = false;
          this.setDialogPosition();
          this.cdRef.detectChanges();
        }, 0);
        this.directiveInstance.stateChanged(true);
        if (!this.isIE10) {
          // The change detection should be run on `mousedown` event only when the condition
          // is met within the `onMouseDown` method.
          this.ngZone.runOutsideAngular(() => {
            // There's no sense to add both event listeners on touch devices since the `touchstart`
            // event is handled earlier than `mousedown`, so we'll get 2 change detections and the
            // second one will be unnecessary.
            if (SUPPORTS_TOUCH) {
              document.addEventListener('touchstart', this.listenerMouseDown);
            } else {
              document.addEventListener('mousedown', this.listenerMouseDown);
            }
          });
        }
        window.addEventListener('resize', this.listenerResize);
      }
    }
    closeColorPicker() {
      if (this.show) {
        this.show = false;
        this.directiveInstance.stateChanged(false);
        if (!this.isIE10) {
          if (SUPPORTS_TOUCH) {
            document.removeEventListener('touchstart', this.listenerMouseDown);
          } else {
            document.removeEventListener('mousedown', this.listenerMouseDown);
          }
        }
        window.removeEventListener('resize', this.listenerResize);
        if (!this.cdRef['destroyed']) {
          this.cdRef.detectChanges();
        }
      }
    }
    updateColorPicker(emit = true, update = true, cmykInput = false) {
      if (this.sliderDimMax) {
        if (this.cpColorMode === 2) {
          this.hsva.s = 0;
        }
        let hue, hsla, rgba;
        const lastOutput = this.outputColor;
        hsla = this.service.hsva2hsla(this.hsva);
        if (!this.cpCmykEnabled) {
          rgba = this.service.denormalizeRGBA(this.service.hsvaToRgba(this.hsva));
        } else {
          if (!cmykInput) {
            rgba = this.service.hsvaToRgba(this.hsva);
            this.cmyk = this.service.denormalizeCMYK(this.service.rgbaToCmyk(rgba));
          } else {
            rgba = this.service.cmykToRgb(this.service.normalizeCMYK(this.cmyk));
            this.hsva = this.service.rgbaToHsva(rgba);
          }
          rgba = this.service.denormalizeRGBA(rgba);
          this.sliderH = this.hsva.h;
        }
        hue = this.service.denormalizeRGBA(this.service.hsvaToRgba(new Hsva(this.sliderH || this.hsva.h, 1, 1, 1)));
        if (update) {
          this.hslaText = new Hsla(Math.round(hsla.h * 360), Math.round(hsla.s * 100), Math.round(hsla.l * 100), Math.round(hsla.a * 100) / 100);
          this.rgbaText = new Rgba(rgba.r, rgba.g, rgba.b, Math.round(rgba.a * 100) / 100);
          if (this.cpCmykEnabled) {
            this.cmykText = new Cmyk(this.cmyk.c, this.cmyk.m, this.cmyk.y, this.cmyk.k, Math.round(this.cmyk.a * 100) / 100);
          }
          const allowHex8 = this.cpAlphaChannel === 'always';
          this.hexText = this.service.rgbaToHex(rgba, allowHex8);
          this.hexAlpha = this.rgbaText.a;
        }
        if (this.cpOutputFormat === 'auto') {
          if (this.format !== ColorFormats.RGBA && this.format !== ColorFormats.CMYK && this.format !== ColorFormats.HSLA) {
            if (this.hsva.a < 1) {
              this.format = this.hsva.a < 1 ? ColorFormats.RGBA : ColorFormats.HEX;
            }
          }
        }
        this.hueSliderColor = 'rgb(' + hue.r + ',' + hue.g + ',' + hue.b + ')';
        this.alphaSliderColor = 'rgb(' + rgba.r + ',' + rgba.g + ',' + rgba.b + ')';
        this.outputColor = this.service.outputFormat(this.hsva, this.cpOutputFormat, this.cpAlphaChannel);
        this.selectedColor = this.service.outputFormat(this.hsva, 'rgba', null);
        if (this.format !== ColorFormats.CMYK) {
          this.cmykColor = '';
        } else {
          if (this.cpAlphaChannel === 'always' || this.cpAlphaChannel === 'enabled' || this.cpAlphaChannel === 'forced') {
            const alpha = Math.round(this.cmyk.a * 100) / 100;
            this.cmykColor = `cmyka(${this.cmyk.c},${this.cmyk.m},${this.cmyk.y},${this.cmyk.k},${alpha})`;
          } else {
            this.cmykColor = `cmyk(${this.cmyk.c},${this.cmyk.m},${this.cmyk.y},${this.cmyk.k})`;
          }
        }
        this.slider = new SliderPosition((this.sliderH || this.hsva.h) * this.sliderDimMax.h - 8, this.hsva.s * this.sliderDimMax.s - 8, (1 - this.hsva.v) * this.sliderDimMax.v - 8, this.hsva.a * this.sliderDimMax.a - 8);
        if (emit && lastOutput !== this.outputColor) {
          if (this.cpCmykEnabled) {
            this.directiveInstance.cmykChanged(this.cmykColor);
          }
          this.directiveInstance.colorChanged(this.outputColor);
        }
      }
    }
    // Private helper functions for the color picker dialog positioning
    setDialogPosition() {
      if (this.cpDialogDisplay === 'inline') {
        this.position = 'relative';
      } else {
        let position = 'static',
          transform = '',
          style;
        let parentNode = null,
          transformNode = null;
        let node = this.directiveElementRef.nativeElement.parentNode;
        const dialogHeight = this.dialogElement.nativeElement.offsetHeight;
        while (node !== null && node.tagName !== 'HTML') {
          style = window.getComputedStyle(node);
          position = style.getPropertyValue('position');
          transform = style.getPropertyValue('transform');
          if (position !== 'static' && parentNode === null) {
            parentNode = node;
          }
          if (transform && transform !== 'none' && transformNode === null) {
            transformNode = node;
          }
          if (position === 'fixed') {
            parentNode = transformNode;
            break;
          }
          node = node.parentNode;
        }
        const boxDirective = this.createDialogBox(this.directiveElementRef.nativeElement, position !== 'fixed');
        if (this.useRootViewContainer || position === 'fixed' && (!parentNode || parentNode instanceof HTMLUnknownElement)) {
          this.top = boxDirective.top;
          this.left = boxDirective.left;
        } else {
          if (parentNode === null) {
            parentNode = node;
          }
          const boxParent = this.createDialogBox(parentNode, position !== 'fixed');
          this.top = boxDirective.top - boxParent.top;
          this.left = boxDirective.left - boxParent.left;
        }
        if (position === 'fixed') {
          this.position = 'fixed';
        }
        let usePosition = this.cpPosition;
        const dialogBounds = this.dialogElement.nativeElement.getBoundingClientRect();
        if (this.cpPosition === 'auto') {
          const triggerBounds = this.cpTriggerElement.nativeElement.getBoundingClientRect();
          usePosition = calculateAutoPositioning(dialogBounds, triggerBounds);
        }
        this.arrowTop = usePosition === 'top' ? dialogHeight - 1 : undefined;
        this.cpArrowPosition = undefined;
        switch (usePosition) {
          case 'top':
            this.top -= dialogHeight + this.dialogArrowSize;
            this.left += this.cpPositionOffset / 100 * boxDirective.width - this.dialogArrowOffset;
            break;
          case 'bottom':
            this.top += boxDirective.height + this.dialogArrowSize;
            this.left += this.cpPositionOffset / 100 * boxDirective.width - this.dialogArrowOffset;
            break;
          case 'top-left':
          case 'left-top':
            this.top -= dialogHeight - boxDirective.height + boxDirective.height * this.cpPositionOffset / 100;
            this.left -= this.cpWidth + this.dialogArrowSize - 2 - this.dialogArrowOffset;
            break;
          case 'top-right':
          case 'right-top':
            this.top -= dialogHeight - boxDirective.height + boxDirective.height * this.cpPositionOffset / 100;
            this.left += boxDirective.width + this.dialogArrowSize - 2 - this.dialogArrowOffset;
            break;
          case 'left':
          case 'bottom-left':
          case 'left-bottom':
            this.top += boxDirective.height * this.cpPositionOffset / 100 - this.dialogArrowOffset;
            this.left -= this.cpWidth + this.dialogArrowSize - 2;
            break;
          case 'right':
          case 'bottom-right':
          case 'right-bottom':
          default:
            this.top += boxDirective.height * this.cpPositionOffset / 100 - this.dialogArrowOffset;
            this.left += boxDirective.width + this.dialogArrowSize - 2;
            break;
        }
        const windowInnerHeight = window.innerHeight;
        const windowInnerWidth = window.innerWidth;
        const elRefClientRect = this.elRef.nativeElement.getBoundingClientRect();
        const bottom = this.top + dialogBounds.height;
        if (bottom > windowInnerHeight) {
          this.top = windowInnerHeight - dialogBounds.height;
          this.cpArrowPosition = elRefClientRect.x / 2 - 20;
        }
        const right = this.left + dialogBounds.width;
        if (right > windowInnerWidth) {
          this.left = windowInnerWidth - dialogBounds.width;
          this.cpArrowPosition = elRefClientRect.x / 2 - 20;
        }
        this.cpUsePosition = usePosition;
      }
    }
    // Private helper functions for the color picker dialog positioning and opening
    isDescendant(parent, child) {
      let node = child.parentNode;
      while (node !== null) {
        if (node === parent) {
          return true;
        }
        node = node.parentNode;
      }
      return false;
    }
    createDialogBox(element, offset) {
      const {
        top,
        left
      } = element.getBoundingClientRect();
      return {
        top: top + (offset ? window.pageYOffset : 0),
        left: left + (offset ? window.pageXOffset : 0),
        width: element.offsetWidth,
        height: element.offsetHeight
      };
    }
    static ɵfac = function ColorPickerComponent_Factory(t) {
      return new (t || ColorPickerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_1__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.PLATFORM_ID), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](ColorPickerService));
    };
    static ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: ColorPickerComponent,
      selectors: [["color-picker"]],
      viewQuery: function ColorPickerComponent_Query(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c1, 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c2, 7);
        }
        if (rf & 2) {
          let _t;
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.dialogElement = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.hueSlider = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.alphaSlider = _t.first);
        }
      },
      hostBindings: function ColorPickerComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.esc", function ColorPickerComponent_keyup_esc_HostBindingHandler($event) {
            return ctx.handleEsc($event);
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresolveDocument"])("keyup.enter", function ColorPickerComponent_keyup_enter_HostBindingHandler($event) {
            return ctx.handleEnter($event);
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresolveDocument"]);
        }
      },
      decls: 30,
      vars: 51,
      consts: [["dialogPopup", ""], ["hueSlider", ""], ["valueSlider", ""], ["alphaSlider", ""], [1, "color-picker", 3, "click"], [3, "left", "class", "top", 4, "ngIf"], ["class", "saturation-lightness", 3, "slider", "rgX", "rgY", "background-color", "newValue", "dragStart", "dragEnd", 4, "ngIf"], [1, "hue-alpha", "box"], [1, "left"], [1, "selected-color-background"], [1, "selected-color", 3, "click"], ["class", "eyedropper-icon", "xmlns", "http://www.w3.org/2000/svg", "height", "24px", "viewBox", "0 0 24 24", "width", "24px", "fill", "#000000", 4, "ngIf"], ["type", "button", 3, "class", "disabled", "click", 4, "ngIf"], [1, "right"], ["style", "height: 16px;", 4, "ngIf"], [1, "hue", 3, "newValue", "dragStart", "dragEnd", "slider", "rgX"], [1, "cursor"], [1, "value", 3, "newValue", "dragStart", "dragEnd", "slider", "rgX"], [1, "alpha", 3, "newValue", "dragStart", "dragEnd", "slider", "rgX"], ["class", "cmyk-text", 3, "display", 4, "ngIf"], ["class", "hsla-text", 3, "display", 4, "ngIf"], ["class", "rgba-text", 3, "display", 4, "ngIf"], ["class", "hex-text", 3, "hex-alpha", "display", 4, "ngIf"], ["class", "value-text", 4, "ngIf"], ["class", "type-policy", 4, "ngIf"], ["class", "preset-area", 4, "ngIf"], ["class", "button-area", 4, "ngIf"], ["class", "extra-template", 4, "ngIf"], [1, "saturation-lightness", 3, "newValue", "dragStart", "dragEnd", "slider", "rgX", "rgY"], ["xmlns", "http://www.w3.org/2000/svg", "height", "24px", "viewBox", "0 0 24 24", "width", "24px", "fill", "#000000", 1, "eyedropper-icon"], ["d", "M0 0h24v24H0V0z", "fill", "none"], ["d", "M17.66 5.41l.92.92-2.69 2.69-.92-.92 2.69-2.69M17.67 3c-.26 0-.51.1-.71.29l-3.12 3.12-1.93-1.91-1.41 1.41 1.42 1.42L3 16.25V21h4.75l8.92-8.92 1.42 1.42 1.41-1.41-1.92-1.92 3.12-3.12c.4-.4.4-1.03.01-1.42l-2.34-2.34c-.2-.19-.45-.29-.7-.29zM6.92 19L5 17.08l8.06-8.06 1.92 1.92L6.92 19z"], ["type", "button", 3, "click", "disabled"], [2, "height", "16px"], [1, "cmyk-text"], [1, "box"], ["type", "number", "pattern", "[0-9]*", "min", "0", "max", "100", 3, "keyup.enter", "newValue", "text", "rg", "value"], ["type", "number", "pattern", "[0-9]+([\\.,][0-9]{1,2})?", "min", "0", "max", "1", "step", "0.1", 3, "text", "rg", "value", "keyup.enter", "newValue", 4, "ngIf"], [4, "ngIf"], ["type", "number", "pattern", "[0-9]+([\\.,][0-9]{1,2})?", "min", "0", "max", "1", "step", "0.1", 3, "keyup.enter", "newValue", "text", "rg", "value"], [1, "hsla-text"], ["type", "number", "pattern", "[0-9]*", "min", "0", "max", "360", 3, "keyup.enter", "newValue", "text", "rg", "value"], [1, "rgba-text"], ["type", "number", "pattern", "[0-9]*", "min", "0", "max", "255", 3, "keyup.enter", "newValue", "text", "rg", "value"], [1, "hex-text"], [3, "blur", "keyup.enter", "newValue", "text", "value"], [1, "value-text"], [1, "type-policy"], [1, "type-policy-arrow", 3, "click"], [1, "preset-area"], [1, "preset-label"], [3, "class", 4, "ngIf"], ["class", "preset-color", 3, "backgroundColor", "click", 4, "ngFor", "ngForOf"], [1, "preset-color", 3, "click"], [3, "class", "click", 4, "ngIf"], [3, "click"], [1, "button-area"], ["type", "button", 3, "class", "click", 4, "ngIf"], ["type", "button", 3, "click"], [1, "extra-template"], [4, "ngTemplateOutlet"]],
      template: function ColorPickerComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 4, 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_Template_div_click_0_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"]($event.stopPropagation());
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ColorPickerComponent_div_2_Template, 1, 7, "div", 5)(3, ColorPickerComponent_div_3_Template, 2, 8, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 7)(5, "div", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "div", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerComponent_Template_div_click_7_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.eyeDropperSupported && ctx.cpEyeDropper && ctx.onEyeDropper());
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, ColorPickerComponent__svg_svg_8_Template, 3, 0, "svg", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, ColorPickerComponent_button_9_Template, 2, 5, "button", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, ColorPickerComponent_div_11_Template, 1, 0, "div", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 15, 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("newValue", function ColorPickerComponent_Template_div_newValue_12_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onHueChange($event));
          })("dragStart", function ColorPickerComponent_Template_div_dragStart_12_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onDragStart("hue"));
          })("dragEnd", function ColorPickerComponent_Template_div_dragEnd_12_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onDragEnd("hue"));
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "div", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 17, 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("newValue", function ColorPickerComponent_Template_div_newValue_15_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onValueChange($event));
          })("dragStart", function ColorPickerComponent_Template_div_dragStart_15_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onDragStart("value"));
          })("dragEnd", function ColorPickerComponent_Template_div_dragEnd_15_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onDragEnd("value"));
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "div", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 18, 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("newValue", function ColorPickerComponent_Template_div_newValue_18_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onAlphaChange($event));
          })("dragStart", function ColorPickerComponent_Template_div_dragStart_18_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onDragStart("alpha"));
          })("dragEnd", function ColorPickerComponent_Template_div_dragEnd_18_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
            return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.onDragEnd("alpha"));
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "div", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](21, ColorPickerComponent_div_21_Template, 17, 12, "div", 19)(22, ColorPickerComponent_div_22_Template, 14, 10, "div", 20)(23, ColorPickerComponent_div_23_Template, 14, 10, "div", 21)(24, ColorPickerComponent_div_24_Template, 8, 7, "div", 22)(25, ColorPickerComponent_div_25_Template, 9, 3, "div", 23)(26, ColorPickerComponent_div_26_Template, 3, 0, "div", 24)(27, ColorPickerComponent_div_27_Template, 6, 3, "div", 25)(28, ColorPickerComponent_div_28_Template, 3, 2, "div", 26)(29, ColorPickerComponent_div_29_Template, 2, 1, "div", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", !ctx.show ? "none" : "block")("visibility", ctx.hidden ? "hidden" : "visible")("top", ctx.top, "px")("left", ctx.left, "px")("position", ctx.position)("height", ctx.cpHeight, "px")("width", ctx.cpWidth, "px");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("open", ctx.show);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpDialogDisplay === "popup");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.cpColorMode || 1) === 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background-color", ctx.selectedColor)("cursor", ctx.eyeDropperSupported && ctx.cpEyeDropper ? "pointer" : null);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.eyeDropperSupported && ctx.cpEyeDropper);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpAddColorButton);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpAlphaChannel === "disabled");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", (ctx.cpColorMode || 1) === 1 ? "block" : "none");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rgX", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("left", ctx.slider == null ? null : ctx.slider.h, "px");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", (ctx.cpColorMode || 1) === 2 ? "block" : "none");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rgX", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("right", ctx.slider == null ? null : ctx.slider.v, "px");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx.cpAlphaChannel === "disabled" ? "none" : "block")("background-color", ctx.alphaSliderColor);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rgX", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("left", ctx.slider == null ? null : ctx.slider.a, "px");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cpDisableInput && (ctx.cpColorMode || 1) === 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cpDisableInput && (ctx.cpColorMode || 1) === 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cpDisableInput && (ctx.cpColorMode || 1) === 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cpDisableInput && (ctx.cpColorMode || 1) === 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cpDisableInput && (ctx.cpColorMode || 1) === 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.cpDisableInput && (ctx.cpColorMode || 1) === 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.cpPresetColors == null ? null : ctx.cpPresetColors.length) || ctx.cpAddColorButton);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpOKButton || ctx.cpCancelButton);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.cpExtraTemplate);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgTemplateOutlet, TextDirective, SliderDirective],
      styles: [".color-picker{position:absolute;z-index:1000;width:230px;height:auto;border:#777 solid 1px;cursor:default;-webkit-user-select:none;user-select:none;background-color:#fff}.color-picker *{box-sizing:border-box;margin:0;font-size:11px}.color-picker input{width:0;height:26px;min-width:0;font-size:13px;text-align:center;color:#000}.color-picker input:invalid,.color-picker input:-moz-ui-invalid,.color-picker input:-moz-submit-invalid{box-shadow:none}.color-picker input::-webkit-inner-spin-button,.color-picker input::-webkit-outer-spin-button{margin:0;-webkit-appearance:none}.color-picker .arrow{position:absolute;z-index:999999;width:0;height:0;border-style:solid}.color-picker .arrow.arrow-top{left:8px;border-width:10px 5px;border-color:#777 rgba(0,0,0,0) rgba(0,0,0,0) rgba(0,0,0,0)}.color-picker .arrow.arrow-bottom{top:-20px;left:8px;border-width:10px 5px;border-color:rgba(0,0,0,0) rgba(0,0,0,0) #777 rgba(0,0,0,0)}.color-picker .arrow.arrow-top-left,.color-picker .arrow.arrow-left-top{right:-21px;bottom:8px;border-width:5px 10px;border-color:rgba(0,0,0,0) rgba(0,0,0,0) rgba(0,0,0,0) #777}.color-picker .arrow.arrow-top-right,.color-picker .arrow.arrow-right-top{bottom:8px;left:-20px;border-width:5px 10px;border-color:rgba(0,0,0,0) #777 rgba(0,0,0,0) rgba(0,0,0,0)}.color-picker .arrow.arrow-left,.color-picker .arrow.arrow-left-bottom,.color-picker .arrow.arrow-bottom-left{top:8px;right:-21px;border-width:5px 10px;border-color:rgba(0,0,0,0) rgba(0,0,0,0) rgba(0,0,0,0) #777}.color-picker .arrow.arrow-right,.color-picker .arrow.arrow-right-bottom,.color-picker .arrow.arrow-bottom-right{top:8px;left:-20px;border-width:5px 10px;border-color:rgba(0,0,0,0) #777 rgba(0,0,0,0) rgba(0,0,0,0)}.color-picker .cursor{position:relative;width:16px;height:16px;border:#222 solid 2px;border-radius:50%;cursor:default}.color-picker .box{display:flex;padding:4px 8px}.color-picker .left{position:relative;padding:16px 8px}.color-picker .right{flex:1 1 auto;padding:12px 8px}.color-picker .button-area{padding:0 16px 16px;text-align:right}.color-picker .button-area button{margin-left:8px}.color-picker .preset-area{padding:4px 15px}.color-picker .preset-area .preset-label{overflow:hidden;width:100%;padding:4px;font-size:11px;white-space:nowrap;text-align:left;text-overflow:ellipsis;color:#555}.color-picker .preset-area .preset-color{position:relative;display:inline-block;width:18px;height:18px;margin:4px 6px 8px;border:#a9a9a9 solid 1px;border-radius:25%;cursor:pointer}.color-picker .preset-area .preset-empty-message{min-height:18px;margin-top:4px;margin-bottom:8px;font-style:italic;text-align:center}.color-picker .hex-text{width:100%;padding:4px 8px;font-size:11px}.color-picker .hex-text .box{padding:0 24px 8px 8px}.color-picker .hex-text .box div{float:left;flex:1 1 auto;text-align:center;color:#555;clear:left}.color-picker .hex-text .box input{flex:1 1 auto;padding:1px;border:#a9a9a9 solid 1px}.color-picker .hex-alpha .box div:first-child,.color-picker .hex-alpha .box input:first-child{flex-grow:3;margin-right:8px}.color-picker .cmyk-text,.color-picker .hsla-text,.color-picker .rgba-text,.color-picker .value-text{width:100%;padding:4px 8px;font-size:11px}.color-picker .cmyk-text .box,.color-picker .hsla-text .box,.color-picker .rgba-text .box{padding:0 24px 8px 8px}.color-picker .value-text .box{padding:0 8px 8px}.color-picker .cmyk-text .box div,.color-picker .hsla-text .box div,.color-picker .rgba-text .box div,.color-picker .value-text .box div{flex:1 1 auto;margin-right:8px;text-align:center;color:#555}.color-picker .cmyk-text .box div:last-child,.color-picker .hsla-text .box div:last-child,.color-picker .rgba-text .box div:last-child,.color-picker .value-text .box div:last-child{margin-right:0}.color-picker .cmyk-text .box input,.color-picker .hsla-text .box input,.color-picker .rgba-text .box input,.color-picker .value-text .box input{float:left;flex:1;padding:1px;margin:0 8px 0 0;border:#a9a9a9 solid 1px}.color-picker .cmyk-text .box input:last-child,.color-picker .hsla-text .box input:last-child,.color-picker .rgba-text .box input:last-child,.color-picker .value-text .box input:last-child{margin-right:0}.color-picker .hue-alpha{align-items:center;margin-bottom:3px}.color-picker .hue{direction:ltr;width:100%;height:16px;margin-bottom:16px;border:none;cursor:pointer;background-size:100% 100%;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAAQCAYAAAD06IYnAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AIWDwkUFWbCCAAAAFxJREFUaN7t0kEKg0AQAME2x83/n2qu5qCgD1iDhCoYdpnbQC9bbY1qVO/jvc6k3ad91s7/7F1/csgPrujuQ17BDYSFsBAWwgJhISyEBcJCWAgLhIWwEBYIi2f7Ar/1TCgFH2X9AAAAAElFTkSuQmCC)}.color-picker .value{direction:rtl;width:100%;height:16px;margin-bottom:16px;border:none;cursor:pointer;background-size:100% 100%;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAAQCAYAAAD06IYnAAACTklEQVR42u3SYUcrABhA4U2SkmRJMmWSJklKJiWZZpKUJJskKUmaTFImKZOUzMySpGRmliRNJilJSpKSJEtmSpIpmWmSdO736/6D+x7OP3gUCoWCv1cqlSQlJZGcnExKSgqpqamkpaWRnp5ORkYGmZmZqFQqsrKyyM7OJicnh9zcXNRqNXl5eeTn56PRaCgoKKCwsJCioiK0Wi3FxcWUlJRQWlpKWVkZ5eXlVFRUUFlZiU6no6qqiurqampqaqitraWurg69Xk99fT0GgwGj0UhDQwONjY00NTXR3NxMS0sLra2ttLW10d7ejslkwmw209HRQWdnJ11dXXR3d9PT00Nvby99fX309/czMDDA4OAgFouFoaEhrFYrw8PDjIyMMDo6ytjYGDabjfHxcSYmJpicnGRqagq73c709DQzMzPMzs4yNzfH/Pw8DocDp9OJy+XC7XazsLDA4uIiS0tLLC8vs7KywurqKmtra3g8HrxeLz6fD7/fz/r6OhsbG2xubrK1tcX29jaBQICdnR2CwSC7u7vs7e2xv7/PwcEBh4eHHB0dcXx8zMnJCaenp5ydnXF+fs7FxQWXl5dcXV1xfX3Nzc0Nt7e33N3dEQqFuL+/5+HhgXA4TCQS4fHxkaenJ56fn3l5eeH19ZVoNMrb2xvv7+98fHwQi8WIx+N8fn6SSCT4+vri+/ubn58ffn9/+VcKgSWwBJbAElgCS2AJLIElsASWwBJYAktgCSyBJbAElsASWAJLYAksgSWwBJbAElgCS2AJLIElsP4/WH8AmJ5Z6jHS4h8AAAAASUVORK5CYII=)}.color-picker .alpha{direction:ltr;width:100%;height:16px;border:none;cursor:pointer;background-size:100% 100%;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAAQCAYAAAD06IYnAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AIWDwYQlZMa3gAAAWVJREFUaN7tmEGO6jAQRCsOArHgBpyAJYGjcGocxAm4A2IHpmoWE0eBH+ezmFlNvU06shJ3W6VEelWMUQAIIF9f6qZpimsA1LYtS2uF51/u27YVAFZVRUkEoGHdPV/sIcbIEIIkUdI/9Xa7neyv61+SWFUVAVCSct00TWn2fv6u3+Ecfd3tXzy/0+nEUu+SPjo/kqzrmiQpScN6v98XewfA8/lMkiLJ2WxGSUopcT6fM6U0NX9/frfbjev1WtfrlZfLhYfDQQHG/AIOlnGwjINlHCxjHCzjYJm/TJWdCwquJXseFFzGwDNNeiKMOJTO8xQdDQaeB29+K9efeLaBo9J7vdvtJj1RjFFjfiv7qv95tjx/7leSQgh93e1ffMeIp6O+YQjho/N791t1XVOSSI7N//K+4/GoxWLBx+PB5/Op5XLJ+/3OlJJWqxU3m83ovv5iGf8KjYNlHCxjHCzjYBkHy5gf5gusvQU7U37jTAAAAABJRU5ErkJggg==)}.color-picker .type-policy{position:absolute;top:218px;right:12px;width:16px;height:24px;background-size:8px 16px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAgCAYAAAAffCjxAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAACewAAAnsB01CO3AAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAIASURBVEiJ7ZY9axRRFIafsxMStrLQJpAgpBFhi+C9w1YSo00I6RZ/g9vZpBf/QOr4GyRgkSKNSrAadsZqQGwCkuAWyRZJsySwvhZ7N/vhzrgbLH3Ld8597jlzz50zJokyxXH8DqDVar0qi6v8BbItqSGpEcfxdlmsFWXkvX8AfAVWg3UKPEnT9GKujMzsAFgZsVaCN1VTQd77XUnrgE1kv+6935268WRpzrnHZvYRWC7YvC3pRZZl3wozqtVqiyH9IgjAspkd1Gq1xUJQtVrdB9ZKIAOthdg/Qc65LUk7wNIMoCVJO865rYFhkqjX6/d7vV4GPJwBMqofURS5JEk6FYBer/eeYb/Mo9WwFnPOvQbeAvfuAAK4BN4sAJtAG/gJIElmNuiJyba3EGNmZiPeZuEVmVell/Y/6N+CzDn3AXhEOOo7Hv/3BeAz8IzQkMPnJbuPx1wC+yYJ7/0nYIP5S/0FHKdp+rwCEEXRS/rf5Hl1Gtb2M0iSpCOpCZzPATmX1EySpHMLAsiy7MjMDoHrGSDXZnaYZdnRwBh7J91utwmczAA6CbG3GgPleX4jqUH/a1CktqRGnuc3hSCAMB32gKspkCtgb3KCQMmkjeP4WNJThrNNZval1WptTIsv7JtQ4tmIdRa8qSoEpWl6YWZNoAN0zKxZNPehpLSBZv2t+Q0CJ9lLnARQLAAAAABJRU5ErkJggg==);background-repeat:no-repeat;background-position:center}.color-picker .type-policy .type-policy-arrow{display:block;width:100%;height:50%}.color-picker .selected-color{position:absolute;top:16px;left:8px;width:40px;height:40px;border:1px solid #a9a9a9;border-radius:50%}.color-picker .selected-color-background{width:40px;height:40px;border-radius:50%;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAh0lEQVRYR+2W0QlAMQgD60zdfwOdqa8TmI/wQMr5K0I5bZLIzLOa2nt37VVVbd+dDx5obgCC3KBLwJ2ff4PnVidkf+ucIhw80HQaCLo3DMH3CRK3iFsmAWVl6hPNDwt8EvNE5q+YuEXcMgkonVM6SdyCoEvAnZ8v1Hjx817MilmxSUB5rdLJDycZgUAZUch/AAAAAElFTkSuQmCC)}.color-picker .saturation-lightness{direction:ltr;width:100%;height:130px;border:none;cursor:pointer;touch-action:manipulation;background-size:100% 100%;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOYAAACCCAYAAABSD7T3AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AIWDwksPWR6lgAAIABJREFUeNrtnVuT47gRrAHN+P//Or/61Y5wONZ7mZ1u3XAeLMjJZGZVgdKsfc5xR3S0RIIUW+CHzCpc2McYo7XGv3ex7UiZd57rjyzzv+v+33X/R/+3r/f7vR386Y+TvKNcf/wdhTLPcv9qU2wZd74uth0t1821jkIZLPcsI/6nWa4XvutquU0Z85mnx80S/ZzgpnLnOtHNt7/ofx1TKXcSNzN/7qbMQ3ju7rNQmMYYd/4s2j9aa+P+gGaMcZrb1M/tdrvf7/d2v99P9/t93O/3cbvdxu12G9frdVwul3E+n8c///nP+2+//Xb66aefxl//+tfx5z//2YK5Al2rgvf4UsbpdGrB52bAvArXpuzjmiqAVSGz5eDmGYXzhbAZmCrnmzddpUU+8Y1dAOYeXCtDUwVwV7YCGH6uAmyMcZ9l5vkUaBPGMUZ7/J5w/792/fvv9Xq93263dr/fTxPECeME8nK5jM/Pz/HTTz/dv337dvrll1/GP/7xj/G3v/1t/OUvfwkVswongjdOp9PzH3U3D3zmWGnZVXn4jCqs7wC2BKP4/8tAzkZsoWx6XrqeHZymvp4ABCBJhTQwKfDT8gzrZCIqi5AhiACjBfEB2rP8/X63MM7f6/V6v9/v7Xa7bYC83W7jcrlsVHIq5ffv30+//fbb+OWXX8ZPP/00/v73v4+ff/75JSvbeu+bL2WMMaFbAlpBNM85QX+ct6qoSqkPAwuQlBVKqGNFSUOAA3Bmu7gC5hNOd15nSwvAOUW7C4giUCV8Sgn5L9hNFIqTsp0GxI0ysioyjAjkY/tGJVEpz+fz+OWXX+7fv38//f777+Pbt2/j119/HT///PP49ddfx8fHRwrmTjV779EXu2px2xhjwtdJZQcAWQIPLPISsMJaSwiD8gzIKrwSyATE5j5nAbR5c1dBUwBlsEWW0h6LqiYsqFPAQxCyRZ3wOSARxmlXMX5k64pQfvv27f75+dk+Pj5OHx8f4/v37+Pbt2/jt99+G9++fRsfHx/jcrmUFLO31gYDWblxRIs/TqfT7ousxJsAxXA2Gc7TA9XdgfdoHbFsj76X2+1WArgI1ageGwA3qupqoHsmcbI6Fu93quggFa9d7LeDtgKfAFHBJ+NEByIkcJ5KervdTmhhGcgJJSZ5vn//fj+fz+18Pp8+Pz/H5+fnmGD+/vvv4/v37+Pj42N8fn6O2+1Ws7JjjP6wraMI5E4RZ8x2vV5TSwkquotV7/d7Tz6HFWsD/qNcdw0CQ3q/321c686TwDVIdbuy73zNldhSHb8I2klZznm+InBS4U6n0302aBFsLhHDAKJVJVglfI9jhvu53W53sLANYNxAiDA6MCeUHx8f9+v12i6XS7tcLqcZW57P5yeY8/fz83Ocz+fnsSmYUyknWEG85WBst9stzSLyMdfr9Qi08iY15UZ0LlDGLhR3o5zK2j7OPUTD0E+nU3tk7Xb/16NFbhloAMuY1zjLUOO3BKeIDe+Z8s3/J4gFo4TM5jPmuRg28foUKKVSwo16TgA5npywcWLHgYl/Pz8/73/605/ab7/91m63W7tcLie0sZj4mao5gTyfz88E0f1+j8EcYzwTPEG2cqjyfHNF0M8fuqEiaOVnRzZZQNh5fwQyHg/HDGfJo89Q1zb/quu5XC6773I2XKfTqd/v9+d3wuqWva/YTdUdEV3fhIv/Viyps6YE3x3r43K5bJQS66zaxVGFsvd+//j4aF+/fm3fv39vt9utff36tf3+++/tdrudvn37ZuNLBaaCMgUzC+rZRiFowxUuJI8YMqcCp9Opq5vagaYU6lGJA1XQqejchw6Cj0Gw5nYBrGw01A2O206n04BGouNNyTfp/FwElhUey6nXrIKw7QQWddxuN2ldL5fL839gSPF8ahu/JvBO48CPSuqMf8Vp9/P53L58+dLu93s7n8/tfr8/39/v9/b5+TkhPJ3P56mQ436/j+/fv+/iSgbzer0+AZx/5+88bv6OMda6S5z6kd21fYC9dxv7cIJJ2d9AOS30fPMzyHiTM8B4DF6XUlYHp4KQW3W+1t77MNB1vGHxWq7Xa7vf78+y5/N5A+H1et29xuP5dbYtyaRu4AksbPq6936fjRzXRxBbPr/b+b18+fKljTHaBBBfn8/n0/1+H1++fBnn8zm0sB8fH5u4cr5GuBhMVk0EEn9RsctgVhM+ixlJtMA23R8B6yysAstBOgFXIKKCMIgToMqNEu2fYMH7ztc732dQKkCj1ytAZtY0Kx8pIr8GGJ+AT3V+2Hirhl++fBmXy2Wz73w+b17P8p+fn8/tUwGVleVkTyUb68DkfayWY4zxNRihU4EpLJPZVrK+u7J4/mgfKqeLW9X2REWlItL1diynbDDb3+jXgYjQqn0rrxWc+NkILP7F7xIbMvx7vV53x40xnlbWJF12ZSag/N0pW6t+ZzmOMzHjajKwDfond78zYTdfq18up97zr2q8v3IioBprRtBl0EZ9og5WBRGOdOHjIjXF7UotFbgOWnXzIJyzYvjG5IYgsmMOxHkz8OsMSrVNWeq5T8DaOcbEv1Od5rbs9aO7YvMet63EkF++fMExq+MRl4/L5bLZN/+ez+fnZ6KazuMqXSQVO5spJXflHAIzes/xJseckRJiDMog9d6VfRrqXMr6KpVV27jRwJacGovOAM1zMdQMnwK1AubK63kdCChvI1C7g0z9nf/D+Xze2Vj8H7Gx4P9duQlsYCrqyN8XqG3Hm/10Oj3jw/n+crlstuM+jPmmxT2dTuPz83Pzt2pn1XsEHX/bnPaVqVmh0xwOt0o6XLLAHePUU203wHfcrspCwmV3TryB5s0Mseeg97x/BwzCjBlbB+pRAPla0BVQuT6V6QHdBlj3d0KG147b+DqxQeUymDO43W4dQar+TIjwmAd0z8/h65vf0/yLv3Pb5XLpru/ydDo9s7ET0I+Pj6dKK9VUEIeKWQWPAOrJ8LKd4vE+t91Y3e7UFlWatg2VwJnb+HPmtvm/sfK59/OaWF3x/eP1UPHvA5DDYDpYXfb0drv1V2DkBkxtw/tEWVVlXWdC9pFYs5/jfh9dS/16vW7s6lTG+TfqsxSJHxkXXq/Xdr1eu4LsfD6P3vsT3N77DkL+zPm5jSdKL4zR3AxQd6rHkLkYlSowsrq7znzu6wSwdsMJOXmA5fBcjxtgMGBYHlr5zokhtsMCTgXLQOW4XC6dEyEMprL8mAQzXRgduix2yZzorxkYsDn3hB1VeMLGsXsVtgl2pW8S3svk0vw7R4hNaHvv4cACl5HFzwIH0Kc6zu4XjDPR/jpAVxWzO1Xk2DDb3vTcxeGU1iWZHkmIDWziWKvirCJ4Dravs6IJ/GG6cTqWdXDy+fArQDVVkLqkVjAoZIITdmmIqXwqa95N3+MGYoZQdRVNO53Y1xRkhO16vY7eu507Ca9lJnbGpxOemQhSw/AQsmmp5zU9BiU8G6wvX76M6/U6Pj4+do0Bz4CpgiknTUeDqwlKBmg3u4OVjrZ1A+rAcgaejWq6eJCvCYFDONSwOgHX4EQRw8lxbzDOdEK6gZ3Hk1b+8g2o1JFtKXyv/fEdTXuWjWXdAZiBp6ADeDrCFiim7B6ZFneeI7Gvm/PMkUDX67W7xI8b0D7/v8dA9qfN5oaCf74WZjH0mf1cmfY1Y0JUFmVrTWu8uzkNcLtEj7u5FXBTkfC6GOA5q8YMxO8KVvF6sAVGdcrUbsKODcQKkLMOMdmlxum642YrPm26AlhZW1YB1R+rrGswE8TaYAWeUMxdf+WjwSvZ2Ef3ytOyfn5+PpVPAaqOn43MtNBqvmjjxbjM4lZjZY4gqNMI5ktaW/sYKNwS+9lFQzGihmMCKPa7+Z0V6Eb0GRmobtpX8JljWu5FMLN5ja6hG9kwQgZqf5+1NH5UxzkFReCdWhJ8XdlGUkxO7HRlYRm4mVO43W7ter12TPJEw/rmEN3L5SKHIWZg9mz+pUoKOYq5bJTJdX2gme1UcxMZQFaEQIlHct32M+Y1BzGkGuzfiyAN9z+ugplZ1symCrDCYYkGxDTpI9RzBy0rHyeDUC1nWaeUaD9n4xkNyYMBDZtzZ3B++fJlY21XFDOcARJlabOyiS3uCpLI9jrZjCDkaVvcCCjwognKShWdzXZWlZMvVTgD8LpqlCLrqgbcB+qYwrgKYpT0ccCqbKyCValkEabn/FynogCrPKfqf51xJ7sGB2ZXcZmxoSOztjx300DZi7a0/2AIR0UlBag9SuDw6KcAzlaB7vHZvWpjK90dyrq6bKyDUZQbR0B05biLQkHIcSUmgIK+SwuqgHCnoio2RQU1yj+BnBy9pphVKLGyC7ZzFK1pxWK+E8IhVCWLN/uLtnUU4ayoYLoaANz8FdtaSvY4pV0BEW2ls61czqllBKpTyKgMAhrZ1cdc1RROtPmvWNkdcKZ7ZKxaWjiPLJMpp7OZKxA+rqG/oJLjxf0pnJlqLoDZo3gyU0mKGys2taKecj/d1C+rJSplBqlTyAqgR+D8KjKlmRL2gtUcAdCtsL+ijCNT1oqqqkH2OHEbG5sDFnUg5Aa+yLou2VU1ptj1S2ZQqv1ORZN9IWzRfgaRBxKoBE8UWyqlJFtrIc0AxNjSjed99CTY/XDfSzCz5M0IZoVEsWnPFNTsl8ooVC1TzbGgqFZNDSgVwKK+1sGDMKqxZCWGVMDysiEr1jVSQJUYwj5iHOlThdHt44SQg9CN+nl8D90NMIgAdgr46JqRiR9I8vRdFvbr17m/yxUMKjNLMiVUADwu2CWGhhi+F55TWM9M9cogzms1dnM4uOF/LAEYWdcqnM7yFmyq3IfwmOROd7Y1iFWtOjoY8To41mTV5IysgFFuRzsbWFGbNIIJCDv1dOo4lZG7jWBwRFtVTKuWyeCByJKOan8oZ3ep9XddNl0tDuaywLz9cXPYeDAA0SpkBO9sbVcTOVWldPv4uyzEkzxHtjvonHoSkFEWNoo1d8DhcQputd2ppNon4BzoAiJ1hBFQg0dVtdbGHHDQWushmNEQukLM2QO1G2Y8bgTXqFhcBJj7EjPgcPts8US8qPpPB/dXznOh5Z438tzH5ec6QgrOKrRRfKmysBmUDB+PhYabMlVPER+GCSITTzr7am2tArH3bgcEzPJm+cr5jJ4NnHNFDVrFXcI5Le9k5Jnw+bedbV+FfRzZIHaOOaOsLY0/7UGs58DjrGwKMIMFIGzOEW1/jGsdAtCN6hEAI4hBe9YXeRROBSVPAVPAqvIM5bx5hVKWAMP6zBRy3iescridVdFBinBxXDnG2GRY2XbCvp1lhvGtO9Bxu5h908XQu42lnSArMFdizMim8uwRCxPGnnOS8lwpnbOiDqTAjsrRN/PcoAScCbaACqVM40ylnjjTBs+bwWlAG23/UKbdkiwKWIQPGzWaczpoSlxPEj822cNWkpS7FyzsDrqpfgpG3jahw2vgbaSQAxuLWZYt7JzyNe8JoZpNAcvDFOdw0wqYT9AK1rZz/DdbSlLPp0ryIxgQJlK9AZlEq7IOXpohg9PIhrCng88JsOxiV4ZWAYfg4sikx/8ky2Z9l862uqwrfscIH8+ugTmVGyiddeVYUgEMn4GZzg14EwIsh9sx2cKKiWXReuOE5gzGOQgdlRKVVdlevqb279Xq0Qnsts2VDaBO0coezsruWtHApu6sKG4IBhN0aGU2kLrMKGRTN3HmbCDwKV14zvkMEDG4QfZVspVlaNU2mhc5TEZ3N1h/zqTheuLpW05ZWTGVjb3dbnNmxKZBnN8JqidaVLKAOyARNLS+MB54Z2+VaqoMLKroVBlngefnTPAcoHNWCSvlfA8CI0HEmBNBnBlXyMrzU7A7WVm94PPqQ2gmqKx+WDGsnvilmcSOBJqOK1nYyAIzuAyesq3UdSK3KfWcYKD95HmfYOU3qser2CtYEUA+FpfqdNvgPBZUBhDrGONRVlQsh8rLcaUCykHG0OOUwTlLBrsh5soEMGezi1E4HRVt1icp5wZEFXdibCkG8Y8vX75sbO4E0iom9z+hjSiOfy3DhpXItpVhE+UGQdvoWjtChmrGHf4YAzKgBNnGtuJxFCeGdhUAfQLLK8kBYAP6gvFJZajMG3Xkycy8KuC0q4Eyymwtwdxdv2M0mIBtK0LKnf640j00Auq4gUkdWGlhs22qJc6dZCsL19oxnlTJG4SYVRIGpD8TPFBuM6OElbS1pldid4mGAyN6ZIupbC5bXJN9fdpbThSxLUaI8IG1XIYBxW3Tjs6KQosKcxfxcQmdnwRGM10GnFcCy2XYunLMyAkdgk4mePiczsLygthcBut6goOqS7YVFXADLjaosB6s6ofcZWAZSIRYqSUkizYwttYab3vUOQ9w2HRxIIg8WwRVeE68xi4UtL3zRphxplzwuZrcqYCq1I3jPI5dnJIygEohMbPqVJSzrwzxBJTs5zN+ReUSgxikPQVF3JVBeNQxbHENrEMNvEdFZVV9lH9+ORGEsNZQpyTNc4C3AG7XF4ngzq+DrO2zbuaaOXgdaFcdkEotoSFBVX2qJ0C8OWZeG4KGlpghA0XfTOPCqV2qqwQ26QWfF2PMLhI2w1lVAa2aPsYd0za25MQRwgcZN6uQDCi+ZxiD4XEM2kZxOT41FnZnaRlcpZouzlRqqdbQVWopQoSB58RV50lBNrHi/AwXS5LrwDVlpY3Fc3ByiYGc52Trist6kOXdwInAQtJpp5QchyaquYOV7Su+fxVMaV3dc0RE2S6mUY0gLt2pMcYqrKIQ9w2l1gpQUMtQYcmmbt5DTNxdhnUCjQqtbK9SUSzvrC0mmhhE1e2FS2+oxypy/ZASutkmtjx3vcBC24PX65nbqkBCRhfjS9kIYPnee8cMagVOhI/3T1fAmdtAWZsCswTJCkQVNa0qWKSKPOpHAUhD9DrbVcyoYkwqhvh17vYAayXLQyKGYdxlUDFp494rBXRjYgO17DDYetNIUj/ezp6S0lnlpEwsWmJMkOwsKXeZKEAjIHn0EQJISaRBcO6UMINz7p/bEjjnw4ft+xmDvksxX4G2rIris7qaeKwAFMP2Oi7n4criuZwtpSUwpfLxSnORSrIqusc5ZFaXysqRWjiZ2DyAWEIL35tVSoQElFACjOeGGSE7AHEQgdo/LSvCOgGBvkxsmDbvlS3Fp5vhaB2TAGqRKrKKMrhLVpaGzEVjZ0OQxDhaCTA+QyRR1d15aQzrJntL3RibsipjG6jlgL4yqbS0sNYg1e84vhbBVrElK64CUcWYXDfKxhpIuxiVJZUxsbMy/uRBKTNRQ4kQ3LdRYLS0rJjRPlTPqY6gdJsEDc+aQXAn+HgsNUCbRuF0Oj0zwnA7bWDkbhO5Ens00qeQhS1laBMl5M/cAaxsLF8rKyql+Tf7ELLEGu/ixiimdCvo0TjfpjKwaggen4eh5v7LokLKbLuyvHhcZG8dhGrEDx7Hg93ZppJF7qBqO3iVveXEDQNInzeoe8Yq6ePaZBZ2JviM3W2UAGotekRCAGq4EkF1X3DOnR11yRsBL1tRa0PVcZiNFXZ2c34FskvomInQQ6lzpJoZbJxk43NwKJFBquJSsrByHydxKOnTxQASBmS3j+JMnsHSla3Ec6K9VWoJVn9zfjwOM7hqYAAqJQwE2a3nA48J2QGegRkpZNivSY+ys3EkKd4oJIwsvIHl3cWgLt5k4NH6OmtLWdpurOkwEMupYc7eMtDRhOcI2ui5JhVIzXzLyto/GAPuZoyo8wkoduVgJglCt7OhGbgID4Mq4si+63zUS1FuFFXFlqyaj2emHlLMcBqYu0FMuR28BbB7lOxRMSiCQXFhCKuwkhZ+pYDiGSgbsKKV8MiSRsuHSIWM9rklRiIlZZuqXjsQK8ooYJMgq3JKWVkhHbhsVxFUzthOWPkYijcbx54IKsSdT+uLr3crGKyoYgFiGR9iBk4kfloUX+JIlQRQqabmpgnhqtpQpb6RVQ1WH5DnrS4hEoGZqaerQ2dhFbz8XePxShmDbo70eISjoorO2vK8SJXI4SUmEU4zWKDzUDtWTYw7xXlbSTEj4FRg7zKnKoGRALv0Gs9Tgc1BpCywGZRQAtqVz2xrBcAMzEpfZwFSa2G5W0QBFjSMapWAEFa3HcGN7CxDzECyIkJ97qwrqWNTWVo876PPsjPkj2wvgroM5lLZKMETKVql/CvnWVFiFa/SzJUQwkoZsr67Y6vlSRV3/2tmNTOY3vnaxYwMuoPKqdzR1w7IqHymlPxaAThfU7Ko2ZXYj4AYJHL+kNdKwRQYESTRa5fsUZ/rVC1TMTyWVyYoqNtuzaHsMyv2tvoarxdfqwYgU1axFo/cnql1FGsqK+uAROV8BX4GU8WcZTATi2q7Qcyi0O0V+GhWBMNRUkn8H1SsWVE5By3Gi0ECqUeJoBfAtDa4amkdXG37AGP5Ggeb84p7UazpoKRzdFzeQ8HkoHGxprKy/Hpm5t12p47J6xTYDEz7uINEXSuxYXvFskYAc+ySxH9sf5ftKzU6IbwVBcUGg5e5FMCEXSErZR0wGayV19woM9guPjTqJdVTqR4uE4nJnLldWVkECCZLd2VLF+xtamex7IpiriSDUpvrpn9lrwGMCHyppMH+ps6LILsuFGUj1XEOXiqbqSHPUKnClpWV68kqtURVNDY4TNaocykoYeTU5ngGEQa/S1DnnE4AeXMcKjHPAmFVjCBENaeyLVNHfr3px8xUstJ94hIpfH4HKE/eDaArK6lSyVVFbdt1gxTIVk3pppVlFXi4pEhVBTObquohU85MLXn1iahvUkHJjSCMc01tLFveVVBx0DodM6jftCu7DOtIzYxrc0qp1JGP2ayYFz2Gb6HvMrO8cnGtV6Gjm3uImSfD2GpWK6uowbZGMxFKQCo1pOMtcMXFpRst+hXGoAomF3sSTBGgTglbBKWwsQ3tZqaYSp0Z1CimRDWFcCJUPYJ00BI5FkKYNoifuQxmN88SWVXWLMaUqqqgC0BmQJR6sk3u9NCf6jYLXxAfqsYEgVLAhRY2AtgtflZNFmFyhxdrLkAdWlk4D88M2ixHyepIdhMHrG/iR1ZGtq0MGpbDbRPYOXeSY1M6Ny4ZstvGSktK+XbFPATj2D371saPEsAMXhXrsZ0km/XStkhhMyBfsa6uXFZe2VCe+YMr1+GKgwrQyNYq1VRrB+EizAow6NsdNKcyVEkYeM73ys6q4kAHp6BiFklTkIrVC5oYV7uzwOGCz4UJ0Stq2lWMJy4wtb+RetL6tZFicnJmBw5UjCvXXMZVJX2MQkbf+XN5EWd78Vz8/JEsMZTBiKNzsm1inLRUQ74H4NidaqI68j5sAFgxcRveC7ieLJXfQYxjZZ2CsiWFewZXJmBIlZ1tdtrX4hSuateKso/RZOtOKW2nmq1oTzeK6dRWAWu2NRVb4hq0SXm1GvtugHrbr5IXqmSktg5CuDE2MSlPwsY5kNE2Wp3AqiZbWVLAxiBF+2iBZbuNj6MB6rsMLC7FyasaYDyo7KkoPyEtw3pEMXfPvxAJi2jAQQgjrz0rLIZSWZlIoNhwd5xK4AR9mYNjWAaLrnuImJeBVN9zBORObVvbr+mTTfFSEJLSRnHo7hEJoIi8MFqjxmvgmF5URZz4zLFgZZ8Ctu2X7ggVccKm9gVxIsOHqxXgNMKnFWZYnf1dBnOhayXq17QwFlWW09eNKyVJFmXqaONGA5aCegMbJ3UUkGY1ic3nKWgjq8qfVYGQG1gRt6rs62a6HiqqUOqdesK5NmX4nGofJoiE1d0dF9lVVkvT1/kEEaaCoYOwFpcVcoLM+7669PxC9rWqktH0sWUYld0VCpuBZ/stVRcGgy9WX2+U1Qthi9SzAqSxzZsy+OiFzBYnySGV6Gku44rD8BCOZBV3BvD5+AKRHNwMEsB6EzHnJpkTAeiUlEGkcECeB6GDZTp5YEJTlvdrknxYjTllMkfNtXwDjM7uVjK5JXUUn43rrqpK2jytaxHW0M5G8DC8rtHMYs7KSgduVQMGTYFqFvVS6rkD3sDJ46afdYFwoq11AOKCBLhvwoUgc8IGANycR6knZrdJPdsuxnyjfd3FovTlRMdEdtOl5CMV5EHsXQBis7TOwvIDZaGj2Vnpbh7cpK63VwYEMLwqbjzyl699sawFFkF1yqjUU31HfC6sW1ZFVFuXVXVgz9keEaw0ys1lWfm+azQAQSWA+hKYVfsZjPncAcUB9oIayy/UZXRNckDGji77GsWbvBo6tPrWPqOyVkBUq+INeqpzNdYs/u0ifh5qmpqIW+33JVSUcwY70KL4U9lYdU6ljtSls7lmfi9g3YzeQfVkaGFaV3ODCnaD2N8wsEDFklE3RzM3ZghdYkWHsszq70FIecnKkVkt8ezMzRq9bkGuKojRLBVSod3Y1yPqKgYW7JRQTPVyy5xIYLjOgxgT52RKJUY1dOrIiRd4futQx/A5AcSmEjz0vFWrkLzvbWAu9HOWbGgxFk1VNTpnBKk6TgwisI/HcxYXP1uAWO72ULFlBTq+aSu2VTUs6hrxM2CF+hEor1VIA9ZmFUaab1lSSgZsVs4sxzHlVLoJHr9H4DhONTkI1XC0/wiY2NoWAG5RlnHFnq6oLccpQddMuJ/O17JVA5OHLi0BqCztq7Y1++ucCd98qLI8MIHBV/cKjxQTme3hFBS3MyCqnDsuym2o80HjvFFTtrURmNaGJsmVahImjTsUXKtQZTAVs7Mvv8/+fzUrZAXcLJ6M4koe6XP0b6SmWWNDzyUpQ8bl+LtWx4tuqZ36cRYV3yuVxPNwvIiqiQCSmu7srgTzR6nkyhpCarXwFy1vGd5iP2cY06lFr5Njhhg1Y6+NB28ftbK83s8rf7kLJbKwDFPbLg25a0AdZJEiqr5phixKMDlRUtcssq1hriLqGoH+zeNgVm9OemjsETV8JdF0NHnkIFxWY1OB4Yrp7rtWJ7NgAAAPXklEQVQ3oNs5nplyVf8u2FoLu1JrHveaZWQjqAkshtFa2gzsSG3Zpkbvg3HafF9slPPlldjFlK80Gysm8Mr4MPhneNWENPGjAIpmilTPATdTRTXlCBYHYAQuPwA36xIpWtGN4q3Y2MhiGsUpuSSnlEJRD8PorC7CFYVw+F51qThgabxsTxWzCGY0ZSsb3lfqAy0OPNjNy8xiQQKsHYFQ2HBZVvVbBuq3m1oWKajqaonsM6uZUr6CjXWNZ0l5E3h3jURma6kP3MJIiy1Lm+kahQq41N2iZja5sjtlLYNZHZrH6qUGm4vMbDp6Rw2CFmvuyFkrBcCyMtFqBaECmsHoK9BZ2LA/lJcRqSaDqnaWbrZdGaz3DLgIvBln4woGztbyJGqslwxkhhHrTjTYFXCtOoKS8uLdofVdAbOylGU6nlYpXWZts4nXBq6WxJitMNokHUJnbnJplQm+aGpY2a5GMV2QD1hRubBPFKdumf5OHkLHz0F9luE5kjBjRa0nFE5CUGqHw32MmjZ6xkgINVnSnZ1VZStK2qKlRaLlQgK7uTq7JFXJwM+3SOEKyhZNI+tJ0I5qMYy9k2qJD7dVWdqKXa0CKNR0Ccjg+B2IYu2fcBZJZkMFgM11r0X92wilghFGgzVnexlqB7xL9mS29SiYUVY2nXOZjNBRsyDsQPRWW5hrZ4XcdC4HVWRbjgJr4sFofK5SzjQ7rhI1UebdPdEbj6sqIvTZQZ5va08rABsAW0UxeWytAk7A2KJ9ZpxzCioB24XFtYAeXYxr6anSqhLgppEqWbGwLunTgrV+IjWlL29ljaAl4EQMGsErp4apeZiquwRXLXAqOCeru32mmydc6oWTSWpFAGdzeTB8RTHVMEtlM90CbbQCYhPjq3egYr1FGdYIQjiuDGZ5zZ/AzobKGOyLxti6c4Rwtv2anyWlLICnlLhxJRXt6A5ebDBWFNONbxWZ2d02mnu4S9YECpeppV1zSWRBWxHYzVIv1CXSouwqqX3jBBBDZdYQbpTQW4ZQlS8r5kH4suSRmg2++3JN10x1PaAmEkmtYlEdeGpJEM6kOuCqCR22oSujj5IV2HdT0zj5prLKTjXFAPjdQlyq7xIBxAQP5yMczG4VxAKw0n6ilZ2QBce2pLulkuxxqnoIzFfgqyqjil9S1VNwBrFmeyeops8yOjZUybZdfS8CuaTIJumzs5tODaNtLpFDQ/PcJGweLhmeL1nB0KqiUDScsiUVD89Di3HtrKtSULw3RLiygZD+7sF8JTObgYsrGvDNUFRGl1iy0Ll1YkUc2aJYMog920I8qW6YDCg1Mqk0JHJFKXkbgbRreI+qpYNOZHrVcDUba7pjsphSJNtK6upgRNAVoOS0mugBeN4bIZgHhuPZ/s1ENaX6KsVr+YNrh1Nb7ipR0PE5zbNRegCbrHRUw6Yf07dLBJl1f8KB9as2V1nNqAsl62LBBhehwalerkHmB1JFIEZKSEusdl5JQj1nJlHXSCF342gJ9CYGrXelknJIXqVP8sD+qtplCR3XH2qfKq0ygMp+KnVkKxNlZ8m2YkIlVMiCnXUwl7qznBKSvQz3m3Pt6oQbXO5b5FixCh/fHxUQW/AEcK6zCNqKQnL9sywqmKuwvqSYzT/aPVNNpVyhvRW21aqciCsjdWvBwILUvh5VyCzbWoC1pJjJ680CWsl+udKB6T5RwG1mlohnlpbg47iz5U9ha0FGtmRLFYBtO99y97Ap0z+ZDTAog6kSLZsMHg/IFkkgp6CpvU2U0cYVSdnmkjwBdOmXbxTWNWzuIbipMioVxEckZEoahSOiy2M3K0jcC1LhVDwaqG0ZvkcWqCnrG4GIxykrqlbWdw6LQyBaZR8HmLRIhQWsHswD42ZXVLNkf9l+FlW0HVQ2lwFsC/Z1FdzlQR0KaPfo+Fdfu+/dwVRICu1CGR7AEIiAhc+AZUF0kOBaPxmUqg4i64vQnU4nFDYJ9Nz+1fVXveH9qmr+kPILx8oKcRV/BFbxbE0JMT0kSD4w6L/lNY8ocsqagVdU3A3MjxhxcGuqzsPH4irpaow1q6OyrVjvp9Npc59E91LldboYVzJWdimWfAW2SNEKcDaX2FmBLLA/uKxlmhh613Is1URQApbKfttwxL02q6Onx5pQxSbPojAg+v5hAnN6LHVRDXIsvKtRjiS0qJUyZTAXVbAK82ElFJWaQdVoqUC1Unt7BVaTQudM6SuqexjQJN4+0icaxv/utbKv83ETbT8H8gjcOKxOJmbUa6OOVXht3dFY6rHv9XoNzFLceEA1o8+pKm0LAHPHZ2rYKjFq0hfZFixsqHJgD3eD5n+U0kb1mFjXkn2lvMSSOsNE/CdIAKF0Sytq6urOHUN5gwg4GZosgbmggM5ucra2qrS2Ig1cbiBBcxYzgzUDNLCvL8GbZXNp6ORy3LmS+Kk83zRIAK6A1ioKa2I9NapIuiUFdfC9766PFZUtqUr6KbWk+zZU1a/ZrIXEztrjTOfz7hwKziCeXIaraHtbZIMz+2pGgazCmw4qWAFvEdhodYp0Xq0pV7G1YWYWbO4qhGq42+Z8BYtrLWvluNPpZAeaFFS1vubPgbgxsqcpnAaszBovKaFoDQ8BGtjfUOl4NAG2nmQV04feJgumvX2fsrQEWZghL0JnVdYkn3DOZIeRN86RqPWCmsvGVqEMRnwxQAxwS8EMYo3IzmY2+BCcLp4MKiuyuhImamlbZFcNoNl7tp+RHd18ZjQIRKyXdFRhN98/hyKqwXWNo7O1wiaXoHN108REZZWEq6grnIfjzeg8jdRf1XEL4kkXa5bBjKxoKaljBjeHlVxQ4GaycpW4lDOAKtnTxHAtOfzOtZwHAM7sqVXkV6yu6kap1nHkXKqWF/4XHqjenNKqBjpR3l1ch3Ejg1+EsgdQhsdG0B4FM9sWAVWpuAyiwTPleZxt9VyZVS2qXfReWqTAilpr9ApoWTjxymit7NwV4JTriZyOA9B0k7HFfULourmKYHVnRQvqGL5HMHdqFcR2qWpmcK6eTwx2dipWrviDilr+fKWq3OWRWdHKwA4eu8wjchbeRzFilqjjZN3ufCpfkJ0/scVpnYk6L0PI77lxdWCZ87WiWm7B/AGquQSnujGKsB8CJmiJq8q1pKIVWyqOiTK66r18BN8r74/AE71fdC3yPS2MxdOpnE1tlVxD9JmVOoggN+r4PjAXVFPa3Eg5jVJGFVUGNolH20GVrUB7BOySWq6WqYQdWR92pcFMYMwckbSgCKCqD67DiiWu1g8MQC9ByfcFqW1L+jL714qNCuznoSxt0da2gtWN1G8F0BK0NN0nuimelUF9dIdAfjO44UT3CjQLoUeLHJFTO3gmpRuIIOvwBQCbqNeo3qtZ9iF6xVK13GRlo4zqimq+CGdTiR1uRY8oqgE02hZBa79kZXPMquxRHKla2saZWN4mRqZUj0vLCKhkjKnqOQHNuSZVJoKvAqS1wpEquvWDC1B2ypwrCPsRMEPVTODMLJMDv6qeKXwi2JYV5Sq4qKyvgGsHCLiuj2jR59V8gMqSJ2FJZRXEHVRHj3sFPrct6OpqlW1GpatQdt0GvwfM6n63InsGVFhJGaBqgqqIV6IsXllZgySPq4R3bnt3wi5cv+cN2yqQLW1T95KYVsWWtKk4cB9W53WQQflQYR6Wl4HaJZjvVE0D5yvq+RKgZCs5qdBEP5sD94cAvQLlSgNaSMAtHx88BuNQ41zdFsX30zKbcs0MLD/ihkpQzl0wiTqKLTfbKmCmyYICnK0IbaieC4CG9iSyLQ7cIMGQwau6TKoq60Apl3WN40LZpca1CKKK9VQyyIEn8w0F8F6CL2h8o3ixGwC7s7EWzCOqmcApYxYD4jsAzVS0sl2t98pA7vrKophCVSonbYpgH6mvSn24pTBV4sdtV3BtMq5k82y+IADvUJ0uAlkCVTxIaPm+UNu/qkV4F1TzHXCGrXIAqItBKypqK99VtAOVs64O4ObX7pHLVCpYHcRmwvLR7TvYAKBBN58LGVzDuFz+hQbWgncQyCZAk+VbsPSouf93261iZgmfCpwRbAvqmSqriU2PwhjaoOyYqtIegVXViTsmyta6bGySpY3gyRrpIyAeaWDDxtpsXwKyalMDKNP7YBXMqEskUsi2uC8FNAPxAKTVfT1o6VzM0E0jF+1rWcUuHvdyg7vgoFplX8HpvHpMCOMRUPHzZkInsqlFKNX/EIO52E0SxSzOwob2VmRLW5D1XIU0rbgM1AzWgyC7fe8G7xUAK/taEBat7luqtyP7EmsaJQOj5F+mrnZfCuYCfBUAWwShyd6pMY/vAHG1UqOYpbI/gy5T0CMKm+UO3gFuC85dgfDVeguPDfITrIBLsLrcgdh3CFgFZjaKJ4Iv3F8ANEqvuxR1tVKOgLoCa1jxboBAkj6v7j/icFbA7f4rfRnQDLRViG13i0vqBQrYVqBbADZT0ZpiHoSzvQpopKIFS3sE1HfBWlHXd0H7LnArqvougMtljHBgZnh3Eoz/BKjLML4Z2Aq0+hEJr9jaVUBbvNzCIUiroC7AWmmFw4o5AK3MtB5VypZMSFgs05JyGVwlwBqsEGAAa2ZU1CjUexXGsE4rKriilBvFzOKKo3AuAroE6QFQU3u8YpNXwS5k+1TZt5UrwouN4KiUEw+k3ZWDp1RXHNRqXb21Ts39945yZSg3VnZFNQ9CF3XeZyr5DgBXKiwCMa2MxeTDYXgP1Fsf9QNKZc0k81RJk3r6EQ3rCmBVyLL75EjZ1pIVDHoFtiOAHoB0BdTVylqBsKKKS+AeBXJVLY+CXASuGvO/Auq7GuEjDfGKg1oKa1z/dmmi9I9SUGNhl0AtfulHAawoYrnSkmNXAVuGEhrEVXvUF+A5Ct2PqNOjDetyna4CmeUolmeXLN4Aq7C5Sj10Q7yjgl+t6CNxSRHmI5X+CpwreYB3Qfdqna4q21KdBuc4GoZsn49ZOOiVinwHqK9WzjvgeweEh2AU5+vtxZ9Cd9Wqkh49V18E5oj6vVyn0RStAyGIO5edXRKd5B0VGVXq2yr3xYp+5Ut+C4QJ4P1N339pQMjRejj4vb/Dcr6rQc3O/0rjmtZpeYCBiCHfCemRbNhbK/pNUPc3wfKy5f2D7OlL3/uPhve/oU4T0F8f+VNM2vyoiv0jK+KHQfdHq+0bncz4oz73/+Y6LbKw1o/5B7eOf1Rl/0du9B9tn/9bvrf/j+v0h6ttn2tp/r/4819y4/zv5391uvzzfwDifz6phT1MPgAAAABJRU5ErkJggg==)}.color-picker .cp-add-color-button-class{position:absolute;display:inline;padding:0;margin:3px -3px;border:0;cursor:pointer;background:transparent}.color-picker .cp-add-color-button-class:hover{text-decoration:underline}.color-picker .cp-add-color-button-class:disabled{cursor:not-allowed;color:#999}.color-picker .cp-add-color-button-class:disabled:hover{text-decoration:none}.color-picker .cp-remove-color-button-class{position:absolute;top:-5px;right:-5px;display:block;width:10px;height:10px;border-radius:50%;cursor:pointer;text-align:center;background:#fff;box-shadow:1px 1px 5px #333}.color-picker .cp-remove-color-button-class:before{content:\"x\";position:relative;bottom:3.5px;display:inline-block;font-size:10px}.color-picker .eyedropper-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);fill:#fff;mix-blend-mode:exclusion}\n"],
      encapsulation: 2
    });
  }
  return ColorPickerComponent;
})();
(() => {
  ( false) && 0;
})();

// Caretaker note: we have still left the `typeof` condition in order to avoid
// creating a breaking change for projects that still use the View Engine.
// The `ngDevMode` is always available when Ivy is enabled.
// This will be evaluated during compilation into `const NG_DEV_MODE = false`,
// thus Terser will be able to tree-shake `console.warn` calls.
const NG_DEV_MODE =  false || !!false;
let ColorPickerDirective = /*#__PURE__*/(() => {
  class ColorPickerDirective {
    injector;
    cfr;
    appRef;
    vcRef;
    elRef;
    _service;
    dialog;
    dialogCreated = false;
    ignoreChanges = false;
    cmpRef;
    viewAttachedToAppRef = false;
    colorPicker;
    cpWidth = '230px';
    cpHeight = 'auto';
    cpToggle = false;
    cpDisabled = false;
    cpIgnoredElements = [];
    cpFallbackColor = '';
    cpColorMode = 'color';
    cpCmykEnabled = false;
    cpOutputFormat = 'auto';
    cpAlphaChannel = 'enabled';
    cpDisableInput = false;
    cpDialogDisplay = 'popup';
    cpSaveClickOutside = true;
    cpCloseClickOutside = true;
    cpUseRootViewContainer = false;
    cpPosition = 'auto';
    cpPositionOffset = '0%';
    cpPositionRelativeToArrow = false;
    cpOKButton = false;
    cpOKButtonText = 'OK';
    cpOKButtonClass = 'cp-ok-button-class';
    cpCancelButton = false;
    cpCancelButtonText = 'Cancel';
    cpCancelButtonClass = 'cp-cancel-button-class';
    cpEyeDropper = false;
    cpPresetLabel = 'Preset colors';
    cpPresetColors;
    cpPresetColorsClass = 'cp-preset-colors-class';
    cpMaxPresetColorsLength = 6;
    cpPresetEmptyMessage = 'No colors added';
    cpPresetEmptyMessageClass = 'preset-empty-message';
    cpAddColorButton = false;
    cpAddColorButtonText = 'Add color';
    cpAddColorButtonClass = 'cp-add-color-button-class';
    cpRemoveColorButtonClass = 'cp-remove-color-button-class';
    cpArrowPosition = 0;
    cpExtraTemplate;
    cpInputChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    cpToggleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    cpSliderChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    cpSliderDragEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    cpSliderDragStart = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    colorPickerOpen = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    colorPickerClose = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    colorPickerCancel = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    colorPickerSelect = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    colorPickerChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(false);
    cpCmykColorChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    cpPresetColorsChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter(true);
    handleClick() {
      this.inputFocus();
    }
    handleFocus() {
      this.inputFocus();
    }
    handleInput(event) {
      this.inputChange(event);
    }
    constructor(injector, cfr, appRef, vcRef, elRef, _service) {
      this.injector = injector;
      this.cfr = cfr;
      this.appRef = appRef;
      this.vcRef = vcRef;
      this.elRef = elRef;
      this._service = _service;
    }
    ngOnDestroy() {
      if (this.cmpRef != null) {
        if (this.viewAttachedToAppRef) {
          this.appRef.detachView(this.cmpRef.hostView);
        }
        this.cmpRef.destroy();
        this.cmpRef = null;
        this.dialog = null;
      }
    }
    ngOnChanges(changes) {
      if (changes.cpToggle && !this.cpDisabled) {
        if (changes.cpToggle.currentValue) {
          this.openDialog();
        } else if (!changes.cpToggle.currentValue) {
          this.closeDialog();
        }
      }
      if (changes.colorPicker) {
        if (this.dialog && !this.ignoreChanges) {
          if (this.cpDialogDisplay === 'inline') {
            this.dialog.setInitialColor(changes.colorPicker.currentValue);
          }
          this.dialog.setColorFromString(changes.colorPicker.currentValue, false);
          if (this.cpUseRootViewContainer && this.cpDialogDisplay !== 'inline') {
            this.cmpRef.changeDetectorRef.detectChanges();
          }
        }
        this.ignoreChanges = false;
      }
      if (changes.cpPresetLabel || changes.cpPresetColors) {
        if (this.dialog) {
          this.dialog.setPresetConfig(this.cpPresetLabel, this.cpPresetColors);
        }
      }
    }
    openDialog() {
      if (!this.dialogCreated) {
        let vcRef = this.vcRef;
        this.dialogCreated = true;
        this.viewAttachedToAppRef = false;
        if (this.cpUseRootViewContainer && this.cpDialogDisplay !== 'inline') {
          const classOfRootComponent = this.appRef.componentTypes[0];
          const appInstance = this.injector.get(classOfRootComponent, _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injector.NULL);
          if (appInstance !== _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injector.NULL) {
            vcRef = appInstance.vcRef || appInstance.viewContainerRef || this.vcRef;
            if (NG_DEV_MODE && vcRef === this.vcRef) {
              console.warn('You are using cpUseRootViewContainer, ' + 'but the root component is not exposing viewContainerRef!' + 'Please expose it by adding \'public vcRef: ViewContainerRef\' to the constructor.');
            }
          } else {
            this.viewAttachedToAppRef = true;
          }
        }
        const compFactory = this.cfr.resolveComponentFactory(ColorPickerComponent);
        if (this.viewAttachedToAppRef) {
          this.cmpRef = compFactory.create(this.injector);
          this.appRef.attachView(this.cmpRef.hostView);
          document.body.appendChild(this.cmpRef.hostView.rootNodes[0]);
        } else {
          const injector = _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injector.create({
            providers: [],
            // We shouldn't use `vcRef.parentInjector` since it's been deprecated long time ago and might be removed
            // in newer Angular versions: https://github.com/angular/angular/pull/25174.
            parent: vcRef.injector
          });
          this.cmpRef = vcRef.createComponent(compFactory, 0, injector, []);
        }
        this.cmpRef.instance.setupDialog(this, this.elRef, this.colorPicker, this.cpWidth, this.cpHeight, this.cpDialogDisplay, this.cpFallbackColor, this.cpColorMode, this.cpCmykEnabled, this.cpAlphaChannel, this.cpOutputFormat, this.cpDisableInput, this.cpIgnoredElements, this.cpSaveClickOutside, this.cpCloseClickOutside, this.cpUseRootViewContainer, this.cpPosition, this.cpPositionOffset, this.cpPositionRelativeToArrow, this.cpPresetLabel, this.cpPresetColors, this.cpPresetColorsClass, this.cpMaxPresetColorsLength, this.cpPresetEmptyMessage, this.cpPresetEmptyMessageClass, this.cpOKButton, this.cpOKButtonClass, this.cpOKButtonText, this.cpCancelButton, this.cpCancelButtonClass, this.cpCancelButtonText, this.cpAddColorButton, this.cpAddColorButtonClass, this.cpAddColorButtonText, this.cpRemoveColorButtonClass, this.cpEyeDropper, this.elRef, this.cpExtraTemplate);
        this.dialog = this.cmpRef.instance;
        if (this.vcRef !== vcRef) {
          this.cmpRef.changeDetectorRef.detectChanges();
        }
      } else if (this.dialog) {
        this.dialog.openDialog(this.colorPicker);
      }
    }
    closeDialog() {
      if (this.dialog && this.cpDialogDisplay === 'popup') {
        this.dialog.closeDialog();
      }
    }
    cmykChanged(value) {
      this.cpCmykColorChange.emit(value);
    }
    stateChanged(state) {
      this.cpToggleChange.emit(state);
      if (state) {
        this.colorPickerOpen.emit(this.colorPicker);
      } else {
        this.colorPickerClose.emit(this.colorPicker);
      }
    }
    colorChanged(value, ignore = true) {
      this.ignoreChanges = ignore;
      this.colorPickerChange.emit(value);
    }
    colorSelected(value) {
      this.colorPickerSelect.emit(value);
    }
    colorCanceled() {
      this.colorPickerCancel.emit();
    }
    inputFocus() {
      const element = this.elRef.nativeElement;
      const ignored = this.cpIgnoredElements.filter(item => item === element);
      if (!this.cpDisabled && !ignored.length) {
        if (typeof document !== 'undefined' && element === document.activeElement) {
          this.openDialog();
        } else if (!this.dialog || !this.dialog.show) {
          this.openDialog();
        } else {
          this.closeDialog();
        }
      }
    }
    inputChange(event) {
      if (this.dialog) {
        this.dialog.setColorFromString(event.target.value, true);
      } else {
        this.colorPicker = event.target.value;
        this.colorPickerChange.emit(this.colorPicker);
      }
    }
    inputChanged(event) {
      this.cpInputChange.emit(event);
    }
    sliderChanged(event) {
      this.cpSliderChange.emit(event);
    }
    sliderDragEnd(event) {
      this.cpSliderDragEnd.emit(event);
    }
    sliderDragStart(event) {
      this.cpSliderDragStart.emit(event);
    }
    presetColorsChanged(value) {
      this.cpPresetColorsChange.emit(value);
    }
    static ɵfac = function ColorPickerDirective_Factory(t) {
      return new (t || ColorPickerDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Injector), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ComponentFactoryResolver), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ApplicationRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewContainerRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](ColorPickerService));
    };
    static ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
      type: ColorPickerDirective,
      selectors: [["", "colorPicker", ""]],
      hostBindings: function ColorPickerDirective_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ColorPickerDirective_click_HostBindingHandler() {
            return ctx.handleClick();
          })("focus", function ColorPickerDirective_focus_HostBindingHandler() {
            return ctx.handleFocus();
          })("input", function ColorPickerDirective_input_HostBindingHandler($event) {
            return ctx.handleInput($event);
          });
        }
      },
      inputs: {
        colorPicker: "colorPicker",
        cpWidth: "cpWidth",
        cpHeight: "cpHeight",
        cpToggle: "cpToggle",
        cpDisabled: "cpDisabled",
        cpIgnoredElements: "cpIgnoredElements",
        cpFallbackColor: "cpFallbackColor",
        cpColorMode: "cpColorMode",
        cpCmykEnabled: "cpCmykEnabled",
        cpOutputFormat: "cpOutputFormat",
        cpAlphaChannel: "cpAlphaChannel",
        cpDisableInput: "cpDisableInput",
        cpDialogDisplay: "cpDialogDisplay",
        cpSaveClickOutside: "cpSaveClickOutside",
        cpCloseClickOutside: "cpCloseClickOutside",
        cpUseRootViewContainer: "cpUseRootViewContainer",
        cpPosition: "cpPosition",
        cpPositionOffset: "cpPositionOffset",
        cpPositionRelativeToArrow: "cpPositionRelativeToArrow",
        cpOKButton: "cpOKButton",
        cpOKButtonText: "cpOKButtonText",
        cpOKButtonClass: "cpOKButtonClass",
        cpCancelButton: "cpCancelButton",
        cpCancelButtonText: "cpCancelButtonText",
        cpCancelButtonClass: "cpCancelButtonClass",
        cpEyeDropper: "cpEyeDropper",
        cpPresetLabel: "cpPresetLabel",
        cpPresetColors: "cpPresetColors",
        cpPresetColorsClass: "cpPresetColorsClass",
        cpMaxPresetColorsLength: "cpMaxPresetColorsLength",
        cpPresetEmptyMessage: "cpPresetEmptyMessage",
        cpPresetEmptyMessageClass: "cpPresetEmptyMessageClass",
        cpAddColorButton: "cpAddColorButton",
        cpAddColorButtonText: "cpAddColorButtonText",
        cpAddColorButtonClass: "cpAddColorButtonClass",
        cpRemoveColorButtonClass: "cpRemoveColorButtonClass",
        cpArrowPosition: "cpArrowPosition",
        cpExtraTemplate: "cpExtraTemplate"
      },
      outputs: {
        cpInputChange: "cpInputChange",
        cpToggleChange: "cpToggleChange",
        cpSliderChange: "cpSliderChange",
        cpSliderDragEnd: "cpSliderDragEnd",
        cpSliderDragStart: "cpSliderDragStart",
        colorPickerOpen: "colorPickerOpen",
        colorPickerClose: "colorPickerClose",
        colorPickerCancel: "colorPickerCancel",
        colorPickerSelect: "colorPickerSelect",
        colorPickerChange: "colorPickerChange",
        cpCmykColorChange: "cpCmykColorChange",
        cpPresetColorsChange: "cpPresetColorsChange"
      },
      exportAs: ["ngxColorPicker"],
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]]
    });
  }
  return ColorPickerDirective;
})();
(() => {
  ( false) && 0;
})();
let ColorPickerModule = /*#__PURE__*/(() => {
  class ColorPickerModule {
    static ɵfac = function ColorPickerModule_Factory(t) {
      return new (t || ColorPickerModule)();
    };
    static ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: ColorPickerModule
    });
    static ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      providers: [ColorPickerService],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]
    });
  }
  return ColorPickerModule;
})();
(() => {
  ( false) && 0;
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=ngx-color-picker.mjs.map

/***/ }),

/***/ 1873:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ DomHandler),
/* harmony export */   b: () => (/* binding */ ConnectedOverlayScrollHandler)
/* harmony export */ });
/**
 * @dynamic is for runtime initializing DomHandler.browser
 *
 * If delete below comment, we can see this error message:
 *  Metadata collected contains an error that will be reported at runtime:
 *  Only initialized variables and constants can be referenced
 *  because the value of this variable is needed by the template compiler.
 */
// @dynamic
let DomHandler = /*#__PURE__*/(() => {
  class DomHandler {
    static zindex = 1000;
    static calculatedScrollbarWidth = null;
    static calculatedScrollbarHeight = null;
    static browser;
    static addClass(element, className) {
      if (element && className) {
        if (element.classList) element.classList.add(className);else element.className += ' ' + className;
      }
    }
    static addMultipleClasses(element, className) {
      if (element && className) {
        if (element.classList) {
          let styles = className.trim().split(' ');
          for (let i = 0; i < styles.length; i++) {
            element.classList.add(styles[i]);
          }
        } else {
          let styles = className.split(' ');
          for (let i = 0; i < styles.length; i++) {
            element.className += ' ' + styles[i];
          }
        }
      }
    }
    static removeClass(element, className) {
      if (element && className) {
        if (element.classList) element.classList.remove(className);else element.className = element.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
      }
    }
    static removeMultipleClasses(element, classNames) {
      if (element && classNames) {
        [classNames].flat().filter(Boolean).forEach(cNames => cNames.split(' ').forEach(className => this.removeClass(element, className)));
      }
    }
    static hasClass(element, className) {
      if (element && className) {
        if (element.classList) return element.classList.contains(className);else return new RegExp('(^| )' + className + '( |$)', 'gi').test(element.className);
      }
      return false;
    }
    static siblings(element) {
      return Array.prototype.filter.call(element.parentNode.children, function (child) {
        return child !== element;
      });
    }
    static find(element, selector) {
      return Array.from(element.querySelectorAll(selector));
    }
    static findSingle(element, selector) {
      return this.isElement(element) ? element.querySelector(selector) : null;
    }
    static index(element) {
      let children = element.parentNode.childNodes;
      let num = 0;
      for (var i = 0; i < children.length; i++) {
        if (children[i] == element) return num;
        if (children[i].nodeType == 1) num++;
      }
      return -1;
    }
    static indexWithinGroup(element, attributeName) {
      let children = element.parentNode ? element.parentNode.childNodes : [];
      let num = 0;
      for (var i = 0; i < children.length; i++) {
        if (children[i] == element) return num;
        if (children[i].attributes && children[i].attributes[attributeName] && children[i].nodeType == 1) num++;
      }
      return -1;
    }
    static appendOverlay(overlay, target, appendTo = 'self') {
      if (appendTo !== 'self' && overlay && target) {
        this.appendChild(overlay, target);
      }
    }
    static alignOverlay(overlay, target, appendTo = 'self', calculateMinWidth = true) {
      if (overlay && target) {
        if (calculateMinWidth) {
          overlay.style.minWidth = `${DomHandler.getOuterWidth(target)}px`;
        }
        if (appendTo === 'self') {
          this.relativePosition(overlay, target);
        } else {
          this.absolutePosition(overlay, target);
        }
      }
    }
    static relativePosition(element, target, gutter = true) {
      const getClosestRelativeElement = el => {
        if (!el) return;
        return getComputedStyle(el).getPropertyValue('position') === 'relative' ? el : getClosestRelativeElement(el.parentElement);
      };
      const elementDimensions = element.offsetParent ? {
        width: element.offsetWidth,
        height: element.offsetHeight
      } : this.getHiddenElementDimensions(element);
      const targetHeight = target.offsetHeight ?? target.getBoundingClientRect().height;
      const targetOffset = target.getBoundingClientRect();
      const windowScrollTop = this.getWindowScrollTop();
      const windowScrollLeft = this.getWindowScrollLeft();
      const viewport = this.getViewport();
      const relativeElement = getClosestRelativeElement(element);
      const relativeElementOffset = relativeElement?.getBoundingClientRect() || {
        top: -1 * windowScrollTop,
        left: -1 * windowScrollLeft
      };
      let top, left;
      if (targetOffset.top + targetHeight + elementDimensions.height > viewport.height) {
        top = targetOffset.top - relativeElementOffset.top - elementDimensions.height;
        element.style.transformOrigin = 'bottom';
        if (targetOffset.top + top < 0) {
          top = -1 * targetOffset.top;
        }
      } else {
        top = targetHeight + targetOffset.top - relativeElementOffset.top;
        element.style.transformOrigin = 'top';
      }
      const horizontalOverflow = targetOffset.left + elementDimensions.width - viewport.width;
      const targetLeftOffsetInSpaceOfRelativeElement = targetOffset.left - relativeElementOffset.left;
      if (elementDimensions.width > viewport.width) {
        // element wider then viewport and cannot fit on screen (align at left side of viewport)
        left = (targetOffset.left - relativeElementOffset.left) * -1;
      } else if (horizontalOverflow > 0) {
        // element wider then viewport but can be fit on screen (align at right side of viewport)
        left = targetLeftOffsetInSpaceOfRelativeElement - horizontalOverflow;
      } else {
        // element fits on screen (align with target)
        left = targetOffset.left - relativeElementOffset.left;
      }
      element.style.top = top + 'px';
      element.style.left = left + 'px';
      gutter && (element.style.marginTop = origin === 'bottom' ? 'calc(var(--p-anchor-gutter) * -1)' : 'calc(var(--p-anchor-gutter))');
    }
    static absolutePosition(element, target, gutter = true) {
      const elementDimensions = element.offsetParent ? {
        width: element.offsetWidth,
        height: element.offsetHeight
      } : this.getHiddenElementDimensions(element);
      const elementOuterHeight = elementDimensions.height;
      const elementOuterWidth = elementDimensions.width;
      const targetOuterHeight = target.offsetHeight ?? target.getBoundingClientRect().height;
      const targetOuterWidth = target.offsetWidth ?? target.getBoundingClientRect().width;
      const targetOffset = target.getBoundingClientRect();
      const windowScrollTop = this.getWindowScrollTop();
      const windowScrollLeft = this.getWindowScrollLeft();
      const viewport = this.getViewport();
      let top, left;
      if (targetOffset.top + targetOuterHeight + elementOuterHeight > viewport.height) {
        top = targetOffset.top + windowScrollTop - elementOuterHeight;
        element.style.transformOrigin = 'bottom';
        if (top < 0) {
          top = windowScrollTop;
        }
      } else {
        top = targetOuterHeight + targetOffset.top + windowScrollTop;
        element.style.transformOrigin = 'top';
      }
      if (targetOffset.left + elementOuterWidth > viewport.width) left = Math.max(0, targetOffset.left + windowScrollLeft + targetOuterWidth - elementOuterWidth);else left = targetOffset.left + windowScrollLeft;
      element.style.top = top + 'px';
      element.style.left = left + 'px';
      gutter && (element.style.marginTop = origin === 'bottom' ? 'calc(var(--p-anchor-gutter) * -1)' : 'calc(var(--p-anchor-gutter))');
    }
    static getParents(element, parents = []) {
      return element['parentNode'] === null ? parents : this.getParents(element.parentNode, parents.concat([element.parentNode]));
    }
    static getScrollableParents(element) {
      let scrollableParents = [];
      if (element) {
        let parents = this.getParents(element);
        const overflowRegex = /(auto|scroll)/;
        const overflowCheck = node => {
          let styleDeclaration = window['getComputedStyle'](node, null);
          return overflowRegex.test(styleDeclaration.getPropertyValue('overflow')) || overflowRegex.test(styleDeclaration.getPropertyValue('overflowX')) || overflowRegex.test(styleDeclaration.getPropertyValue('overflowY'));
        };
        for (let parent of parents) {
          let scrollSelectors = parent.nodeType === 1 && parent.dataset['scrollselectors'];
          if (scrollSelectors) {
            let selectors = scrollSelectors.split(',');
            for (let selector of selectors) {
              let el = this.findSingle(parent, selector);
              if (el && overflowCheck(el)) {
                scrollableParents.push(el);
              }
            }
          }
          if (parent.nodeType !== 9 && overflowCheck(parent)) {
            scrollableParents.push(parent);
          }
        }
      }
      return scrollableParents;
    }
    static getHiddenElementOuterHeight(element) {
      element.style.visibility = 'hidden';
      element.style.display = 'block';
      let elementHeight = element.offsetHeight;
      element.style.display = 'none';
      element.style.visibility = 'visible';
      return elementHeight;
    }
    static getHiddenElementOuterWidth(element) {
      element.style.visibility = 'hidden';
      element.style.display = 'block';
      let elementWidth = element.offsetWidth;
      element.style.display = 'none';
      element.style.visibility = 'visible';
      return elementWidth;
    }
    static getHiddenElementDimensions(element) {
      let dimensions = {};
      element.style.visibility = 'hidden';
      element.style.display = 'block';
      dimensions.width = element.offsetWidth;
      dimensions.height = element.offsetHeight;
      element.style.display = 'none';
      element.style.visibility = 'visible';
      return dimensions;
    }
    static scrollInView(container, item) {
      let borderTopValue = getComputedStyle(container).getPropertyValue('borderTopWidth');
      let borderTop = borderTopValue ? parseFloat(borderTopValue) : 0;
      let paddingTopValue = getComputedStyle(container).getPropertyValue('paddingTop');
      let paddingTop = paddingTopValue ? parseFloat(paddingTopValue) : 0;
      let containerRect = container.getBoundingClientRect();
      let itemRect = item.getBoundingClientRect();
      let offset = itemRect.top + document.body.scrollTop - (containerRect.top + document.body.scrollTop) - borderTop - paddingTop;
      let scroll = container.scrollTop;
      let elementHeight = container.clientHeight;
      let itemHeight = this.getOuterHeight(item);
      if (offset < 0) {
        container.scrollTop = scroll + offset;
      } else if (offset + itemHeight > elementHeight) {
        container.scrollTop = scroll + offset - elementHeight + itemHeight;
      }
    }
    static fadeIn(element, duration) {
      element.style.opacity = 0;
      let last = +new Date();
      let opacity = 0;
      let tick = function () {
        opacity = +element.style.opacity.replace(',', '.') + (new Date().getTime() - last) / duration;
        element.style.opacity = opacity;
        last = +new Date();
        if (+opacity < 1) {
          window.requestAnimationFrame && requestAnimationFrame(tick) || setTimeout(tick, 16);
        }
      };
      tick();
    }
    static fadeOut(element, ms) {
      var opacity = 1,
        interval = 50,
        duration = ms,
        gap = interval / duration;
      let fading = setInterval(() => {
        opacity = opacity - gap;
        if (opacity <= 0) {
          opacity = 0;
          clearInterval(fading);
        }
        element.style.opacity = opacity;
      }, interval);
    }
    static getWindowScrollTop() {
      let doc = document.documentElement;
      return (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    }
    static getWindowScrollLeft() {
      let doc = document.documentElement;
      return (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
    }
    static matches(element, selector) {
      var p = Element.prototype;
      var f = p['matches'] || p.webkitMatchesSelector || p['mozMatchesSelector'] || p['msMatchesSelector'] || function (s) {
        return [].indexOf.call(document.querySelectorAll(s), this) !== -1;
      };
      return f.call(element, selector);
    }
    static getOuterWidth(el, margin) {
      let width = el.offsetWidth;
      if (margin) {
        let style = getComputedStyle(el);
        width += parseFloat(style.marginLeft) + parseFloat(style.marginRight);
      }
      return width;
    }
    static getHorizontalPadding(el) {
      let style = getComputedStyle(el);
      return parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
    }
    static getHorizontalMargin(el) {
      let style = getComputedStyle(el);
      return parseFloat(style.marginLeft) + parseFloat(style.marginRight);
    }
    static innerWidth(el) {
      let width = el.offsetWidth;
      let style = getComputedStyle(el);
      width += parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
      return width;
    }
    static width(el) {
      let width = el.offsetWidth;
      let style = getComputedStyle(el);
      width -= parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
      return width;
    }
    static getInnerHeight(el) {
      let height = el.offsetHeight;
      let style = getComputedStyle(el);
      height += parseFloat(style.paddingTop) + parseFloat(style.paddingBottom);
      return height;
    }
    static getOuterHeight(el, margin) {
      let height = el.offsetHeight;
      if (margin) {
        let style = getComputedStyle(el);
        height += parseFloat(style.marginTop) + parseFloat(style.marginBottom);
      }
      return height;
    }
    static getHeight(el) {
      let height = el.offsetHeight;
      let style = getComputedStyle(el);
      height -= parseFloat(style.paddingTop) + parseFloat(style.paddingBottom) + parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
      return height;
    }
    static getWidth(el) {
      let width = el.offsetWidth;
      let style = getComputedStyle(el);
      width -= parseFloat(style.paddingLeft) + parseFloat(style.paddingRight) + parseFloat(style.borderLeftWidth) + parseFloat(style.borderRightWidth);
      return width;
    }
    static getViewport() {
      let win = window,
        d = document,
        e = d.documentElement,
        g = d.getElementsByTagName('body')[0],
        w = win.innerWidth || e.clientWidth || g.clientWidth,
        h = win.innerHeight || e.clientHeight || g.clientHeight;
      return {
        width: w,
        height: h
      };
    }
    static getOffset(el) {
      var rect = el.getBoundingClientRect();
      return {
        top: rect.top + (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0),
        left: rect.left + (window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0)
      };
    }
    static replaceElementWith(element, replacementElement) {
      let parentNode = element.parentNode;
      if (!parentNode) throw `Can't replace element`;
      return parentNode.replaceChild(replacementElement, element);
    }
    static getUserAgent() {
      if (navigator && this.isClient()) {
        return navigator.userAgent;
      }
    }
    static isIE() {
      var ua = window.navigator.userAgent;
      var msie = ua.indexOf('MSIE ');
      if (msie > 0) {
        // IE 10 or older => return version number
        return true;
      }
      var trident = ua.indexOf('Trident/');
      if (trident > 0) {
        // IE 11 => return version number
        var rv = ua.indexOf('rv:');
        return true;
      }
      var edge = ua.indexOf('Edge/');
      if (edge > 0) {
        // Edge (IE 12+) => return version number
        return true;
      }
      // other browser
      return false;
    }
    static isIOS() {
      return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window['MSStream'];
    }
    static isAndroid() {
      return /(android)/i.test(navigator.userAgent);
    }
    static isTouchDevice() {
      return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    }
    static appendChild(element, target) {
      if (this.isElement(target)) target.appendChild(element);else if (target && target.el && target.el.nativeElement) target.el.nativeElement.appendChild(element);else throw 'Cannot append ' + target + ' to ' + element;
    }
    static removeChild(element, target) {
      if (this.isElement(target)) target.removeChild(element);else if (target.el && target.el.nativeElement) target.el.nativeElement.removeChild(element);else throw 'Cannot remove ' + element + ' from ' + target;
    }
    static removeElement(element) {
      if (!('remove' in Element.prototype)) element.parentNode.removeChild(element);else element.remove();
    }
    static isElement(obj) {
      return typeof HTMLElement === 'object' ? obj instanceof HTMLElement : obj && typeof obj === 'object' && obj !== null && obj.nodeType === 1 && typeof obj.nodeName === 'string';
    }
    static calculateScrollbarWidth(el) {
      if (el) {
        let style = getComputedStyle(el);
        return el.offsetWidth - el.clientWidth - parseFloat(style.borderLeftWidth) - parseFloat(style.borderRightWidth);
      } else {
        if (this.calculatedScrollbarWidth !== null) return this.calculatedScrollbarWidth;
        let scrollDiv = document.createElement('div');
        scrollDiv.className = 'p-scrollbar-measure';
        document.body.appendChild(scrollDiv);
        let scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
        document.body.removeChild(scrollDiv);
        this.calculatedScrollbarWidth = scrollbarWidth;
        return scrollbarWidth;
      }
    }
    static calculateScrollbarHeight() {
      if (this.calculatedScrollbarHeight !== null) return this.calculatedScrollbarHeight;
      let scrollDiv = document.createElement('div');
      scrollDiv.className = 'p-scrollbar-measure';
      document.body.appendChild(scrollDiv);
      let scrollbarHeight = scrollDiv.offsetHeight - scrollDiv.clientHeight;
      document.body.removeChild(scrollDiv);
      this.calculatedScrollbarWidth = scrollbarHeight;
      return scrollbarHeight;
    }
    static invokeElementMethod(element, methodName, args) {
      element[methodName].apply(element, args);
    }
    static clearSelection() {
      if (window.getSelection) {
        if (window.getSelection().empty) {
          window.getSelection().empty();
        } else if (window.getSelection().removeAllRanges && window.getSelection().rangeCount > 0 && window.getSelection().getRangeAt(0).getClientRects().length > 0) {
          window.getSelection().removeAllRanges();
        }
      } else if (document['selection'] && document['selection'].empty) {
        try {
          document['selection'].empty();
        } catch (error) {
          //ignore IE bug
        }
      }
    }
    static getBrowser() {
      if (!this.browser) {
        let matched = this.resolveUserAgent();
        this.browser = {};
        if (matched.browser) {
          this.browser[matched.browser] = true;
          this.browser['version'] = matched.version;
        }
        if (this.browser['chrome']) {
          this.browser['webkit'] = true;
        } else if (this.browser['webkit']) {
          this.browser['safari'] = true;
        }
      }
      return this.browser;
    }
    static resolveUserAgent() {
      let ua = navigator.userAgent.toLowerCase();
      let match = /(chrome)[ \/]([\w.]+)/.exec(ua) || /(webkit)[ \/]([\w.]+)/.exec(ua) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) || /(msie) ([\w.]+)/.exec(ua) || ua.indexOf('compatible') < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) || [];
      return {
        browser: match[1] || '',
        version: match[2] || '0'
      };
    }
    static isInteger(value) {
      if (Number.isInteger) {
        return Number.isInteger(value);
      } else {
        return typeof value === 'number' && isFinite(value) && Math.floor(value) === value;
      }
    }
    static isHidden(element) {
      return !element || element.offsetParent === null;
    }
    static isVisible(element) {
      return element && element.offsetParent != null;
    }
    static isExist(element) {
      return element !== null && typeof element !== 'undefined' && element.nodeName && element.parentNode;
    }
    static focus(element, options) {
      element && document.activeElement !== element && element.focus(options);
    }
    static getFocusableSelectorString(selector = '') {
      return `button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        [href][clientHeight][clientWidth]:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        .p-inputtext:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
        .p-button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector}`;
    }
    static getFocusableElements(element, selector = '') {
      let focusableElements = this.find(element, this.getFocusableSelectorString(selector));
      let visibleFocusableElements = [];
      for (let focusableElement of focusableElements) {
        const computedStyle = getComputedStyle(focusableElement);
        if (this.isVisible(focusableElement) && computedStyle.display != 'none' && computedStyle.visibility != 'hidden') visibleFocusableElements.push(focusableElement);
      }
      return visibleFocusableElements;
    }
    static getFocusableElement(element, selector = '') {
      let focusableElement = this.findSingle(element, this.getFocusableSelectorString(selector));
      if (focusableElement) {
        const computedStyle = getComputedStyle(focusableElement);
        if (this.isVisible(focusableElement) && computedStyle.display != 'none' && computedStyle.visibility != 'hidden') return focusableElement;
      }
      return null;
    }
    static getFirstFocusableElement(element, selector = '') {
      const focusableElements = this.getFocusableElements(element, selector);
      return focusableElements.length > 0 ? focusableElements[0] : null;
    }
    static getLastFocusableElement(element, selector) {
      const focusableElements = this.getFocusableElements(element, selector);
      return focusableElements.length > 0 ? focusableElements[focusableElements.length - 1] : null;
    }
    static getNextFocusableElement(element, reverse = false) {
      const focusableElements = DomHandler.getFocusableElements(element);
      let index = 0;
      if (focusableElements && focusableElements.length > 0) {
        const focusedIndex = focusableElements.indexOf(focusableElements[0].ownerDocument.activeElement);
        if (reverse) {
          if (focusedIndex == -1 || focusedIndex === 0) {
            index = focusableElements.length - 1;
          } else {
            index = focusedIndex - 1;
          }
        } else if (focusedIndex != -1 && focusedIndex !== focusableElements.length - 1) {
          index = focusedIndex + 1;
        }
      }
      return focusableElements[index];
    }
    static generateZIndex() {
      this.zindex = this.zindex || 999;
      return ++this.zindex;
    }
    static getSelection() {
      if (window.getSelection) return window.getSelection().toString();else if (document.getSelection) return document.getSelection().toString();else if (document['selection']) return document['selection'].createRange().text;
      return null;
    }
    static getTargetElement(target, el) {
      if (!target) return null;
      switch (target) {
        case 'document':
          return document;
        case 'window':
          return window;
        case '@next':
          return el?.nextElementSibling;
        case '@prev':
          return el?.previousElementSibling;
        case '@parent':
          return el?.parentElement;
        case '@grandparent':
          return el?.parentElement.parentElement;
        default:
          const type = typeof target;
          if (type === 'string') {
            return document.querySelector(target);
          } else if (type === 'object' && target.hasOwnProperty('nativeElement')) {
            return this.isExist(target.nativeElement) ? target.nativeElement : undefined;
          }
          const isFunction = obj => !!(obj && obj.constructor && obj.call && obj.apply);
          const element = isFunction(target) ? target() : target;
          return element && element.nodeType === 9 || this.isExist(element) ? element : null;
      }
    }
    static isClient() {
      return !!(typeof window !== 'undefined' && window.document && window.document.createElement);
    }
    static getAttribute(element, name) {
      if (element) {
        const value = element.getAttribute(name);
        if (!isNaN(value)) {
          return +value;
        }
        if (value === 'true' || value === 'false') {
          return value === 'true';
        }
        return value;
      }
      return undefined;
    }
    static calculateBodyScrollbarWidth() {
      return window.innerWidth - document.documentElement.offsetWidth;
    }
    static blockBodyScroll(className = 'p-overflow-hidden') {
      document.body.style.setProperty('--scrollbar-width', this.calculateBodyScrollbarWidth() + 'px');
      this.addClass(document.body, className);
    }
    static unblockBodyScroll(className = 'p-overflow-hidden') {
      document.body.style.removeProperty('--scrollbar-width');
      this.removeClass(document.body, className);
    }
    static createElement(type, attributes = {}, ...children) {
      if (type) {
        const element = document.createElement(type);
        this.setAttributes(element, attributes);
        element.append(...children);
        return element;
      }
      return undefined;
    }
    static setAttribute(element, attribute = '', value) {
      if (this.isElement(element) && value !== null && value !== undefined) {
        element.setAttribute(attribute, value);
      }
    }
    static setAttributes(element, attributes = {}) {
      if (this.isElement(element)) {
        const computedStyles = (rule, value) => {
          const styles = element?.$attrs?.[rule] ? [element?.$attrs?.[rule]] : [];
          return [value].flat().reduce((cv, v) => {
            if (v !== null && v !== undefined) {
              const type = typeof v;
              if (type === 'string' || type === 'number') {
                cv.push(v);
              } else if (type === 'object') {
                const _cv = Array.isArray(v) ? computedStyles(rule, v) : Object.entries(v).map(([_k, _v]) => rule === 'style' && (!!_v || _v === 0) ? `${_k.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase()}:${_v}` : !!_v ? _k : undefined);
                cv = _cv.length ? cv.concat(_cv.filter(c => !!c)) : cv;
              }
            }
            return cv;
          }, styles);
        };
        Object.entries(attributes).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            const matchedEvent = key.match(/^on(.+)/);
            if (matchedEvent) {
              element.addEventListener(matchedEvent[1].toLowerCase(), value);
            } else if (key === 'pBind') {
              this.setAttributes(element, value);
            } else {
              value = key === 'class' ? [...new Set(computedStyles('class', value))].join(' ').trim() : key === 'style' ? computedStyles('style', value).join(';').trim() : value;
              (element.$attrs = element.$attrs || {}) && (element.$attrs[key] = value);
              element.setAttribute(key, value);
            }
          }
        });
      }
    }
    static isFocusableElement(element, selector = '') {
      return this.isElement(element) ? element.matches(`button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
                [href][clientHeight][clientWidth]:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
                input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
                select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
                textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
                [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector},
                [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${selector}`) : false;
    }
  }
  return DomHandler;
})();
class ConnectedOverlayScrollHandler {
  element;
  listener;
  scrollableParents;
  constructor(element, listener = () => {}) {
    this.element = element;
    this.listener = listener;
  }
  bindScrollListener() {
    this.scrollableParents = DomHandler.getScrollableParents(this.element);
    for (let i = 0; i < this.scrollableParents.length; i++) {
      this.scrollableParents[i].addEventListener('scroll', this.listener);
    }
  }
  unbindScrollListener() {
    if (this.scrollableParents) {
      for (let i = 0; i < this.scrollableParents.length; i++) {
        this.scrollableParents[i].removeEventListener('scroll', this.listener);
      }
    }
  }
  destroy() {
    this.unbindScrollListener();
    this.element = null;
    this.listener = null;
    this.scrollableParents = null;
  }
}

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-dom.mjs.map

/***/ }),

/***/ 6330:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}

/***/ })

}]);